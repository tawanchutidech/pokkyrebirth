# Deploy GVG 7K on Cloudflare Workers

This project is configured as a full-stack Cloudflare Worker. Static files are
served from `guild-war-hub.pages.dev`; team data and votes are persisted by a
Durable Object on Cloudflare. No GitHub token or GitHub API is used.

## What is stored where

- `data/teams.json` is the packaged fallback used for local previews and the
  first deployment.
- The Durable Object is the shared source of truth after explicit, one-time
  initialization by an administrator.
- Production never substitutes the bundled JSON when the Durable Object is
  unavailable or empty. It returns a safe maintenance error instead.
- Browser drafts in `localStorage` are still available as an editing safety
  net. A successful platform save clears that browser draft.
- Votes, registered accounts, and activity events are saved to the Durable
  Object. An account can be created with Discord without guild membership.

## Prerequisites

1. Node.js 20 or later.
2. A Cloudflare account with Workers enabled.
3. A Discord application.

## 1. Configure Cloudflare values

Edit `wrangler.jsonc` before deployment:

- `name`: a unique Worker name.
- `PUBLIC_ORIGIN`: leave empty for the initial `workers.dev` deployment, then
  set it to the final HTTPS domain, without a trailing slash.
- `DISCORD_CLIENT_ID`: Discord application client ID.
- `DISCORD_GUILD_ID`: the Discord server ID used to check a member's roles.
- `DISCORD_EDITOR_ROLE_ID`: role ID whose members may edit and save teams,
  without administrator access.
- `DISCORD_ADMIN_ROLE_ID`: role ID whose members receive full Admin access.
- `DISCORD_MEMBER_ROLE_IDS`: comma-separated role IDs that grant read-only guild
  member access. Members can browse teams, but cannot edit or save teams.
- `DISCORD_ADMIN_USER_IDS`: comma-separated Discord user IDs that also receive
  full Admin access. A user may become Admin through either this setting or
  `DISCORD_ADMIN_ROLE_ID`.
- `TEAM_STORE_EXPECTED_ID`: permanent identity of the production team store.
  Do not change it during an ordinary deployment.

Keep these two values as Cloudflare secrets; do not put them in `wrangler.jsonc`:

```powershell
npx wrangler secret put DISCORD_CLIENT_SECRET
npx wrangler secret put SESSION_SECRET
```

For `SESSION_SECRET`, use a long random value, for example:

```powershell
[Convert]::ToBase64String((1..48 | ForEach-Object { Get-Random -Maximum 256 }))
```

## 2. Configure Discord OAuth

In the Discord Developer Portal, add this exact OAuth redirect URL:

```text
https://gvg-7k-pokkyxpriest.okegta.workers.dev/auth/callback
```

After adding a custom domain, add that domain's `/auth/callback` URL too, set
`PUBLIC_ORIGIN` to the custom domain, and deploy again. The Worker requests
`identify` and `guilds.members.read`; any Discord account can sign up without granting an email
address to the site.

## 3. Deploy

```powershell
npm install
npx wrangler login
npx wrangler deploy
```

Wrangler creates the Durable Object from the migration in `wrangler.jsonc` on
the first deployment. Open the returned `workers.dev` URL and test Discord
login.

## 4. Seed shared team data

Existing stores are migrated in place: the first protected read creates store
metadata and an immutable snapshot without changing the team revision. An empty
store is not automatically seeded. Initialize an empty production store only
through the administrator-only `/api/teams/initialize` workflow with explicit
`INITIALIZE` confirmation and a verified export.

After initialization, administrators import data through the guarded Import
workflow. It shows additions, modifications, deletions, counter-count changes,
and historical-checksum matches before issuing a short-lived apply token.

This uploads the normalized JSON to the Durable Object. All visitors will then
read the same shared data through `/api/teams`. Imported records are displayed
as `PokkyRebirth` while retaining the compatible team JSON schema.

## Local development

Create a local `.dev.vars` file (never commit it):

```text
DISCORD_CLIENT_SECRET=replace-me
SESSION_SECRET=replace-with-a-long-random-value
```

Then run:

```powershell
npm install
npm run dev
```

For local OAuth, add the callback URL printed by Wrangler to the Discord
application's Redirects list. Local Durable Object data persists in Wrangler's
development state; delete `.wrangler` only when you intentionally want to
reset local test data.

## Operational notes

- `POST /api/teams/mutate` requires a valid Researcher/editor or administrator
  session. The legacy full-dataset `PUT /api/teams` route is retired.
- `POST /api/votes` requires a signed-in user session.
- `GET /api/teams` is public, so visitors can read the published team list.
- `GET /api/users` and `GET /api/activity` require an administrator session.
  The activity log includes visit/login time, path, browser user-agent and IP;
  it is capped at the latest 5,000 events and de-duplicates repeat page visits
  for 15 minutes. Inform visitors about this collection and set a retention
  policy appropriate for your jurisdiction before launching publicly.
- Administrators can also open **Admin Tools** in the site to view the latest
  visits and registered-user count without calling the API manually.
- The Worker serializes team writes and vote updates through one Durable
  Object, avoiding the concurrent full-file write race that existed with the
  former GitHub-file approach.

## Rollback-protection deployment gate

Capture the current revision and team count before deployment:

```powershell
npm run capture:baseline -- https://gvg-7k-pokkyxpriest.okegta.workers.dev
```

Set the returned baseline values and run the protected check after deployment:

```powershell
$env:TEAM_MIN_REVISION = "replace-with-current-revision"
$env:TEAM_MIN_COUNT = "replace-with-current-team-count"
npm run verify:deployment -- https://gvg-7k-pokkyxpriest.okegta.workers.dev gvg-7k-pokkyxpriest-production-v1
```

The check fails if the store identity changes, revision decreases, team count
falls below the supplied baseline, API metadata disagrees with team data, or
the protected client assets are not deployed.

Never change the Worker name, `TEAM_STORE` class/binding, environment, or the
Durable Object name `primary` as an ordinary configuration edit. Use an
explicit Cloudflare Durable Object transfer/rename migration and verify the
store identity and revision before allowing traffic.

## Recovery runbook

1. Stop team editing or temporarily remove editor permissions.
2. Open Admin Tools and inspect **ประวัติและกู้คืนข้อมูลทีม**.
3. Download the current revision and the intended recovery revision.
4. Verify actor, timestamp, counts, changed IDs, and checksum.
5. Select **กู้คืน**, enter an incident reason, and confirm.
6. Confirm the restored content appears as a new, higher revision.
7. Run `npm run verify:deployment` using the pre-incident minimum team count.
8. Re-enable editing and record the incident and restored revision.

Restoring revision 12 while revision 30 is current creates revision 31. It does
not lower the revision or delete intervening history. If application snapshots
are unavailable, use Cloudflare SQLite Durable Object point-in-time recovery
only after exporting current state and recording the recovery bookmark so the
infrastructure restore can itself be undone.

Application snapshots are retained in the Durable Object. Configure a separate
scheduled export destination before enabling automatic snapshot cleanup; this
repository intentionally performs no history deletion until that independent
backup is available and verified.
