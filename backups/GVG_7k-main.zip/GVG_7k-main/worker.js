const JSON_HEADERS = {
  "Content-Type": "application/json; charset=utf-8",
  "Cache-Control": "no-store"
};

const SESSION_COOKIE = "gvg_session";
const OAUTH_STATE_COOKIE = "gvg_oauth_state";
const SESSION_MAX_AGE = 60 * 60 * 6;
const PRESENCE_TIMEOUT_MS = 15 * 60 * 1000;
const DISPLAY_GUILD = "PokkyRebirth";
const ACTIVITY_RETENTION = 5000;
const TEAM_HISTORY_LIMIT = 100;
const IMPORT_TOKEN_TTL_MS = 10 * 60 * 1000;
const MEMBER_GUILD_NAMES = new Map([
  ["1419264782988738611", "PokkyRebirth"],
  ["1534224204155584535", "Priest"],
  ["1536371863037542400", "Gummy"],
  ["1536731765412991016", "Unleash"],
  ["1537436314037784708", "Everlasting"]
]);

export class TeamStore {
  constructor(state) {
    this.state = state;
  }

  async fetch(request) {
    const url = new URL(request.url);

    if (request.method === "GET" && url.pathname === "/teams") {
      const loaded = await this.loadTeamState(request);
      return loaded.response || json(loaded.data);
    }

    if (request.method === "PUT" && url.pathname === "/teams") {
      const envelope = await request.json();
      const expectedRevision = Number(request.headers.get("X-Team-Version"));
      const loaded = await this.loadTeamState(request);
      if (loaded.response) return loaded.response;
      if (!Number.isInteger(expectedRevision) || expectedRevision !== loaded.meta.currentRevision) {
        return json({ error: "stale_version", revision: loaded.meta.currentRevision }, 409);
      }
      return json({ error: "legacy_publish_retired" }, 410);
    }

    if (request.method === "POST" && url.pathname === "/teams/mutate") {
      const envelope = await request.json();
      const loaded = await this.loadTeamState(request);
      if (loaded.response) return loaded.response;
      if (!Number.isInteger(envelope.baseRevision) || envelope.baseRevision !== loaded.meta.currentRevision) {
        return json({ error: "stale_version", revision: loaded.meta.currentRevision }, 409);
      }
      let proposed;
      try {
        proposed = applyTeamOperations(loaded.data, envelope.operations);
      } catch (error) {
        return json({ error: "invalid_operation", message: error.message }, 400);
      }
      proposed = normalizeTeams(proposed, loaded.meta.currentRevision + 1);
      const change = summarizeTeamChange(loaded.data, proposed);
      const changedTeamCount = change.addedIds.length + change.changedIds.length + change.removedIds.length;
      const counterReduction = change.before.counterCount - change.after.counterCount;
      if (changedTeamCount === 0 && !change.orderChanged) return json({ error: "no_changes" }, 400);
      if (change.removedIds.length > 1 || changedTeamCount > 10 || counterReduction > 10) {
        return json({ error: "destructive_change_requires_import", change }, 409);
      }
      const proposedChecksum = await checksumJson(proposed);
      const matchingRevision = await this.findHistoricalChecksum(proposedChecksum);
      if (matchingRevision && matchingRevision !== loaded.meta.currentRevision) {
        return json({ error: "historical_snapshot_requires_restore", matchingRevision, change }, 409);
      }
      return this.commitTeamData(request, loaded, proposed, {
        actor: envelope.actor,
        operation: "mutation_batch",
        reason: envelope.reason
      });
    }

    if (request.method === "POST" && url.pathname === "/teams/import/preview") {
      const envelope = await request.json();
      const loaded = await this.loadTeamState(request);
      if (loaded.response) return loaded.response;
      let proposed;
      try {
        proposed = normalizeTeams(envelope.data, loaded.meta.currentRevision + 1);
        validateTeams(proposed);
      } catch (error) {
        return json({ error: "invalid_teams", message: error.message }, 400);
      }
      const proposedChecksum = await checksumJson(proposed);
      const change = summarizeTeamChange(loaded.data, proposed);
      const actor = sanitizeActor(envelope.actor);
      const token = randomToken();
      const expiresAt = Date.now() + IMPORT_TOKEN_TTL_MS;
      const matchingRevision = await this.findHistoricalChecksum(proposedChecksum);
      await this.state.storage.put(`team_import_token:${token}`, {
        actorId: actor.userId,
        baseRevision: loaded.meta.currentRevision,
        proposedChecksum,
        proposed,
        change,
        expiresAt
      });
      return json({
        token,
        expiresAt: new Date(expiresAt).toISOString(),
        baseRevision: loaded.meta.currentRevision,
        proposedChecksum,
        matchingRevision,
        destructive: change.removedIds.length > 0 || change.before.counterCount > change.after.counterCount,
        change
      });
    }

    if (request.method === "POST" && url.pathname === "/teams/import/apply") {
      const envelope = await request.json();
      if (!String(envelope.reason || "").trim()) return json({ error: "reason_required" }, 400);
      const tokenKey = `team_import_token:${String(envelope.token || "")}`;
      const preview = await this.state.storage.get(tokenKey);
      const actor = sanitizeActor(envelope.actor);
      if (!preview || preview.expiresAt < Date.now() || preview.actorId !== actor.userId) {
        return json({ error: "invalid_import_token" }, 409);
      }
      const isDestructive = preview.change.removedIds.length > 0 ||
        preview.change.before.counterCount > preview.change.after.counterCount;
      if (isDestructive && envelope.confirmDestructive !== true) {
        return json({ error: "destructive_confirmation_required", change: preview.change }, 409);
      }
      const loaded = await this.loadTeamState(request);
      if (loaded.response) return loaded.response;
      if (preview.baseRevision !== loaded.meta.currentRevision) {
        await this.state.storage.delete(tokenKey);
        return json({ error: "stale_version", revision: loaded.meta.currentRevision }, 409);
      }
      const response = await this.commitTeamData(request, loaded, preview.proposed, {
        actor,
        operation: "import",
        reason: envelope.reason,
        expectedChecksum: preview.proposedChecksum
      });
      if (response.ok) await this.state.storage.delete(tokenKey);
      return response;
    }

    if (request.method === "POST" && url.pathname === "/teams/initialize") {
      const envelope = await request.json();
      if (envelope.confirm !== "INITIALIZE") return json({ error: "initialization_confirmation_required" }, 400);
      if (!String(envelope.reason || "").trim()) return json({ error: "reason_required" }, 400);
      const expectedStoreId = this.expectedStoreId(request);
      if (!expectedStoreId) return json({ error: "store_identity_not_configured" }, 500);
      const [current, existingMeta] = await Promise.all([
        this.state.storage.get("teams"),
        this.state.storage.get("teams_meta")
      ]);
      if (current || existingMeta) return json({ error: "store_already_initialized" }, 409);
      let data;
      try {
        data = normalizeTeams(envelope.data, 1);
        validateTeams(data);
      } catch (error) {
        return json({ error: "invalid_teams", message: error.message }, 400);
      }
      const checksum = await checksumJson(data);
      const now = new Date().toISOString();
      const actor = sanitizeActor(envelope.actor);
      const meta = {
        storeId: expectedStoreId,
        currentRevision: 1,
        initializedAt: now,
        updatedAt: now,
        currentChecksum: checksum,
        schemaVersion: 1
      };
      const change = summarizeTeamChange({ teams: [] }, data);
      const audit = teamChangeAudit({
        actor, operation: "initialize", reason: envelope.reason, change,
        previousRevision: 0, newRevision: 1, previousChecksum: null,
        newChecksum: checksum, workerVersion: envelope.workerVersion
      });
      let initialized = false;
      await this.storageTransaction(async (storage) => {
        if (await storage.get("teams") || await storage.get("teams_meta")) throw new Error("store_already_initialized");
        await storage.put("teams", data);
        await storage.put("teams_meta", meta);
        await storage.put(snapshotKey(1), data);
        await storage.put(changeKey(1), audit);
        initialized = true;
      }).catch((error) => {
        if (error.message !== "store_already_initialized") throw error;
      });
      if (!initialized) return json({ error: "store_already_initialized" }, 409);
      const saved = await this.state.storage.get("teams_meta");
      if (!saved || saved.storeId !== expectedStoreId) return json({ error: "store_already_initialized" }, 409);
      return json({ data, meta, change: audit }, 201);
    }

    if (request.method === "GET" && url.pathname === "/teams/meta") {
      const loaded = await this.loadTeamState(request);
      if (loaded.response) return loaded.response;
      return json({
        storeId: loaded.meta.storeId,
        revision: loaded.meta.currentRevision,
        checksum: loaded.meta.currentChecksum,
        schemaVersion: loaded.meta.schemaVersion,
        updatedAt: loaded.meta.updatedAt,
        ...teamCounts(loaded.data)
      });
    }

    if (request.method === "GET" && url.pathname === "/teams/history") {
      const loaded = await this.loadTeamState(request);
      if (loaded.response) return loaded.response;
      const requestedLimit = Number(url.searchParams.get("limit"));
      const limit = Number.isInteger(requestedLimit) ? Math.min(Math.max(requestedLimit, 1), TEAM_HISTORY_LIMIT) : 25;
      const entries = await this.state.storage.list({ prefix: "team_change:", reverse: true, limit });
      return json({ currentRevision: loaded.meta.currentRevision, changes: [...entries.values()] });
    }

    const snapshotMatch = url.pathname.match(/^\/teams\/history\/(\d+)$/);
    if (request.method === "GET" && snapshotMatch) {
      const loaded = await this.loadTeamState(request);
      if (loaded.response) return loaded.response;
      const revision = Number(snapshotMatch[1]);
      const snapshot = await this.state.storage.get(snapshotKey(revision));
      if (!snapshot) return json({ error: "revision_not_found" }, 404);
      return json(snapshot);
    }

    if (request.method === "POST" && url.pathname === "/teams/restore") {
      const envelope = await request.json();
      if (!String(envelope.reason || "").trim()) return json({ error: "reason_required" }, 400);
      const loaded = await this.loadTeamState(request);
      if (loaded.response) return loaded.response;
      const revision = Number(envelope.revision);
      const snapshot = Number.isInteger(revision) ? await this.state.storage.get(snapshotKey(revision)) : null;
      if (!snapshot) return json({ error: "revision_not_found" }, 404);
      const proposed = normalizeTeams(snapshot, loaded.meta.currentRevision + 1);
      return this.commitTeamData(request, loaded, proposed, {
        actor: envelope.actor,
        operation: "restore",
        reason: envelope.reason || `Restore revision ${revision}`,
        restoredRevision: revision
      });
    }

    if (request.method === "POST" && url.pathname === "/votes") {
      const vote = await request.json();
      const data = await this.state.storage.get("teams");
      if (!data) return json({ error: "not_initialized" }, 409);

      const team = data.teams.find((item) => item.id === vote.teamId);
      const counter = team?.counters?.[Number(vote.counterIdx)];
      if (!counter || !["like", "dislike"].includes(vote.voteType) || !vote.userId) {
        return json({ error: "invalid_vote" }, 400);
      }

      const voteKey = `vote:${vote.userId}:${vote.teamId}:${vote.counterIdx}`;
      const previous = await this.state.storage.get(voteKey);
      const next = previous === vote.voteType ? null : vote.voteType;
      let likes = counter.likes || 0;
      let dislikes = counter.dislikes || 0;

      if (previous === "like") likes = Math.max(0, likes - 1);
      if (previous === "dislike") dislikes = Math.max(0, dislikes - 1);
      if (next === "like") likes += 1;
      if (next === "dislike") dislikes += 1;

      counter.likes = likes;
      counter.dislikes = dislikes;
      if (next) await this.state.storage.put(voteKey, next);
      else await this.state.storage.delete(voteKey);
      await this.state.storage.put("teams", data);

      return json({ newVote: next, likes, dislikes });
    }

    if (request.method === "POST" && url.pathname === "/users") {
      const account = await request.json();
      if (!account?.id || !account?.provider || !account?.displayName) {
        return json({ error: "invalid_user" }, 400);
      }

      const key = `user:${account.provider}:${account.id}`;
      const existing = await this.state.storage.get(key);
      const now = new Date().toISOString();
      const user = {
        id: String(account.id),
        provider: String(account.provider),
        displayName: String(account.displayName),
        email: account.email ? String(account.email) : null,
        firstSeenAt: existing?.firstSeenAt || now,
        lastLoginAt: now,
        loginCount: (existing?.loginCount || 0) + 1,
        lastIp: account.ip || null,
        guild: account.guild || DISPLAY_GUILD
      };
      await this.state.storage.put(key, user);
      await this.addActivity({
        type: "login",
        at: now,
        userId: user.id,
        provider: user.provider,
        displayName: user.displayName,
        email: user.email,
        ip: user.lastIp,
        guild: user.guild
      });
      return json(user);
    }

    if (request.method === "POST" && url.pathname === "/activity") {
      const activity = await request.json();
      if (!activity?.type || !activity?.at) return json({ error: "invalid_activity" }, 400);
      return json(await this.addActivity(activity));
    }

    if (request.method === "GET" && url.pathname === "/activity") {
      const requestedLimit = Number(url.searchParams.get("limit"));
      const limit = Number.isInteger(requestedLimit) ? Math.min(Math.max(requestedLimit, 1), ACTIVITY_RETENTION) : 250;
      const entries = await this.state.storage.list({ prefix: "activity:", reverse: true, limit });
      return json({ activities: [...entries.values()] });
    }

    if (request.method === "GET" && url.pathname === "/users") {
      const users = await this.state.storage.list({ prefix: "user:", limit: 1000 });
      return json({ users: [...users.values()] });
    }

    if (request.method === "GET" && url.pathname === "/access-code") {
      const code = await this.getAccessCode();
      return json({ code: code.code, version: code.version, date: code.date });
    }

    if (request.method === "GET" && url.pathname === "/access-code/version") {
      const code = await this.getAccessCode();
      return json({ version: code.version, date: code.date });
    }

    if (request.method === "POST" && url.pathname === "/access-code/verify") {
      const body = await request.json();
      const code = await this.getAccessCode();
      return json({ valid: String(body?.code || "") === code.code, version: code.version, date: code.date });
    }

    if (request.method === "POST" && url.pathname === "/access-code/reset") {
      const code = await this.getAccessCode({ reset: true });
      return json({ code: code.code, version: code.version, date: code.date });
    }

    if (request.method === "POST" && url.pathname === "/presence") {
      const presence = await request.json();
      if (!presence?.userId || !presence?.provider) return json({ error: "invalid_presence" }, 400);
      return json(await this.touchPresence(presence));
    }

    if (request.method === "GET" && url.pathname === "/presence") {
      return json(await this.getPresence());
    }

    if (request.method === "DELETE" && url.pathname === "/presence") {
      const presence = await request.json();
      if (!presence?.userId || !presence?.provider) return json({ error: "invalid_presence" }, 400);
      await this.state.storage.delete(`presence:${String(presence.provider)}:${String(presence.userId)}`);
      return json(await this.getPresence());
    }

    return json({ error: "not_found" }, 404);
  }

  expectedStoreId(request) {
    return String(request.headers.get("X-Team-Store-Id") || "").trim();
  }

  async loadTeamState(request) {
    const expectedStoreId = this.expectedStoreId(request);
    if (!expectedStoreId) return { response: json({ error: "store_identity_not_configured" }, 500) };

    let [data, meta] = await Promise.all([
      this.state.storage.get("teams"),
      this.state.storage.get("teams_meta")
    ]);
    if (!data) return { response: json({ error: "store_uninitialized" }, 503) };

    const normalized = normalizeTeams(data);
    try {
      validateTeams(normalized);
    } catch (error) {
      return { response: json({ error: "stored_teams_invalid", message: error.message }, 503) };
    }

    // One-time, content-preserving migration for the pre-history production
    // store. Empty storage is never initialized here.
    if (!meta) {
      const checksum = await checksumJson(normalized);
      const revision = Number(normalized.revision) || 1;
      const now = new Date().toISOString();
      const migrationMeta = {
        storeId: expectedStoreId,
        currentRevision: revision,
        initializedAt: now,
        updatedAt: now,
        currentChecksum: checksum,
        schemaVersion: 1
      };
      const change = summarizeTeamChange({ teams: [] }, normalized);
      const audit = teamChangeAudit({
        actor: { displayName: "System migration" },
        operation: "metadata_migration",
        reason: "Create rollback-protection metadata for existing team data",
        change,
        previousRevision: 0,
        newRevision: revision,
        previousChecksum: null,
        newChecksum: checksum,
        workerVersion: request.headers.get("X-Worker-Version")
      });
      await this.storageTransaction(async (storage) => {
        const currentMeta = await storage.get("teams_meta");
        if (currentMeta) return;
        const current = await storage.get("teams");
        if (!current) throw new Error("store_uninitialized");
        await storage.put("teams", normalized);
        await storage.put("teams_meta", migrationMeta);
        await storage.put(snapshotKey(revision), normalized);
        await storage.put(changeKey(revision), audit);
      });
      [data, meta] = await Promise.all([
        this.state.storage.get("teams"),
        this.state.storage.get("teams_meta")
      ]);
    }

    if (meta.storeId !== expectedStoreId) {
      return { response: json({ error: "store_identity_mismatch" }, 503) };
    }
    const currentRevision = Number(data.revision);
    if (!Number.isInteger(currentRevision) || currentRevision !== meta.currentRevision) {
      return { response: json({ error: "store_metadata_inconsistent" }, 503) };
    }
    return { data: normalizeTeams(data, currentRevision), meta };
  }

  async commitTeamData(request, loaded, proposed, details = {}) {
    try {
      validateTeams(proposed);
    } catch (error) {
      return json({ error: "invalid_teams", message: error.message }, 400);
    }
    const checksum = await checksumJson(proposed);
    if (details.expectedChecksum && checksum !== details.expectedChecksum) {
      return json({ error: "import_checksum_mismatch" }, 409);
    }
    const change = summarizeTeamChange(loaded.data, proposed);
    const actor = sanitizeActor(details.actor);
    const nextMeta = {
      ...loaded.meta,
      currentRevision: proposed.revision,
      updatedAt: new Date().toISOString(),
      currentChecksum: checksum,
      schemaVersion: 1
    };
    const audit = teamChangeAudit({
      actor,
      operation: details.operation || "mutation",
      reason: details.reason,
      change,
      previousRevision: loaded.meta.currentRevision,
      newRevision: proposed.revision,
      previousChecksum: loaded.meta.currentChecksum,
      newChecksum: checksum,
      workerVersion: request.headers.get("X-Worker-Version"),
      restoredRevision: details.restoredRevision
    });

    try {
      await this.storageTransaction(async (storage) => {
        const [current, meta] = await Promise.all([
          storage.get("teams"),
          storage.get("teams_meta")
        ]);
        if (!current || !meta) throw new Error("store_uninitialized");
        if (meta.storeId !== loaded.meta.storeId) throw new Error("store_identity_mismatch");
        if (meta.currentRevision !== loaded.meta.currentRevision || Number(current.revision) !== loaded.meta.currentRevision) {
          throw new Error("stale_version");
        }
        if (!await storage.get(snapshotKey(loaded.meta.currentRevision))) {
          await storage.put(snapshotKey(loaded.meta.currentRevision), loaded.data);
        }
        await storage.put("teams", proposed);
        await storage.put("teams_meta", nextMeta);
        await storage.put(snapshotKey(proposed.revision), proposed);
        await storage.put(changeKey(proposed.revision), audit);
      });
    } catch (error) {
      if (error.message === "stale_version") {
        const currentMeta = await this.state.storage.get("teams_meta");
        return json({ error: "stale_version", revision: currentMeta?.currentRevision }, 409);
      }
      if (["store_uninitialized", "store_identity_mismatch"].includes(error.message)) {
        return json({ error: error.message }, 503);
      }
      throw error;
    }

    return json({ ...proposed, meta: nextMeta, change: audit });
  }

  async findHistoricalChecksum(checksum) {
    const entries = await this.state.storage.list({
      prefix: "team_change:", reverse: true, limit: TEAM_HISTORY_LIMIT
    });
    const match = [...entries.values()].find((entry) => entry.newChecksum === checksum);
    return match?.newRevision || null;
  }

  async storageTransaction(callback) {
    if (typeof this.state.storage.transaction === "function") {
      return this.state.storage.transaction(callback);
    }
    return callback(this.state.storage);
  }

  async addActivity(activity) {
    const dedupeKey = activity.dedupeKey ? `activity_dedupe:${activity.dedupeKey}` : null;
    const now = Date.now();
    if (dedupeKey) {
      const previous = await this.state.storage.get(dedupeKey);
      if (previous && now - previous < 15 * 60 * 1000) return { recorded: false };
      await this.state.storage.put(dedupeKey, now);
    }

    const key = `activity:${String(now).padStart(13, "0")}:${randomToken().slice(0, 8)}`;
    const saved = { ...activity, dedupeKey: undefined };
    await this.state.storage.put(key, saved);

    const count = (await this.state.storage.get("activity_count")) || 0;
    if (count >= ACTIVITY_RETENTION) {
      const oldest = await this.state.storage.list({ prefix: "activity:", limit: 1 });
      const oldestKey = oldest.keys().next().value;
      if (oldestKey) await this.state.storage.delete(oldestKey);
      await this.state.storage.put("activity_count", ACTIVITY_RETENTION);
    } else {
      await this.state.storage.put("activity_count", count + 1);
    }
    return { recorded: true };
  }

  async touchPresence(presence) {
    const now = new Date().toISOString();
    const key = `presence:${String(presence.provider)}:${String(presence.userId)}`;
    await this.state.storage.put(key, {
      userId: String(presence.userId),
      provider: String(presence.provider),
      displayName: presence.displayName ? String(presence.displayName) : null,
      guild: presence.guild ? String(presence.guild) : null,
      lastSeenAt: now
    });
    return this.getPresence();
  }

  async getPresence() {
    const cutoff = Date.now() - PRESENCE_TIMEOUT_MS;
    const entries = await this.state.storage.list({ prefix: "presence:", limit: 1000 });
    let onlineCount = 0;
    const staleKeys = [];
    for (const [key, presence] of entries) {
      const lastSeenAt = Date.parse(presence?.lastSeenAt || "");
      if (Number.isFinite(lastSeenAt) && lastSeenAt >= cutoff) onlineCount += 1;
      else staleKeys.push(key);
    }
    await Promise.all(staleKeys.map((key) => this.state.storage.delete(key)));
    return { onlineCount, timeoutMinutes: SESSION_MAX_AGE / 60 };
  }

  async getAccessCode({ reset = false } = {}) {
    const date = bangkokDate();
    const saved = await this.state.storage.get("daily_access_code");
    if (!reset && saved?.date === date && /^\d{6}$/.test(saved.code || "") && saved.version) {
      return saved;
    }

    const next = { date, code: randomAccessCode(), version: randomToken(), createdAt: new Date().toISOString() };
    await this.state.storage.put("daily_access_code", next);
    return next;
  }
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (url.pathname === "/auth/login") return startDiscordLogin(request, env);
    if (url.pathname === "/auth/callback") return finishDiscordLogin(request, env);
    if (url.pathname === "/auth/me") return authMe(request, env);
    if (url.pathname === "/auth/logout") return logout(request);

    if (url.pathname === "/api/presence" && request.method === "GET") {
      return teamStoreRequest(env, "/presence", "GET");
    }

    if (url.pathname === "/api/presence" && request.method === "POST") {
      const session = await getSession(request, env);
      if (!session?.member) return json({ error: "member_required" }, 401);
      return teamStoreRequest(env, "/presence", "POST", JSON.stringify({
        userId: session.id,
        provider: session.provider,
        displayName: session.displayName,
        guild: session.memberGuilds?.join(" / ") || DISPLAY_GUILD
      }));
    }

    if (url.pathname === "/api/presence/offline" && request.method === "POST") {
      const session = await getSession(request, env);
      if (!session?.member) return json({ error: "member_required" }, 401);
      return teamStoreRequest(env, "/presence", "DELETE", JSON.stringify({
        userId: session.id,
        provider: session.provider
      }));
    }

    if (url.pathname === "/api/teams" && request.method === "GET") {
      return teamStoreRequest(env, "/teams", "GET");
    }

    if (url.pathname === "/api/teams" && request.method === "PUT") {
      const session = await getSession(request, env);
      if (!session?.canEditTeams) return json({ error: "editor_required" }, 403);
      const data = await request.json();
      const response = await teamStoreRequest(env, "/teams", "PUT", JSON.stringify({
        data,
        actor: teamActor(request, session),
        reason: request.headers.get("X-Team-Reason") || null
      }), {
        "X-Team-Version": request.headers.get("X-Team-Version") || ""
      });
      if (response.ok) ctx?.waitUntil(recordTeamUpdate(env, request, session));
      return response;
    }

    if (url.pathname === "/api/teams/mutate" && request.method === "POST") {
      const session = await getSession(request, env);
      if (!session?.canEditTeams) return json({ error: "editor_required" }, 403);
      const body = await request.json();
      const response = await teamStoreRequest(env, "/teams/mutate", "POST", JSON.stringify({
        baseRevision: body.baseRevision,
        operations: body.operations,
        reason: body.reason,
        actor: teamActor(request, session)
      }));
      if (response.ok) ctx?.waitUntil(recordTeamUpdate(env, request, session, "mutation_batch"));
      return response;
    }

    if (url.pathname === "/api/teams/meta" && request.method === "GET") {
      return teamStoreRequest(env, "/teams/meta", "GET");
    }

    if (url.pathname === "/api/teams/history" && request.method === "GET") {
      const session = await getSession(request, env);
      if (!session?.canAccessAdminTools) return json({ error: "admin_tools_required" }, 403);
      return teamStoreRequest(env, `/teams/history${url.search}`, "GET");
    }

    const historyMatch = url.pathname.match(/^\/api\/teams\/history\/(\d+)$/);
    if (historyMatch && request.method === "GET") {
      const session = await getSession(request, env);
      if (!session?.canAccessAdminTools) return json({ error: "admin_tools_required" }, 403);
      return teamStoreRequest(env, `/teams/history/${historyMatch[1]}`, "GET");
    }

    if (url.pathname === "/api/teams/restore" && request.method === "POST") {
      const session = await getSession(request, env);
      if (!session?.canAccessAdminTools) return json({ error: "admin_tools_required" }, 403);
      const body = await request.json();
      const response = await teamStoreRequest(env, "/teams/restore", "POST", JSON.stringify({
        revision: body.revision,
        reason: body.reason,
        actor: teamActor(request, session)
      }));
      if (response.ok) ctx?.waitUntil(recordTeamUpdate(env, request, session, "restore"));
      return response;
    }

    if (url.pathname === "/api/teams/import/preview" && request.method === "POST") {
      const session = await getSession(request, env);
      if (!session?.canAccessAdminTools) return json({ error: "admin_tools_required" }, 403);
      const body = await request.json();
      return teamStoreRequest(env, "/teams/import/preview", "POST", JSON.stringify({
        data: body.data,
        actor: teamActor(request, session)
      }));
    }

    if (url.pathname === "/api/teams/import/apply" && request.method === "POST") {
      const session = await getSession(request, env);
      if (!session?.canAccessAdminTools) return json({ error: "admin_tools_required" }, 403);
      const body = await request.json();
      const response = await teamStoreRequest(env, "/teams/import/apply", "POST", JSON.stringify({
        token: body.token,
        reason: body.reason,
        confirmDestructive: body.confirmDestructive,
        actor: teamActor(request, session)
      }));
      if (response.ok) ctx?.waitUntil(recordTeamUpdate(env, request, session, "import"));
      return response;
    }

    if (url.pathname === "/api/teams/initialize" && request.method === "POST") {
      const session = await getSession(request, env);
      if (!session?.canAccessAdminTools) return json({ error: "admin_tools_required" }, 403);
      const body = await request.json();
      const response = await teamStoreRequest(env, "/teams/initialize", "POST", JSON.stringify({
        data: body.data,
        confirm: body.confirm,
        reason: body.reason,
        actor: teamActor(request, session),
        workerVersion: env.CF_VERSION_METADATA?.id || null
      }));
      if (response.ok) ctx?.waitUntil(recordTeamUpdate(env, request, session, "initialize"));
      return response;
    }

    if (url.pathname === "/api/votes" && request.method === "POST") {
      return json({ error: "votes_retired" }, 410);
    }

    if (url.pathname === "/api/activity" && request.method === "GET") {
      const session = await getSession(request, env);
      if (!session?.canAccessAdminTools) return json({ error: "admin_tools_required" }, 403);
      return teamStoreRequest(env, `/activity${url.search}`, "GET");
    }

    if (url.pathname === "/api/activity/export" && request.method === "GET") {
      const session = await getSession(request, env);
      if (!session?.canAccessAdminTools) return json({ error: "admin_tools_required" }, 403);
      return exportActivity(env);
    }

    if (url.pathname === "/api/users" && request.method === "GET") {
      const session = await getSession(request, env);
      if (!session?.canAccessAdminTools) return json({ error: "admin_tools_required" }, 403);
      return teamStoreRequest(env, "/users", "GET");
    }

    if (url.pathname === "/api/access-code" && request.method === "GET") {
      const session = await getSession(request, env);
      if (!session?.canAccessAdminTools) return json({ error: "admin_tools_required" }, 403);
      return teamStoreRequest(env, "/access-code", "GET");
    }

    if (url.pathname === "/api/access-code/reset" && request.method === "POST") {
      const session = await getSession(request, env);
      if (!session?.canAccessAdminTools) return json({ error: "admin_tools_required" }, 403);
      return teamStoreRequest(env, "/access-code/reset", "POST");
    }

    if (url.pathname === "/api/access-code/version" && request.method === "GET") {
      return teamStoreRequest(env, "/access-code/version", "GET");
    }

    if (url.pathname === "/api/access-code/verify" && request.method === "POST") {
      return teamStoreRequest(env, "/access-code/verify", "POST", await request.text());
    }

    if (request.method === "GET" && request.headers.get("Accept")?.includes("text/html")) {
      ctx?.waitUntil(recordVisit(env, request));
    }

    return env.ASSETS.fetch(request);
  }
};

function normalizeTeams(value, revision = null) {
  if (!value || !Array.isArray(value.teams)) throw new Error("teams must be an array");
  const { meta: _meta, change: _change, ...data } = value;
  return {
    ...data,
    revision: revision ?? (Number(value.revision) || 1),
    teams: value.teams
      .filter((team) => (team.tab || "attack") !== "defense")
      .map((team) => ({ ...team, guild: DISPLAY_GUILD, pinned: team.hidden ? false : team.pinned }))
  };
}

function validateTeams(value) {
  if (!value || !Array.isArray(value.teams)) throw new Error("teams must be an array");
  if (!Number.isInteger(value.revision) || value.revision < 1) throw new Error("revision must be a positive integer");
  const ids = new Set();
  value.teams.forEach((team, index) => {
    if (!team || typeof team !== "object" || !String(team.id || "").trim()) {
      throw new Error(`team at index ${index} must have an id`);
    }
    if (ids.has(String(team.id))) throw new Error(`duplicate team id: ${team.id}`);
    ids.add(String(team.id));
    if (team.counters !== undefined && !Array.isArray(team.counters)) {
      throw new Error(`team ${team.id} counters must be an array`);
    }
  });
}

function applyTeamOperations(current, operations) {
  if (!Array.isArray(operations) || operations.length < 1 || operations.length > 500) {
    throw new Error("operations must contain between 1 and 500 items");
  }
  const next = structuredClone(current);
  operations.forEach((operation) => {
    if (!operation || typeof operation !== "object") throw new Error("operation must be an object");
    if (operation.type === "upsert_team") {
      const team = structuredClone(operation.team);
      if (!team || !String(team.id || "").trim()) throw new Error("upsert_team requires team.id");
      const index = next.teams.findIndex((item) => String(item.id) === String(team.id));
      if (index >= 0) next.teams[index] = team;
      else next.teams.push(team);
      return;
    }
    if (operation.type === "delete_team") {
      const index = next.teams.findIndex((item) => String(item.id) === String(operation.teamId));
      if (index < 0) throw new Error(`team not found: ${operation.teamId}`);
      next.teams.splice(index, 1);
      return;
    }
    if (operation.type === "set_order") {
      if (!Array.isArray(operation.teamIds)) throw new Error("set_order requires teamIds");
      const requested = operation.teamIds.map(String);
      const currentIds = next.teams.map((team) => String(team.id));
      if (new Set(requested).size !== requested.length || requested.length !== currentIds.length ||
          currentIds.some((id) => !requested.includes(id))) {
        throw new Error("set_order must contain every current team id exactly once");
      }
      const byId = new Map(next.teams.map((team) => [String(team.id), team]));
      next.teams = requested.map((id) => byId.get(id));
      return;
    }
    throw new Error(`unsupported operation: ${operation.type}`);
  });
  return next;
}

function teamCounts(data) {
  const teams = Array.isArray(data?.teams) ? data.teams : [];
  return {
    teamCount: teams.length,
    counterCount: teams.reduce((count, team) => count + (Array.isArray(team.counters) ? team.counters.length : 0), 0)
  };
}

function summarizeTeamChange(before, after) {
  const beforeTeams = Array.isArray(before?.teams) ? before.teams : [];
  const afterTeams = Array.isArray(after?.teams) ? after.teams : [];
  const beforeById = new Map(beforeTeams.map((team) => [String(team.id), team]));
  const afterById = new Map(afterTeams.map((team) => [String(team.id), team]));
  const addedIds = [...afterById.keys()].filter((id) => !beforeById.has(id));
  const removedIds = [...beforeById.keys()].filter((id) => !afterById.has(id));
  const changedIds = [...afterById.keys()].filter((id) =>
    beforeById.has(id) && JSON.stringify(beforeById.get(id)) !== JSON.stringify(afterById.get(id))
  );
  return {
    before: teamCounts({ teams: beforeTeams }),
    after: teamCounts({ teams: afterTeams }),
    addedIds,
    changedIds,
    removedIds,
    orderChanged: beforeTeams.map((team) => String(team.id)).join("|") !==
      afterTeams.map((team) => String(team.id)).join("|")
  };
}

function sanitizeActor(actor) {
  return {
    userId: actor?.userId ? String(actor.userId) : null,
    provider: actor?.provider ? String(actor.provider) : null,
    displayName: actor?.displayName ? String(actor.displayName) : "Unknown",
    guild: actor?.guild ? String(actor.guild) : null,
    ip: actor?.ip ? String(actor.ip) : null
  };
}

function teamChangeAudit({
  actor, operation, reason, change, previousRevision, newRevision,
  previousChecksum, newChecksum, workerVersion, restoredRevision
}) {
  return {
    type: "team_change",
    at: new Date().toISOString(),
    operation,
    reason: reason ? String(reason).slice(0, 500) : null,
    previousRevision,
    newRevision,
    previousChecksum,
    newChecksum,
    workerVersion: workerVersion || null,
    restoredRevision: Number.isInteger(restoredRevision) ? restoredRevision : null,
    ...sanitizeActor(actor),
    change
  };
}

function snapshotKey(revision) {
  return `teams_snapshot:${String(revision).padStart(12, "0")}`;
}

function changeKey(revision) {
  return `team_change:${String(revision).padStart(12, "0")}`;
}

async function checksumJson(value) {
  const checksumValue = value && Array.isArray(value.teams)
    ? { ...value, revision: undefined }
    : value;
  const bytes = new TextEncoder().encode(stableStringify(checksumValue));
  const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", bytes));
  return [...digest].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

function stableStringify(value) {
  if (value === undefined) return "null";
  if (Array.isArray(value)) return `[${value.map((item) => stableStringify(item)).join(",")}]`;
  if (value && typeof value === "object") {
    const entries = Object.keys(value)
      .filter((key) => value[key] !== undefined)
      .sort()
      .map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`);
    return `{${entries.join(",")}}`;
  }
  return JSON.stringify(value);
}

async function teamStoreRequest(env, path, method, body, extraHeaders = {}) {
  const id = env.TEAM_STORE.idFromName("primary");
  const headers = {
    "X-Team-Store-Id": String(env.TEAM_STORE_EXPECTED_ID || ""),
    "X-Worker-Version": String(env.CF_VERSION_METADATA?.id || ""),
    ...(body ? { "Content-Type": "application/json" } : {}),
    ...extraHeaders
  };
  return env.TEAM_STORE.get(id).fetch(new Request(`https://team-store${path}`, { method, headers, body }));
}

async function startDiscordLogin(request, env) {
  if (!hasDiscordConfig(env)) return redirect(request, "/?auth=config_missing");
  const url = new URL(request.url);
  const state = randomToken();
  const redirectUri = publicOrigin(env, url) + "/auth/callback";
  const authorize = new URL("https://discord.com/oauth2/authorize");
  authorize.search = new URLSearchParams({
    client_id: env.DISCORD_CLIENT_ID,
    redirect_uri: redirectUri,
    response_type: "code",
    scope: "identify guilds.members.read",
    state
  }).toString();
  return new Response(null, {
    status: 302,
    headers: {
      Location: authorize.toString(),
      "Set-Cookie": cookie(OAUTH_STATE_COOKIE, state, request, 600, "/auth")
    }
  });
}

async function finishDiscordLogin(request, env) {
  const url = new URL(request.url);
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  const expectedState = cookies(request).get(OAUTH_STATE_COOKIE);
  if (!code || !state || state !== expectedState || !hasDiscordConfig(env)) {
    const reason = hasDiscordConfig(env) ? "state_invalid" : "config_missing";
    return redirect(request, `/?auth=${reason}`, clearCookie(OAUTH_STATE_COOKIE, request, "/auth"));
  }

  const redirectUri = publicOrigin(env, url) + "/auth/callback";
  const tokenResponse = await fetch("https://discord.com/api/v10/oauth2/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: env.DISCORD_CLIENT_ID,
      client_secret: env.DISCORD_CLIENT_SECRET,
      grant_type: "authorization_code",
      code,
      redirect_uri: redirectUri
    })
  });
  if (!tokenResponse.ok) return redirect(request, "/?auth=token_failed", clearCookie(OAUTH_STATE_COOKIE, request, "/auth"));

  const token = await tokenResponse.json();
  const userResponse = await fetch("https://discord.com/api/v10/users/@me", {
    headers: { Authorization: `Bearer ${token.access_token}` }
  });
  if (!userResponse.ok) return redirect(request, "/?auth=user_failed", clearCookie(OAUTH_STATE_COOKIE, request, "/auth"));
  const user = await userResponse.json();
  const guildRoleIds = await discordGuildRoleIds(token.access_token, env);
  return completeLogin(request, env, {
    id: user.id,
    provider: "discord",
    displayName: user.global_name || user.username || "Discord user",
    email: null,
    guildRoleIds
  });
}

async function completeLogin(request, env, account) {
  const roleFlags = getRoleFlags(env, account.id, account.guildRoleIds);
  const session = {
    id: account.id,
    provider: account.provider,
    displayName: account.displayName,
    ...roleFlags,
    guildRoleIds: account.guildRoleIds || [],
    exp: Math.floor(Date.now() / 1000) + SESSION_MAX_AGE
  };
  await recordUser(env, request, account).catch(() => {});
  const sessionValue = await signSession(session, env.SESSION_SECRET);
  const headers = new Headers({ Location: "/?login=success" });
  headers.append("Set-Cookie", cookie(SESSION_COOKIE, sessionValue, request, SESSION_MAX_AGE));
  headers.append("Set-Cookie", clearCookie(OAUTH_STATE_COOKIE, request, "/auth"));
  return new Response(null, { status: 302, headers });
}

async function authMe(request, env) {
  const session = await getSession(request, env);
  if (!session) return json({ loggedIn: false });
  return json({
    loggedIn: true,
    isMember: session.member,
    isAdmin: session.admin,
    isAdminById: session.adminByUserId,
    isResearcher: session.researcher,
    canEditTeams: session.canEditTeams,
    canAccessAdminTools: session.canAccessAdminTools,
    memberGuilds: session.memberGuilds,
    displayName: session.displayName,
    provider: session.provider,
    expiresAt: session.exp * 1000
  });
}

function logout(request) {
  return json({ ok: true }, 200, { "Set-Cookie": clearCookie(SESSION_COOKIE, request) });
}

async function getSession(request, env) {
  const raw = cookies(request).get(SESSION_COOKIE);
  if (!raw || !env.SESSION_SECRET) return null;
  const [payloadPart, signature] = raw.split(".");
  if (!payloadPart || !signature) return null;
  const expected = await hmac(payloadPart, env.SESSION_SECRET);
  if (!safeEqual(signature, expected)) return null;
  try {
    const session = JSON.parse(new TextDecoder().decode(base64UrlToBytes(payloadPart)));
    if (session.exp <= Math.floor(Date.now() / 1000)) return null;
    // Resolve roles from the Worker configuration on every request. This lets
    // role changes take effect for existing signed-in Discord sessions too.
    return { ...session, ...getRoleFlags(env, session.id, session.guildRoleIds) };
  } catch (_) {
    return null;
  }
}

function getRoleFlags(env, userId, guildRoleIds = []) {
  const ids = (value) => new Set(String(value || "").split(",").map((id) => id.trim()).filter(Boolean));
  const adminByUserId = ids(env.DISCORD_ADMIN_USER_IDS).has(String(userId));
  const editorRoleId = String(env.DISCORD_EDITOR_ROLE_ID || "").trim();
  const roleIds = new Set(guildRoleIds.map(String));
  const hasEditorRole = Boolean(editorRoleId) && roleIds.has(editorRoleId);
  // DISCORD_SECURITY_ROLE_ID is retained as a deployment fallback while the
  // configuration is migrated to DISCORD_ADMIN_ROLE_ID.
  const adminRoleId = String(env.DISCORD_ADMIN_ROLE_ID || env.DISCORD_SECURITY_ROLE_ID || "").trim();
  const adminByRole = Boolean(adminRoleId) && roleIds.has(adminRoleId);
  const admin = adminByUserId || adminByRole;
  const memberRoleIds = ids(env.DISCORD_MEMBER_ROLE_IDS);
  const hasMemberRole = [...memberRoleIds].some((roleId) => roleIds.has(roleId));
  const memberGuilds = [...MEMBER_GUILD_NAMES]
    .filter(([roleId]) => memberRoleIds.has(roleId) && roleIds.has(roleId))
    .map(([, guildName]) => guildName);
  const researcher = !admin && hasEditorRole;
  // Researchers and administrators retain access even if they do not hold a member role.
  // Member roles are read-only: only researcher and admin flags grant editing.
  const member = admin || hasEditorRole || hasMemberRole;
  return {
    member,
    admin,
    adminByUserId,
    researcher,
    canEditTeams: admin || researcher,
    canAccessAdminTools: admin,
    memberGuilds
  };
}

function bangkokDate() {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Bangkok", year: "numeric", month: "2-digit", day: "2-digit"
  }).formatToParts(new Date());
  const values = Object.fromEntries(parts.map(({ type, value }) => [type, value]));
  return `${values.year}-${values.month}-${values.day}`;
}

function randomAccessCode() {
  const value = new Uint32Array(1);
  crypto.getRandomValues(value);
  return String((value[0] % 900000) + 100000);
}

async function discordGuildRoleIds(accessToken, env) {
  const guildId = String(env.DISCORD_GUILD_ID || "").trim();
  if (!guildId) return [];
  const response = await fetch(`https://discord.com/api/v10/users/@me/guilds/${guildId}/member`, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });
  if (!response.ok) return [];
  const membership = await response.json();
  return Array.isArray(membership.roles) ? membership.roles.map(String) : [];
}

async function signSession(session, secret) {
  const payload = bytesToBase64Url(new TextEncoder().encode(JSON.stringify(session)));
  return `${payload}.${await hmac(payload, secret)}`;
}

async function hmac(value, secret) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const signature = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(value));
  return bytesToBase64Url(new Uint8Array(signature));
}

function safeEqual(a, b) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i += 1) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

function publicOrigin(env, url) {
  return String(env.PUBLIC_ORIGIN || "").replace(/\/$/, "") || url.origin;
}

function hasDiscordConfig(env) {
  return Boolean(env.DISCORD_CLIENT_ID && env.DISCORD_CLIENT_SECRET && env.SESSION_SECRET);
}

function clientIp(request) {
  return request.headers.get("CF-Connecting-IP") || request.headers.get("X-Forwarded-For")?.split(",")[0].trim() || null;
}

function teamActor(request, session) {
  return {
    userId: session.id,
    provider: session.provider,
    displayName: session.displayName,
    guild: session.memberGuilds?.join(" / ") || DISPLAY_GUILD,
    ip: clientIp(request)
  };
}

async function recordUser(env, request, account) {
  return teamStoreRequest(env, "/users", "POST", JSON.stringify({
    ...account,
    guild: DISPLAY_GUILD,
    ip: clientIp(request)
  }));
}

async function recordTeamUpdate(env, request, session, operation = "legacy_publish") {
  return teamStoreRequest(env, "/activity", "POST", JSON.stringify({
    type: "team_update",
    at: new Date().toISOString(),
    path: "/api/teams",
    operation,
    userId: session.id,
    provider: session.provider,
    displayName: session.displayName,
    guild: DISPLAY_GUILD,
    ip: clientIp(request)
  }));
}

async function exportActivity(env) {
  const response = await teamStoreRequest(env, `/activity?limit=${ACTIVITY_RETENTION}`, "GET");
  if (!response.ok) return response;
  const { activities = [] } = await response.json();
  const fields = ["timestamp", "activity", "user_name", "user_id", "guild", "ip_address", "path", "province", "city", "country", "latitude", "longitude", "maps_url"];
  const rows = activities.map((item) => [
    item.at || "",
    item.type || "",
    item.displayName || "",
    item.userId || "",
    item.guild || "",
    item.ip || "",
    item.path || item.provider || "",
    item.location?.province || "",
    item.location?.city || "",
    item.location?.country || "",
    item.location?.latitude || "",
    item.location?.longitude || "",
    googleMapsUrl(item.location) || ""
  ]);
  const csv = `\uFEFF${[fields, ...rows].map((row) => row.map(csvCell).join(",")).join("\r\n")}`;
  return new Response(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": 'attachment; filename="gvg-activity-log.csv"',
      "Cache-Control": "no-store"
    }
  });
}

function csvCell(value) {
  return `"${String(value ?? "").replace(/"/g, '""')}"`;
}

async function recordVisit(env, request) {
  const url = new URL(request.url);
  const session = await getSession(request, env);
  const ip = clientIp(request);
  const userAgent = request.headers.get("User-Agent") || null;
  const fingerprint = `${session?.id || ip || "unknown"}|${userAgent || "unknown"}|${url.pathname}`;
  return teamStoreRequest(env, "/activity", "POST", JSON.stringify({
    type: "visit",
    at: new Date().toISOString(),
    path: url.pathname,
    userId: session?.id || null,
    provider: session?.provider || null,
    displayName: session?.displayName || null,
    guild: session?.member ? (session.memberGuilds?.join(" / ") || DISPLAY_GUILD) : null,
    ip,
    userAgent,
    location: ipLocation(request),
    dedupeKey: fingerprint
  }));
}

function ipLocation(request) {
  const cf = request.cf || {};
  const latitude = validCoordinate(cf.latitude, -90, 90);
  const longitude = validCoordinate(cf.longitude, -180, 180);
  const location = {
    source: "ip",
    province: cf.region || null,
    city: cf.city || null,
    country: cf.country || null,
    latitude,
    longitude
  };
  return [location.province, location.city, location.country, location.latitude, location.longitude].some(Boolean)
    ? location
    : null;
}

function validCoordinate(value, min, max) {
  const number = Number(value);
  return Number.isFinite(number) && number >= min && number <= max ? String(value) : null;
}

function googleMapsUrl(location) {
  if (!location?.latitude || !location?.longitude) return null;
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${location.latitude},${location.longitude}`)}`;
}

function cookies(request) {
  return new Map((request.headers.get("Cookie") || "").split(";").map((part) => {
    const index = part.indexOf("=");
    return index < 0 ? ["", ""] : [part.slice(0, index).trim(), decodeURIComponent(part.slice(index + 1))];
  }));
}

function cookie(name, value, request, maxAge, path = "/") {
  const secure = new URL(request.url).protocol === "https:" ? "; Secure" : "";
  return `${name}=${encodeURIComponent(value)}; HttpOnly; SameSite=Lax; Path=${path}; Max-Age=${maxAge}${secure}`;
}

function clearCookie(name, request, path = "/") {
  return cookie(name, "", request, 0, path);
}

function randomToken() {
  const bytes = new Uint8Array(24);
  crypto.getRandomValues(bytes);
  return bytesToBase64Url(bytes);
}

function bytesToBase64Url(bytes) {
  let binary = "";
  bytes.forEach((byte) => { binary += String.fromCharCode(byte); });
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function base64UrlToBytes(value) {
  const padded = value.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((value.length + 3) % 4);
  const binary = atob(padded);
  return Uint8Array.from(binary, (char) => char.charCodeAt(0));
}

function json(value, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(value), { status, headers: { ...JSON_HEADERS, ...extraHeaders } });
}

function redirect(request, path, setCookie) {
  const headers = new Headers({ Location: new URL(path, request.url).toString() });
  if (setCookie) headers.set("Set-Cookie", setCookie);
  return new Response(null, { status: 302, headers });
}
