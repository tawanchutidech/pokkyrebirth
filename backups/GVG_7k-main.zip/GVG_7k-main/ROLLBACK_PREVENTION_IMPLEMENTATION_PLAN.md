# Rollback Prevention Implementation Plan

## Task summary

Harden the shared team-data system so that stale browsers, concurrent editors,
old imports, deployment mistakes, and storage-binding mistakes cannot silently
replace current production data with an older dataset. Every accepted change
must be attributable and recoverable.

The existing revision guard remains the first line of defense. This task adds
server-side history, explicit initialization, destructive-change controls,
deployment identity checks, and a tested recovery path.

## Confirmed problem

Before commit `0f129e8`, a browser could restore a complete dataset from an old
`localStorage` draft and publish it without a version check. The full `teams`
value in the Durable Object was then replaced by that historical snapshot.

The current implementation prevents this specific path by attaching a server
revision to drafts and writes. It does not yet protect against:

- An administrator importing an old file after loading the current revision.
- A deployment binding to a new or empty Durable Object.
- The production API silently falling back to the bundled `data/teams.json`.
- An accidental large deletion made from an otherwise current editor session.
- Loss of the current value without an application-level revision history.
- Insufficient audit information to reconstruct exactly what changed.

## Goals

1. Never present bundled fallback data as live production data.
2. Preserve an immutable snapshot for every accepted production revision.
3. Restore any retained revision without lowering or reusing revision numbers.
4. Prevent routine edits from replacing unrelated teams.
5. Require an explicit, reviewed workflow for imports and large deletions.
6. Detect a wrong Durable Object binding before reads or writes are accepted.
7. Record enough evidence to identify the actor, deployment, operation, and
   exact before/after state of every change.
8. Provide automated tests and a documented production recovery procedure.

## Non-goals

- Changing Discord role definitions or the existing authentication provider.
- Redesigning the team editor UI beyond the controls required for previews,
  conflict handling, revision history, and recovery.
- Treating browser drafts as authoritative shared data.
- Promising protection from deliberate infrastructure-account compromise.

## Target storage model

Keep all production team state in the existing `primary` Durable Object, but
separate current state, immutable history, and metadata:

```text
teams                         Current normalized dataset
teams_meta                    Store identity and current revision metadata
teams_snapshot:000000000001   Immutable snapshot for revision 1
teams_snapshot:000000000002   Immutable snapshot for revision 2
team_change:000000000002      Immutable audit record for the transition to 2
```

`teams_meta` should contain at least:

```json
{
  "storeId": "configured-production-store-id",
  "currentRevision": 2,
  "initializedAt": "ISO-8601 timestamp",
  "updatedAt": "ISO-8601 timestamp",
  "currentChecksum": "SHA-256",
  "schemaVersion": 1
}
```

The complete current dataset should continue to include `revision` for client
compatibility. The server, not the client, owns revision numbers and checksums.

## Implementation tasks

### 1. Establish automated regression coverage

Add tests before changing behavior so the existing protection cannot regress.

- Add a `node:test` suite for `TeamStore` using an in-memory storage adapter.
- Test successful revision advancement.
- Test stale, missing, malformed, and future revision rejection.
- Test two editors attempting to save from the same revision.
- Test legacy and mismatched browser drafts being ignored.
- Add `npm test` and retain the existing syntax check.

Expected files:

- `test/team-store.test.js`
- `test/client-store.test.js`
- `package.json`

### 2. Remove silent production fallback

Change `GET /api/teams` behavior:

- If the Durable Object contains current team data, return it normally.
- If storage is empty in production, return `503` with
  `{ "error": "store_uninitialized" }`.
- Do not return `data/teams.json` from the production API.
- Keep `data/teams.json` available only for local/static preview mode.
- Display a non-destructive maintenance message when the client receives
  `store_uninitialized` or `store_identity_mismatch`.
- Do not initialize production storage as a side effect of a read or ordinary
  publish.

Add a separate administrator-only initialization endpoint. It must require an
explicit confirmation payload and must fail if any production team state or
metadata already exists.

### 3. Add store identity verification

- Add a stable `TEAM_STORE_EXPECTED_ID` production configuration value.
- Persist the same ID in `teams_meta` during the controlled migration.
- Pass the expected identity from the outer Worker to the Durable Object on
  every team read, write, restore, and initialization request.
- Return `503 store_identity_mismatch` on any mismatch.
- Never automatically rewrite the stored identity.
- Document the required Durable Object transfer procedure before changing the
  Worker name, class name, binding, environment, or object name `primary`.

For the existing production object, deploy a one-time migration that creates
`teams_meta` and the first snapshot from the existing `teams` value without
changing its content or revision. If `teams` is absent, the migration must stop
and require explicit initialization.

### 4. Make every accepted write recoverable

Perform each accepted mutation as one Durable Object storage transaction:

1. Read and verify `teams_meta`, current data, and expected revision.
2. Normalize and validate the proposed result.
3. Calculate its SHA-256 checksum.
4. Preserve the prior/current snapshots if they do not already exist.
5. Allocate `currentRevision + 1`.
6. Write the new current dataset and metadata.
7. Write an immutable `team_change` audit record.

The audit record must include:

- Previous and new revision.
- Previous and new checksum.
- Timestamp and deployed Worker version.
- Authenticated Discord user ID and display name.
- Operation type: edit, create, delete, reorder, import, initialize, or restore.
- Team and counter counts before and after.
- IDs added, changed, and removed.
- Optional administrator-supplied reason.

Retain at least the latest 100 application snapshots. Do not delete snapshots
until an independent backup has succeeded. Snapshot cleanup must never run in
the same transaction that accepts a user edit.

### 5. Add revision history and safe restore

Add administrator-only endpoints and UI for:

- Listing retained revisions and their audit summaries.
- Previewing a revision without modifying current data.
- Downloading a specific snapshot.
- Restoring a snapshot after confirmation.

A restore must copy the selected snapshot into a new revision. For example,
restoring revision 12 while current is 30 creates revision 31. It must not set
the current revision back to 12 or delete revisions 13 through 30.

### 6. Separate and protect imports

Do not send imported data through the ordinary publish button.

- Add an admin-only import preview endpoint.
- Normalize and validate the file on the server.
- Return counts and IDs for additions, modifications, and deletions.
- Generate a short-lived, single-use confirmation token bound to the current
  revision, checksum, administrator, and proposed imported checksum.
- Require a reason and the confirmation token to apply the import.
- Expire the token if current revision changes before confirmation.
- Always create a snapshot before applying the import.
- Require an additional confirmation when the import removes any team or
  reduces the team/counter count beyond a configurable threshold.

If two-person approval is desired, add it to the import/restore endpoints as a
separate policy after the single-admin workflow is working and tested.

### 7. Replace routine full-dataset writes with operations

Introduce a mutation endpoint for normal editor actions:

```json
{
  "baseRevision": 30,
  "operation": "update_team",
  "teamId": "abc",
  "team": {}
}
```

Supported operations should include create/update/delete team, create/update/
delete counter, visibility changes, pinning, and ordering. The server loads the
current dataset and applies only the requested operation.

- Reject a mutation when its affected entity changed since `baseRevision`.
- Do not let an update remove or replace unrelated teams.
- Keep the guarded full-dataset endpoint temporarily for imports and migration,
  then restrict or remove it after all clients use mutation operations.
- Return the new revision and affected normalized entities to the client.

This is the largest phase and should follow snapshots and safe restore so every
migration step is recoverable.

### 8. Add anomaly detection and deployment checks

Block or elevate suspicious changes, including:

- Revision decreasing or being reused.
- Store identity changing.
- A normal edit deleting unrelated records.
- An import matching the checksum of an older snapshot.
- Unexpectedly large reductions in teams or counters.
- Production storage becoming uninitialized.

Add a deployment smoke-check script that verifies before and after deployment:

- Expected store identity.
- Revision is present and has not decreased.
- Current checksum and counts are readable.
- `/api/teams` never reports fallback mode.
- A stale revision is rejected in staging.
- The deployed HTML and client assets use the intended build version.

Production deployment should stop or automatically roll back when identity or
revision checks fail.

### 9. Add independent backups and a recovery runbook

- Export encrypted/versioned snapshots to a separate storage location on a
  schedule and after high-risk operations such as imports and restores.
- Retain backups longer than the application snapshot window.
- Document Cloudflare SQLite Durable Object point-in-time recovery as the final
  infrastructure-level recovery option.
- Test application restore and infrastructure restore regularly in staging.
- Record the date, operator, restored revision, and verification results for
  every recovery drill.

## API compatibility and rollout order

1. Export and securely retain the current live 29-team dataset.
2. Deploy regression tests and server observability without changing responses.
3. Migrate existing storage metadata and create the initial immutable snapshot.
4. Enable store identity verification and change empty-store reads to `503`.
5. Deploy snapshot-backed writes, detailed audit records, and restore endpoints.
6. Deploy the updated client and guarded import workflow.
7. Deploy operation-based routine edits.
8. Restrict/remove the legacy full-dataset publish path.
9. Enable deployment gates, anomaly alerts, retention cleanup, and independent
   scheduled backups.

Server protection must be deployed before client changes. During rollout, old
clients must continue to receive `409` rather than being allowed to bypass the
new rules.

## Acceptance criteria

- A stale or pre-fix client cannot replace current data.
- Two editors saving from the same revision produce one success and one clear
  conflict; the winner's data remains current.
- An empty or wrong Durable Object never causes bundled JSON to appear as live
  production state.
- Every successful change has a snapshot and immutable audit entry.
- Normal team edits cannot modify unrelated teams.
- An old import cannot be applied without preview, explicit confirmation, a
  current-revision token, and a recovery snapshot.
- Restoring any retained snapshot creates a new monotonic revision.
- The current state can be recovered through both the application revision
  history and the documented infrastructure procedure.
- Deployment checks fail safely on store identity or revision regression.
- Automated tests cover stale drafts, stale writes, concurrent writes, imports,
  restore, initialization, identity mismatch, and large-deletion protection.

## Primary files expected to change

- `worker.js`: storage schema, transactions, snapshots, mutation/import/restore
  endpoints, audit detail, identity checks, and fallback removal.
- `wrangler.jsonc`: stable store identity and optional backup binding/config.
- `guild-war-hub.pages.dev/js/store.js`: maintenance/error states and mutation
  client methods.
- `guild-war-hub.pages.dev/js/publish.js`: conflict handling and removal of
  ordinary full-dataset publishing.
- `guild-war-hub.pages.dev/js/tools.js`: revision history, import preview, and
  restore administration.
- `guild-war-hub.pages.dev/js/editor.js`: operation-based saves and conflicts.
- `guild-war-hub.pages.dev/index.html` and `css/style.css`: history, preview,
  confirmation, and maintenance UI.
- `DEPLOYMENT.md`: store identity, migration, backup, and recovery runbook.
- `test/`: server, client, migration, and failure-path regression tests.

## Definition of done

The task is complete only after the migration has been tested against a copy of
production data, the staging recovery drill succeeds, deployment checks pass,
the production revision and store identity remain unchanged across deployment,
and an administrator can demonstrate previewing and restoring a prior snapshot
as a new revision.
