# GVG 7K by OAKKASET

A Thai-language Guild War strategy hub for the **Seven Knights** community
**PokkyRebirth**. Members can browse enemy formations, find recommended counter
teams, compare equipment requirements, and identify counters that avoid heroes
they have already used.

The application is a framework-free frontend served by a Cloudflare Worker.
Shared teams, votes, registered users, and activity records are persisted in a
Cloudflare Durable Object.

## Features

- Browse attack targets and defensive teams.
- Search and filter teams by hero or category.
- Inspect formations, pets, rings, equipment sets, stat targets, and notes.
- Find available counter teams after selecting heroes that have already been used.
- Vote on recommended counters.
- Share direct links to individual team pages.
- Edit teams through a visual editor with browser draft recovery.
- Authenticate with Discord and assign editor or administrator permissions.
- View registered-user and activity information through administrator tools.

## Technology

- HTML, CSS, and vanilla JavaScript
- Cloudflare Workers and static assets
- Cloudflare Durable Objects with SQLite-backed storage
- Discord OAuth 2.0
- Wrangler for local development and deployment

## Project structure

```text
.
|-- guild-war-hub.pages.dev/
|   |-- index.html          # Main application page
|   |-- css/                # Application styles
|   |-- js/                 # Frontend data, views, editor, and authentication
|   |-- data/teams.json     # Packaged fallback and initial team data
|   `-- public/             # Hero, pet, ring, equipment, and background images
|-- worker.js               # Worker routes, Discord OAuth, and Durable Object
|-- wrangler.jsonc          # Cloudflare configuration
|-- DEPLOYMENT.md           # Detailed deployment instructions
`-- package.json
```

## Requirements

- Node.js 20 or later
- A Cloudflare account with Workers enabled
- A Discord application for OAuth login

## Local development

Install the dependencies:

```powershell
npm install
```

Create a `.dev.vars` file in the project root. Do not commit this file.

```text
DISCORD_CLIENT_SECRET=replace-me
SESSION_SECRET=replace-with-a-long-random-value
```

Review the Discord IDs and public origin in `wrangler.jsonc`, then start the
local Worker:

```powershell
npm run dev
```

Add the `/auth/callback` URL printed by Wrangler to the redirect URLs in your
Discord application before testing Discord login.

## Access levels

| Role | Access |
| --- | --- |
| Member code | Browse team recommendations in the current browser session |
| Discord member role | Browse and vote on counter teams |
| Researcher/editor | Create, edit, and publish shared team data |
| Administrator | Editor access plus imports, exports, access codes, users, and activity logs |

Member, editor, and administrator access is configured through Discord role and
user IDs in `wrangler.jsonc`. The configured member roles are Pokky Member,
Priest Member, Gummy Member, and Unleash Member; they are read-only. Keep
`DISCORD_CLIENT_SECRET` and `SESSION_SECRET` in
Cloudflare secrets or `.dev.vars`; never add them to source control.

Every saved team change is recorded in the administrator-only Activity log with
the editor's Discord display name, guild, and IP address. Admin Tools can export
the full retained log as a CSV file.

## Data flow

`GET /api/teams` reads the shared team list from the Durable Object. Production
returns a safe maintenance error when that store is empty or has the wrong
identity; bundled `data/teams.json` is used only for local/static previews.
Editors work against a versioned browser draft and publish an atomic batch of
targeted team operations through `POST /api/teams/mutate`. Every accepted
revision receives an immutable snapshot, checksum, and audit record. Imports
and restores use separate administrator-only preview and confirmation flows.

## Useful commands

```powershell
npm run dev      # Run the Worker locally
npm run check    # Check worker.js syntax
npm run deploy   # Deploy with Wrangler
```

To regenerate every assigned counter hero's summary after exporting a team-data JSON file:

```powershell
npm run regenerate:counter-summaries -- --input "C:\path\to\teams.json"
```

The command writes a separate `teams.counter-summaries.json` file beside the export. Review and import that file as an administrator. It replaces per-hero counter notes using the saved rings, sets, overlays, and stat values, but preserves team-level notes.

See [DEPLOYMENT.md](DEPLOYMENT.md) for the full Cloudflare and Discord setup.

## Branch workflow

Do not commit directly to `main`. Create a dedicated branch for each change,
push that branch, and open a pull request against `main`.
