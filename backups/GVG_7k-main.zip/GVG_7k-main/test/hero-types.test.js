import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";

const source = fs.readFileSync(
  new URL("../guild-war-hub.pages.dev/js/heroes-data.js", import.meta.url),
  "utf8"
);
const context = {};
vm.createContext(context);
vm.runInContext(
  `${source};globalThis.__heroCatalog = { HEROES, HERO_TYPE_BY_ID, HERO_TYPE_VALUES };`,
  context
);

const { HEROES, HERO_TYPE_BY_ID, HERO_TYPE_VALUES } = context.__heroCatalog;

test("every hero has exactly one valid character type", () => {
  const heroIds = Array.from(HEROES, (hero) => hero.id).sort();
  const typedHeroIds = Object.keys(HERO_TYPE_BY_ID).sort();

  assert.deepEqual(Array.from(HERO_TYPE_VALUES).sort(), [
    "Attack",
    "Defense",
    "Magic",
    "Support",
    "Universal",
  ]);
  assert.deepEqual(typedHeroIds, heroIds);

  for (const hero of HEROES) {
    assert.ok(HERO_TYPE_VALUES.has(hero.type), `${hero.id} has an invalid type`);
  }
});
