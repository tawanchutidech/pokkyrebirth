import test from "node:test";
import assert from "node:assert/strict";
import { TeamStore } from "../worker.js";

const STORE_ID = "test-production-store";

class MemoryStorage {
  constructor(entries = []) {
    this.values = new Map(entries.map(([key, value]) => [key, structuredClone(value)]));
    this.transactionQueue = Promise.resolve();
  }

  async get(key) {
    if (Array.isArray(key)) {
      return new Map(key.filter((item) => this.values.has(item)).map((item) => [item, structuredClone(this.values.get(item))]));
    }
    return this.values.has(key) ? structuredClone(this.values.get(key)) : undefined;
  }

  async put(key, value) {
    this.values.set(key, structuredClone(value));
  }

  async delete(key) {
    this.values.delete(key);
  }

  async list({ prefix = "", reverse = false, limit = Infinity } = {}) {
    let entries = [...this.values.entries()].filter(([key]) => key.startsWith(prefix));
    entries.sort(([a], [b]) => a.localeCompare(b));
    if (reverse) entries.reverse();
    return new Map(entries.slice(0, limit).map(([key, value]) => [key, structuredClone(value)]));
  }

  transaction(callback) {
    const result = this.transactionQueue.then(() => callback(this));
    this.transactionQueue = result.catch(() => {});
    return result;
  }
}

function team(id, name = id, counters = []) {
  return { id, name, tab: "attack", counters };
}

function request(path, { method = "GET", body, version, storeId = STORE_ID } = {}) {
  const headers = new Headers({ "X-Team-Store-Id": storeId, "X-Worker-Version": "test-version" });
  if (body !== undefined) headers.set("Content-Type", "application/json");
  if (version !== undefined) headers.set("X-Team-Version", String(version));
  return new Request(`https://team-store${path}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body)
  });
}

async function responseJson(response) {
  return { status: response.status, body: await response.json() };
}

function storeWith(data) {
  const storage = new MemoryStorage(data ? [["teams", data]] : []);
  return { storage, store: new TeamStore({ storage }) };
}

test("migrates an existing store without changing its team content", async () => {
  const original = { teams: [team("a", "Alpha")], revision: 1 };
  const { storage, store } = storeWith(original);
  const result = await responseJson(await store.fetch(request("/teams")));

  assert.equal(result.status, 200);
  assert.deepEqual(result.body.teams.map(({ id, name }) => ({ id, name })), [{ id: "a", name: "Alpha" }]);
  assert.equal((await storage.get("teams_meta")).storeId, STORE_ID);
  assert.deepEqual(
    (await storage.get("teams_snapshot:000000000001")).teams.map(({ id, name }) => ({ id, name })),
    [{ id: "a", name: "Alpha" }]
  );
});

test("returns 503 for empty storage instead of fallback data", async () => {
  const { store } = storeWith();
  const result = await responseJson(await store.fetch(request("/teams")));
  assert.equal(result.status, 503);
  assert.equal(result.body.error, "store_uninitialized");
});

test("rejects a wrong store identity", async () => {
  const { store } = storeWith({ teams: [team("a")], revision: 1 });
  assert.equal((await store.fetch(request("/teams"))).status, 200);
  const result = await responseJson(await store.fetch(request("/teams", { storeId: "wrong-store" })));
  assert.equal(result.status, 503);
  assert.equal(result.body.error, "store_identity_mismatch");
});

test("accepts mutation writes and rejects stale, headerless, and current legacy publishes", async () => {
  const { store } = storeWith({ teams: [team("a", "Original")], revision: 1 });
  await store.fetch(request("/teams"));

  const accepted = await responseJson(await store.fetch(request("/teams/mutate", {
    method: "POST",
    body: {
      baseRevision: 1,
      actor: { userId: "editor-1" },
      operations: [{ type: "upsert_team", team: team("a", "New") }]
    }
  })));
  const stale = await responseJson(await store.fetch(request("/teams", {
    method: "PUT",
    version: 1,
    body: { data: { teams: [team("a", "Old")] }, actor: { userId: "editor-2" } }
  })));
  const headerless = await responseJson(await store.fetch(request("/teams", {
    method: "PUT",
    body: { data: { teams: [team("a", "Very old")] }, actor: { userId: "legacy" } }
  })));
  const currentLegacy = await responseJson(await store.fetch(request("/teams", {
    method: "PUT",
    version: 2,
    body: { data: { teams: [team("a", "Legacy overwrite")] }, actor: { userId: "legacy" } }
  })));
  const final = await (await store.fetch(request("/teams"))).json();

  assert.equal(accepted.status, 200);
  assert.equal(accepted.body.revision, 2);
  assert.equal(stale.status, 409);
  assert.equal(headerless.status, 409);
  assert.equal(currentLegacy.status, 410);
  assert.equal(final.teams[0].name, "New");
  assert.equal(final.revision, 2);
});

test("serializes competing editors so exactly one mutation wins", async () => {
  const { store } = storeWith({ teams: [team("a", "Original")], revision: 1 });
  await store.fetch(request("/teams"));
  const mutation = (name, userId) => store.fetch(request("/teams/mutate", {
    method: "POST",
    body: {
      baseRevision: 1,
      actor: { userId },
      operations: [{ type: "upsert_team", team: team("a", name) }]
    }
  }));
  const responses = await Promise.all([mutation("First", "one"), mutation("Second", "two")]);
  assert.deepEqual(responses.map((response) => response.status).sort(), [200, 409]);
  const final = await (await store.fetch(request("/teams"))).json();
  assert.equal(final.revision, 2);
  assert.ok(["First", "Second"].includes(final.teams[0].name));
});

test("batch mutations preserve unrelated teams", async () => {
  const { store } = storeWith({ teams: [team("a", "A"), team("b", "B")], revision: 1 });
  await store.fetch(request("/teams"));
  const result = await responseJson(await store.fetch(request("/teams/mutate", {
    method: "POST",
    body: {
      baseRevision: 1,
      actor: { userId: "editor" },
      operations: [{ type: "upsert_team", team: team("a", "A2") }]
    }
  })));
  assert.equal(result.status, 200);
  assert.deepEqual(result.body.teams.map(({ id, name }) => ({ id, name })), [
    { id: "a", name: "A2" }, { id: "b", name: "B" }
  ]);
});

test("restore copies an old snapshot into a new monotonic revision", async () => {
  const { store } = storeWith({ teams: [team("a", "Revision 1")], revision: 1 });
  await store.fetch(request("/teams"));
  await store.fetch(request("/teams/mutate", {
    method: "POST",
    body: {
      baseRevision: 1,
      actor: { userId: "editor" },
      operations: [{ type: "upsert_team", team: team("a", "Revision 2") }]
    }
  }));
  const restored = await responseJson(await store.fetch(request("/teams/restore", {
    method: "POST",
    body: { revision: 1, actor: { userId: "admin" }, reason: "test recovery" }
  })));
  assert.equal(restored.status, 200);
  assert.equal(restored.body.revision, 3);
  assert.equal(restored.body.teams[0].name, "Revision 1");
  assert.equal(restored.body.change.restoredRevision, 1);
});

test("destructive imports require preview and explicit confirmation", async () => {
  const { store } = storeWith({ teams: [team("a"), team("b")], revision: 1 });
  await store.fetch(request("/teams"));
  const preview = await responseJson(await store.fetch(request("/teams/import/preview", {
    method: "POST",
    body: { data: { teams: [team("a")] }, actor: { userId: "admin" } }
  })));
  assert.equal(preview.status, 200);
  assert.equal(preview.body.destructive, true);
  const denied = await responseJson(await store.fetch(request("/teams/import/apply", {
    method: "POST",
    body: { token: preview.body.token, actor: { userId: "admin" }, reason: "test import" }
  })));
  assert.equal(denied.status, 409);
  assert.equal(denied.body.error, "destructive_confirmation_required");
  const applied = await responseJson(await store.fetch(request("/teams/import/apply", {
    method: "POST",
    body: {
      token: preview.body.token,
      actor: { userId: "admin" },
      confirmDestructive: true,
      reason: "approved cleanup"
    }
  })));
  assert.equal(applied.status, 200);
  assert.equal(applied.body.revision, 2);
  assert.deepEqual(applied.body.teams.map((item) => item.id), ["a"]);
});

test("initialization is explicit and can only occur once", async () => {
  const { store } = storeWith();
  const initialized = await responseJson(await store.fetch(request("/teams/initialize", {
    method: "POST",
    body: {
      confirm: "INITIALIZE",
      data: { teams: [team("a")] },
      actor: { userId: "admin" },
      reason: "initial production seed"
    }
  })));
  const repeated = await responseJson(await store.fetch(request("/teams/initialize", {
    method: "POST",
    body: { confirm: "INITIALIZE", data: { teams: [team("b")] }, actor: { userId: "admin" }, reason: "repeat" }
  })));
  assert.equal(initialized.status, 201);
  assert.equal(initialized.body.data.revision, 1);
  assert.equal(repeated.status, 409);
});

test("only one concurrent initialization can succeed", async () => {
  const { store } = storeWith();
  const initialize = (id) => store.fetch(request("/teams/initialize", {
    method: "POST",
    body: {
      confirm: "INITIALIZE",
      data: { teams: [team(id)] },
      actor: { userId: "admin" },
      reason: `initialize ${id}`
    }
  }));
  const responses = await Promise.all([initialize("a"), initialize("b")]);
  assert.deepEqual(responses.map((response) => response.status).sort(), [201, 409]);
  const final = await (await store.fetch(request("/teams"))).json();
  assert.equal(final.teams.length, 1);
  assert.ok(["a", "b"].includes(final.teams[0].id));
});

test("blocks unexpectedly large mutation batches", async () => {
  const teams = Array.from({ length: 12 }, (_, index) => team(String(index)));
  const { store } = storeWith({ teams, revision: 1 });
  await store.fetch(request("/teams"));
  const result = await responseJson(await store.fetch(request("/teams/mutate", {
    method: "POST",
    body: {
      baseRevision: 1,
      actor: { userId: "editor" },
      operations: teams.slice(0, 2).map((item) => ({ type: "delete_team", teamId: item.id }))
    }
  })));
  assert.equal(result.status, 409);
  assert.equal(result.body.error, "destructive_change_requires_import");
  assert.equal((await (await store.fetch(request("/teams"))).json()).teams.length, 12);
});

test("detects imports whose content matches an older snapshot", async () => {
  const { store } = storeWith({ teams: [team("a", "Old")], revision: 1 });
  await store.fetch(request("/teams"));
  await store.fetch(request("/teams/mutate", {
    method: "POST",
    body: {
      baseRevision: 1,
      actor: { userId: "editor" },
      operations: [{ type: "upsert_team", team: team("a", "Current") }]
    }
  }));
  const preview = await responseJson(await store.fetch(request("/teams/import/preview", {
    method: "POST",
    body: { data: { teams: [team("a", "Old")] }, actor: { userId: "admin" } }
  })));
  assert.equal(preview.status, 200);
  assert.equal(preview.body.matchingRevision, 1);
});

test("binds import tokens to the administrator and current revision", async () => {
  const { store } = storeWith({ teams: [team("a", "A")], revision: 1 });
  await store.fetch(request("/teams"));
  const wrongActorPreview = await (await store.fetch(request("/teams/import/preview", {
    method: "POST",
    body: { data: { teams: [team("a", "Imported")] }, actor: { userId: "admin-1" } }
  }))).json();
  const wrongActor = await responseJson(await store.fetch(request("/teams/import/apply", {
    method: "POST",
    body: { token: wrongActorPreview.token, actor: { userId: "admin-2" }, reason: "wrong actor" }
  })));
  assert.equal(wrongActor.status, 409);
  assert.equal(wrongActor.body.error, "invalid_import_token");

  const stalePreview = await (await store.fetch(request("/teams/import/preview", {
    method: "POST",
    body: { data: { teams: [team("a", "Imported")] }, actor: { userId: "admin-1" } }
  }))).json();
  await store.fetch(request("/teams/mutate", {
    method: "POST",
    body: {
      baseRevision: 1,
      actor: { userId: "editor" },
      operations: [{ type: "upsert_team", team: team("a", "Changed first") }]
    }
  }));
  const staleApply = await responseJson(await store.fetch(request("/teams/import/apply", {
    method: "POST",
    body: { token: stalePreview.token, actor: { userId: "admin-1" }, reason: "stale import" }
  })));
  const reused = await responseJson(await store.fetch(request("/teams/import/apply", {
    method: "POST",
    body: { token: stalePreview.token, actor: { userId: "admin-1" }, reason: "retry stale import" }
  })));
  assert.equal(staleApply.status, 409);
  assert.equal(staleApply.body.error, "stale_version");
  assert.equal(reused.body.error, "invalid_import_token");
});
