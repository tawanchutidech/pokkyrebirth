import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";

const source = fs.readFileSync(
  new URL("../guild-war-hub.pages.dev/js/heroes-data.js", import.meta.url),
  "utf8"
);
const context = {};
vm.createContext(context);
vm.runInContext(
  `${source};globalThis.__heroCatalog = { HEROES, AWAKENED_HERO_IDS };`,
  context
);

const { HEROES, AWAKENED_HERO_IDS } = context.__heroCatalog;

test("every hero has an awaken boolean independent of its tier", () => {
  const awakenedIds = Array.from(AWAKENED_HERO_IDS).sort();
  const heroesMarkedAwakened = Array.from(HEROES, (hero) => hero)
    .filter((hero) => hero.awaken)
    .map((hero) => hero.id)
    .sort();

  assert.deepEqual(heroesMarkedAwakened, awakenedIds);

  for (const hero of HEROES) {
    assert.equal(typeof hero.awaken, "boolean", `${hero.id} needs an awaken boolean`);
  }
});
