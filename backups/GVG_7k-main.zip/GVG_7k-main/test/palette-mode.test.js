import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";

const source = fs.readFileSync(
  new URL("../guild-war-hub.pages.dev/js/editor.js", import.meta.url),
  "utf8"
);
const context = {};
vm.createContext(context);
vm.runInContext(`${source};globalThis.__editor = AdminEditor;`, context);

test("the character selector cycles standard, expanded, and hidden", () => {
  const editor = Object.assign({}, context.__editor, {
    paletteCollapsed: false,
    paletteExpanded: false,
  });

  assert.equal(editor.paletteToggleLabel(), "ขยายเมนู");
  assert.equal(editor.paletteBottomPadding(), "370px");

  editor.advancePaletteMode();
  assert.equal(editor.paletteExpanded, true);
  assert.equal(editor.paletteToggleLabel(), "ซ่อนคลัง");
  assert.equal(editor.paletteBottomPadding(), "min(520px, 58dvh)");

  editor.advancePaletteMode();
  assert.equal(editor.paletteCollapsed, true);
  assert.equal(editor.paletteToggleLabel(), "แสดงคลัง");

  editor.advancePaletteMode();
  assert.equal(editor.paletteCollapsed, false);
  assert.equal(editor.paletteExpanded, false);
  assert.equal(editor.paletteToggleLabel(), "ขยายเมนู");
});
