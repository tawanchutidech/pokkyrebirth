import assert from "node:assert/strict";
import test from "node:test";
import { regenerateCounterSummaries } from "../scripts/regenerate-counter-summaries.mjs";

const catalog = {
  rings: new Map([
    ["ring-6", "แหวนชุบ 6 ดาว"],
    ["ring-immortal", "แหวนอมตะ 6 ดาว"]
  ]),
  equipmentSets: new Map([["set-crit", "คริ"]])
};

test("regenerates assigned counter hero notes while preserving team notes", () => {
  const source = {
    teams: [{
      id: "team-1",
      counters: [{
        slots: { "1": "hero-a" },
        teamNote: "Keep this team-level guidance",
        gear: {
          "hero-a": {
            rings: { "1": "ring-6" },
            ringOverlays: { "1": "ring-immortal" },
            sets: { "1": "set-crit" },
            stats: { atk: "5000", critRate: "100" },
            note: "outdated"
          },
          "removed-hero": { note: "leave unassigned gear untouched" }
        }
      }]
    }]
  };

  const result = regenerateCounterSummaries(source, catalog);
  const counter = result.data.teams[0].counters[0];
  assert.equal(counter.teamNote, "Keep this team-level guidance");
  assert.equal(
    counter.gear["hero-a"].note,
    "แหวน: แหวนชุบ 6 ดาว ซ้อน แหวนอมตะ 6 ดาว\nเซ็ต: คริ\nโจมตี 5000 | คริ 100"
  );
  assert.equal(counter.gear["removed-hero"].note, "leave unassigned gear untouched");
  assert.equal(source.teams[0].counters[0].gear["hero-a"].note, "outdated");
  assert.equal(result.summary.updatedNoteCount, 1);
});

test("reports unknown saved gear IDs without deleting them", () => {
  const result = regenerateCounterSummaries({
    teams: [{ counters: [{
      slots: { "1": "hero-a" },
      gear: { "hero-a": { rings: { "1": "retired-ring" }, sets: { "1": "retired-set" } } }
    }] }]
  }, catalog);

  assert.deepEqual(result.summary.missingRingIds, ["retired-ring"]);
  assert.deepEqual(result.summary.missingEquipmentSetIds, ["retired-set"]);
  assert.equal(result.data.teams[0].counters[0].gear["hero-a"].note, "แหวน: retired-ring\nเซ็ต: retired-set");
});
