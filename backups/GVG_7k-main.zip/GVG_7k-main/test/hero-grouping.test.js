import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";

const source = fs.readFileSync(
  new URL("../guild-war-hub.pages.dev/js/editor.js", import.meta.url),
  "utf8"
);
const context = {};
vm.createContext(context);
vm.runInContext(`${source};globalThis.__editor = AdminEditor;`, context);

const editor = Object.assign({}, context.__editor, { selectedHero: null });
const heroes = [
  { id: "universal-rare", name: "Universal Rare", type: "Universal", awaken: false, tier: 4, img: "rare.webp" },
  { id: "universal-awake-rare", name: "Universal Awake Rare", type: "Universal", awaken: true, tier: 4, img: "awake-rare.webp" },
  { id: "universal-awake-legend", name: "Universal Awake Legend", type: "Universal", awaken: true, tier: 3, img: "awake-legend.webp" },
  { id: "universal-awake-legend-plus", name: "Universal Awake Legend+", type: "Universal", awaken: true, tier: 2, img: "awake-legend-plus.webp" },
  { id: "universal-legend-plus-plus", name: "Universal Legend++", type: "Universal", awaken: false, tier: 1, img: "legend-plus-plus.webp" },
  { id: "attack-legend-plus-plus", name: "Attack Legend++", type: "Attack", awaken: false, tier: 1, img: "attack.webp" },
  { id: "magic", name: "Magic", type: "Magic", awaken: false, tier: 2, img: "magic.webp" },
  { id: "defense", name: "Defense", type: "Defense", awaken: false, tier: 3, img: "defense.webp" },
  { id: "support", name: "Support", type: "Support", awaken: false, tier: 4, img: "support.webp" },
];

test("the character palette groups by type and prioritizes awakened higher tiers", () => {
  const markup = editor.heroGridHtml(heroes);
  const position = (text) => markup.indexOf(text);

  assert.ok(position("palette-type-attack") < position("palette-type-magic"));
  assert.ok(position("palette-type-magic") < position("palette-type-defense"));
  assert.ok(position("palette-type-defense") < position("palette-type-support"));
  assert.ok(position("palette-type-support") < position("palette-type-universal"));

  const universalOrder = [
    'data-hero="universal-awake-legend-plus"',
    'data-hero="universal-awake-legend"',
    'data-hero="universal-awake-rare"',
    'data-hero="universal-legend-plus-plus"',
    'data-hero="universal-rare"',
  ];
  for (let index = 1; index < universalOrder.length; index += 1) {
    assert.ok(position(universalOrder[index - 1]) < position(universalOrder[index]));
  }
});

test("pinned heroes appear once at the top in awaken, type, and tier order", () => {
  editor.pinnedHeroIds = new Set([
    "universal-rare",
    "universal-awake-legend",
    "attack-legend-plus-plus",
    "magic",
  ]);
  const markup = editor.heroGridHtml(heroes);
  const position = (text) => markup.indexOf(text);
  const pinnedOrder = [
    'data-hero="universal-awake-legend"',
    'data-hero="attack-legend-plus-plus"',
    'data-hero="magic"',
    'data-hero="universal-rare"',
  ];

  assert.ok(position("palette-pinned-header") < position(pinnedOrder[0]));
  for (let index = 1; index < pinnedOrder.length; index += 1) {
    assert.ok(position(pinnedOrder[index - 1]) < position(pinnedOrder[index]));
  }
  assert.equal(markup.match(/data-hero="universal-rare"/g)?.length, 1);
  assert.equal(markup.match(/data-hero="magic"/g)?.length, 1);

  editor.pinnedHeroIds = new Set();
});
