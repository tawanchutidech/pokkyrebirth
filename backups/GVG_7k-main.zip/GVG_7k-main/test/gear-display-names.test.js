import assert from "node:assert/strict";
import fs from "node:fs";
import test from "node:test";
import vm from "node:vm";

const gearSource = fs.readFileSync(new URL("../guild-war-hub.pages.dev/js/gear-data.js", import.meta.url), "utf8");
const gear = vm.runInNewContext(`${gearSource}\n;({ RINGS, EQUIPMENT_SETS, getRing, getEquipmentSet, ringMatchesQuery })`);

test("gear IDs stay stable while their display names are updated", () => {
  assert.equal(gear.RINGS.length, 36);
  assert.equal(gear.getRing("แหวนแห่งการคืนชีพระดับสูง")?.name, "แหวนชุบ 6 ดาว");
  assert.equal(gear.getRing("แหวนกำแพงเหล็กระดับสูง")?.name, "แหวนโล่ป้องกัน");
  assert.equal(gear.getEquipmentSet("นักฆ่า")?.name, "คริ");
  assert.equal(gear.getEquipmentSet("อัศวินศักดิ์สิทธิ")?.name, "เลือด");
});

test("legacy and display labels are both searchable", () => {
  const ring = gear.getRing("แหวนอมตะระดับสูง");
  assert.equal(gear.ringMatchesQuery(ring, "แหวนอมตะระดับสูง"), true);
  assert.equal(gear.ringMatchesQuery(ring, "แหวนอมตะ 6 ดาว"), true);
});
