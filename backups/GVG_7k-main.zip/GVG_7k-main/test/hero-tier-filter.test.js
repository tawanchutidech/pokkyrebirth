import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";

const source = fs.readFileSync(
  new URL("../guild-war-hub.pages.dev/js/editor.js", import.meta.url),
  "utf8"
);
const context = {
  heroMatchesQuery: () => true,
};
vm.createContext(context);
vm.runInContext(`${source};globalThis.__editor = AdminEditor;`, context);

const editor = Object.assign({}, context.__editor, { heroFilter: "" });
const heroes = [
  { id: "attack", type: "Attack" },
  { id: "magic", type: "Magic" },
  { id: "defense", type: "Defense" },
  { id: "support", type: "Support" },
  { id: "universal", type: "Universal" },
];

test("the character selector filters the five character types", () => {
  for (const [filter, expectedId] of [
    ["Attack", "attack"],
    ["Magic", "magic"],
    ["Defense", "defense"],
    ["Support", "support"],
    ["Universal", "universal"],
  ]) {
    editor.heroTypeFilter = filter;
    assert.deepEqual(
      heroes.filter((hero) => editor._heroVisible(hero)).map((hero) => hero.id),
      [expectedId]
    );
  }
});
