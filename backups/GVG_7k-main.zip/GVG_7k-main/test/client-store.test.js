import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";

const source = fs.readFileSync(new URL("../guild-war-hub.pages.dev/js/store.js", import.meta.url), "utf8") +
  ";globalThis.__Store=Store;";

async function loadWithDraft(draft, remote = { revision: 5, teams: [{ id: "server" }] }, gear = {}) {
  const memory = new Map(draft ? [["7kcombo_draft_v1", JSON.stringify(draft)]] : []);
  const context = {
    console: { ...console, warn: () => {} },
    Response,
    Blob,
    URL,
    setInterval,
    clearInterval,
    structuredClone,
    MAX_FORMATION_HEROES: 3,
    countFilledSlots: () => 0,
    getPattern: () => ({ back: [], front: [] }),
    getHero: () => null,
    RINGS: gear.rings || [],
    EQUIPMENT_SETS: gear.equipmentSets || [],
    fetch: async () => new Response(JSON.stringify(remote), {
      status: 200,
      headers: { "Content-Type": "application/json" }
    }),
    localStorage: {
      getItem: (key) => memory.get(key) ?? null,
      setItem: (key, value) => memory.set(key, value),
      removeItem: (key) => memory.delete(key)
    }
  };
  vm.createContext(context);
  vm.runInContext(source, context);
  await context.__Store.load();
  return context.__Store;
}

test("ignores legacy drafts", async () => {
  const store = await loadWithDraft({ teams: [{ id: "legacy" }] });
  assert.equal(store.data.teams[0].id, "server");
  assert.equal(store.hasStaleDraft(), true);
});

test("ignores drafts from a stale revision", async () => {
  const store = await loadWithDraft({
    format: 2,
    baseRevision: 4,
    data: { teams: [{ id: "stale" }] }
  });
  assert.equal(store.data.teams[0].id, "server");
  assert.equal(store.hasStaleDraft(), true);
});

test("restores a draft only from the exact current revision", async () => {
  const store = await loadWithDraft({
    format: 2,
    baseRevision: 5,
    data: { teams: [{ id: "draft" }] }
  });
  assert.equal(store.data.teams[0].id, "draft");
  assert.equal(store.hasStaleDraft(), false);
});

test("migrates legacy Awake IDs without dropping other shared teams", async () => {
  const store = await loadWithDraft(null, {
    revision: 8,
    teams: [
      {
        id: "keep",
        name: "ลูดี้ Awake / ซอรัน Awake / ยุนกอน Awake",
        enemy: { slots: { "1": "ลูดี้ Awake", "2": "ซอรัน Awake", "3": "ยุนกอน Awake" } },
        counters: [{
          name: "เฮเลเนีย Awake",
          slots: { "1": "เฮเลเนีย Awake" },
          gear: { "เฮเลเนีย Awake": { rings: { "1": "ring" } } },
          mergedFrom: [{ name: "ซอรัน Awake / ยุนกอน Awake" }]
        }]
      },
      { id: "preserve", enemy: { slots: { "1": "ลูดี้" } }, counters: [] }
    ]
  });

  assert.equal(store.data.teams.length, 2);
  const kept = JSON.parse(JSON.stringify(store.data.teams[0]));
  assert.deepEqual(kept.enemy.slots, { "1": "ลูดี้", "2": "ซอรัน", "3": "ยุนกอน" });
  assert.equal(kept.name, "ลูดี้ / ซอรัน / ยุนกอน");
  assert.deepEqual(kept.counters[0].slots, { "1": "เฮเลเนีย" });
  assert.ok(kept.counters[0].gear["เฮเลเนีย"]);
  assert.equal(kept.counters[0].mergedFrom[0].name, "ซอรัน / ยุนกอน");
  assert.equal(store.data.teams[1].id, "preserve");
});

test("does not remove canonical IDs after the migration is complete", async () => {
  const store = await loadWithDraft(null, {
    revision: 9,
    teams: [{ id: "canonical", enemy: { slots: { "1": "ลูดี้" } }, counters: [] }]
  });
  assert.equal(store.data.teams.length, 1);
  assert.equal(store.data.teams[0].enemy.slots["1"], "ลูดี้");
});

test("builds targeted operations instead of a full-dataset replacement", async () => {
  const store = await loadWithDraft(null, {
    revision: 7,
    teams: [{ id: "a", name: "A" }, { id: "b", name: "B" }]
  });
  store.data.teams = [{ id: "c", name: "C" }, { id: "a", name: "A2" }];
  const operations = JSON.parse(JSON.stringify(store.buildOperations()));
  assert.deepEqual(operations, [
    { type: "delete_team", teamId: "b" },
    { type: "upsert_team", team: { id: "c", name: "C" } },
    { type: "upsert_team", team: { id: "a", name: "A2" } },
    { type: "set_order", teamIds: ["c", "a"] }
  ]);
});

test("first-attack counter marker pins and unpins the matching counter", async () => {
  const store = await loadWithDraft(null, {
    revision: 10,
    teams: [{ id: "team-1", counters: [{ id: "counter-1", pinned: false }] }]
  });

  store.toggleCounterFirstAttackOpensHouse("team-1", 0);
  assert.equal(store.getTeam("team-1").counters[0].firstAttackOpensHouse, true);
  assert.equal(store.getTeam("team-1").counters[0].pinned, true);

  store.toggleCounterFirstAttackOpensHouse("team-1", 0);
  assert.equal(store.getTeam("team-1").counters[0].firstAttackOpensHouse, false);
  assert.equal(store.getTeam("team-1").counters[0].pinned, false);
});

test("does not rewrite stored notes when gear display labels change", async () => {
  const teams = Array.from({ length: 11 }, (_, index) => ({
    id: String(index),
    counters: [{
      gear: { hero: { note: "ใช้แหวนแห่งสุขภาพระดับสูงกับเซ็ตนักฆ่า" } }
    }]
  }));
  const store = await loadWithDraft(null, { revision: 11, teams });

  assert.equal(store.data.teams[0].counters[0].gear.hero.note, "ใช้แหวนแห่งสุขภาพระดับสูงกับเซ็ตนักฆ่า");
  assert.deepEqual(JSON.parse(JSON.stringify(store.buildOperations())), []);
});

test("recovers a legacy display-label draft without discarding real edits", async () => {
  const remote = {
    revision: 12,
    teams: [
      { id: "cosmetic", name: "แหวนแห่งการคืนชีพระดับสูง", counters: [] },
      { id: "edited", name: "Original", counters: [] }
    ]
  };
  const store = await loadWithDraft({
    format: 2,
    baseRevision: 12,
    data: {
      revision: 12,
      teams: [
        { id: "cosmetic", name: "แหวนชุบ 6 ดาว", counters: [] },
        { id: "edited", name: "Real editor change", counters: [] }
      ]
    }
  }, remote, {
    rings: [{ id: "แหวนแห่งการคืนชีพระดับสูง", name: "แหวนชุบ 6 ดาว" }]
  });

  assert.equal(store.getTeam("cosmetic").name, "แหวนแห่งการคืนชีพระดับสูง");
  assert.equal(store.getTeam("edited").name, "Real editor change");
  assert.deepEqual(JSON.parse(JSON.stringify(store.buildOperations())), [
    { type: "upsert_team", team: { id: "edited", name: "Real editor change", counters: [] } }
  ]);
});

test("records a production storage failure and does not load bundled fallback data", async () => {
  const memory = new Map();
  let fetchCount = 0;
  const context = {
    console: { ...console, warn: () => {} },
    Response,
    Blob,
    URL,
    location: { protocol: "https:", hostname: "example.com" },
    setInterval,
    clearInterval,
    structuredClone,
    MAX_FORMATION_HEROES: 3,
    countFilledSlots: () => 0,
    getPattern: () => ({ back: [], front: [] }),
    getHero: () => null,
    fetch: async () => {
      fetchCount += 1;
      return new Response(JSON.stringify({ error: "store_uninitialized" }), {
        status: 503,
        headers: { "Content-Type": "application/json" }
      });
    },
    localStorage: {
      getItem: (key) => memory.get(key) ?? null,
      setItem: (key, value) => memory.set(key, value),
      removeItem: (key) => memory.delete(key)
    }
  };
  vm.createContext(context);
  vm.runInContext(source, context);
  await context.__Store.load();
  assert.equal(context.__Store.loadError(), "store_uninitialized");
  assert.equal(context.__Store.data.teams.length, 0);
  assert.equal(fetchCount, 1);
});
