import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";

const source = fs.readFileSync(
  new URL("../guild-war-hub.pages.dev/js/list-view.js", import.meta.url),
  "utf8"
);
const context = {};
vm.createContext(context);
vm.runInContext(`${source};globalThis.__counterFinder = CounterFinder;`, context);

const finder = Object.assign({}, context.__counterFinder, { selectedHeroes: new Set() });
const heroes = [
  { id: "attack-rare", name: "Attack Rare", type: "Attack", awaken: false, tier: 4, img: "" },
  { id: "attack-awakened", name: "Attack Awakened", type: "Attack", awaken: true, tier: 2, img: "" },
  { id: "attack-legend-plus-plus", name: "Attack Legend++", type: "Attack", awaken: false, tier: 1, img: "" },
  { id: "magic", name: "Magic", type: "Magic", awaken: false, tier: 1, img: "" },
  { id: "defense", name: "Defense", type: "Defense", awaken: false, tier: 2, img: "" },
  { id: "support", name: "Support", type: "Support", awaken: false, tier: 3, img: "" },
  { id: "universal", name: "Universal", type: "Universal", awaken: false, tier: 4, img: "" },
];

test("the counter finder groups heroes by type and sorts awakened heroes first", () => {
  const markup = finder.heroPickerHtml(heroes);
  const position = (text) => markup.indexOf(text);

  assert.ok(position("palette-type-attack") < position("palette-type-magic"));
  assert.ok(position("palette-type-magic") < position("palette-type-defense"));
  assert.ok(position("palette-type-defense") < position("palette-type-support"));
  assert.ok(position("palette-type-support") < position("palette-type-universal"));

  assert.ok(position('data-finder-hero="attack-awakened"') < position('data-finder-hero="attack-legend-plus-plus"'));
  assert.ok(position('data-finder-hero="attack-legend-plus-plus"') < position('data-finder-hero="attack-rare"'));
});
