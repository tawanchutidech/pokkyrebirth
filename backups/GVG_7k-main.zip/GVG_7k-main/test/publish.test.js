import assert from "node:assert/strict";
import fs from "node:fs";
import test from "node:test";
import vm from "node:vm";

const source = fs.readFileSync(new URL("../guild-war-hub.pages.dev/js/publish.js", import.meta.url), "utf8") +
  ";globalThis.__Publisher=Publisher;";

test("a rejected publish shows the server error without downloading a JSON backup", async () => {
  let exportCount = 0;
  let message = "";
  const button = {
    innerHTML: "Publish",
    disabled: false,
    classList: { add() {}, remove() {} }
  };
  const context = {
    Response,
    document: { getElementById: () => button },
    fetch: async () => new Response(JSON.stringify({ error: "destructive_change_requires_import" }), {
      status: 409,
      headers: { "Content-Type": "application/json" }
    }),
    Store: {
      _remoteRevision: 7,
      normalizeNames() {},
      buildOperations: () => [{ type: "upsert_team", team: { id: "team-1" } }],
      exportJson: () => { exportCount += 1; }
    },
    toast: (value) => { message = value; }
  };
  vm.createContext(context);
  vm.runInContext(source, context);

  assert.equal(await context.__Publisher.publish(), false);
  assert.equal(exportCount, 0);
  assert.match(message, /Import/);
});
