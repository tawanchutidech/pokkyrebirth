import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";

const source = fs.readFileSync(
  new URL("../guild-war-hub.pages.dev/js/heroes-data.js", import.meta.url),
  "utf8"
);
const context = {};
vm.createContext(context);
vm.runInContext(`${source};globalThis.__heroes = HEROES;`, context);

const HEROES = Array.from(context.__heroes);
const FORMER_7K_HEROES = ["คริส", "วาเนสซา", "เจฟ", "สไปค์", "ราเชล", "ไอลีน"];
const RELOCATED_AWAKEN_HEROES = {
  "ซอรัน": ["Legend+", "public/images/Legend+/ซอรัน.webp"],
  "ซิลเวสตา": ["Legend+", "public/images/Legend+/ซิลเวสตา.webp"],
  "สกัลด์": ["Legend+", "public/images/Legend+/สกัลด์.webp"],
  "ออร์ก้า": ["Legend+", "public/images/Legend+/ออร์ก้า.webp"],
  "เคลมิส": ["Legend+", "public/images/Legend+/เคลมิส.webp"],
  "เดลโลนส์": ["Legend+", "public/images/Legend+/เดลโลนส์.webp"],
  "เฮฟเว่นเนีย": ["Rare", "public/images/Rare/เฮฟเว่นเนีย.webp"],
  "เฮเลเนีย": ["Rare", "public/images/Rare/เฮเลเนีย.webp"],
  "เอริส": ["Legend+", "public/images/Legend+/เอริส.webp"],
  "ลูดี้": ["Legend+", "public/images/Legend+/ลูดี้.webp"],
  "โดยอง": ["Legend+", "public/images/Legend+/โดยอง.webp"],
  "น็อกซ์": ["Legend", "public/images/Legend/น็อกซ์.webp"],
  "ยุนกอน": ["Legend+", "public/images/Legend+/ยุนกอน.png"],
};

test("Legend+ includes the former 7K heroes and uses its image folder", () => {
  assert.ok(!HEROES.some((hero) => hero.tierLabel === "Legend+ (7K)"));

  for (const id of FORMER_7K_HEROES) {
    const hero = HEROES.find((entry) => entry.id === id);

    assert.equal(hero?.tierLabel, "Legend+");
    assert.equal(hero?.img, `public/images/Legend+/${id}.webp`);
  }
});

test("the retired Awake tier is fully relocated with its image paths", () => {
  assert.ok(!HEROES.some((hero) => hero.tierLabel === "Awake"));

  for (const [id, [tierLabel, img]] of Object.entries(RELOCATED_AWAKEN_HEROES)) {
    const hero = HEROES.find((entry) => entry.id === id);

    assert.equal(hero?.tierLabel, tierLabel);
    assert.equal(hero?.img, img);
    assert.equal(hero?.awaken, true);
  }
});
