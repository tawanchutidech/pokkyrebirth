import { readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";

const args = process.argv.slice(2);
const valueFor = (flag) => {
  const index = args.indexOf(flag);
  return index >= 0 ? args[index + 1] : null;
};
const inputPath = valueFor("--input") || new URL("../guild-war-hub.pages.dev/data/teams.json", import.meta.url);
const outputPath = valueFor("--output");
const write = args.includes("--write");

export const AWAKE_HERO_RENAMES = {
  "ซอรัน Awake": "ซอรัน",
  "ซิลเวสตา Awake": "ซิลเวสตา",
  "สกัลด์ Awake": "สกัลด์",
  "ออร์ก้า Awake": "ออร์ก้า",
  "เคลมิส Awake": "เคลมิส",
  "เดลโลนส์ Awake": "เดลโลนส์",
  "เฮฟเว่นเนีย Awake": "เฮฟเว่นเนีย",
  "เฮเลเนีย Awake": "เฮเลเนีย",
  "เอริส Awake": "เอริส",
  "ลูดี้ Awake": "ลูดี้",
  "โดยอง Awake": "โดยอง",
  "น็อกซ์ Awake": "น็อกซ์",
  "ยุนกอน Awake": "ยุนกอน",
};

// These IDs identify the retired, non-Awake versions. Any team containing one
// is removed before the Awake ID is renamed to the same canonical value.
export const RETIRED_HERO_IDS = new Set([
  "ซิลเวสตา", "สกัลด์", "ออร์ก้า", "เคลมิส", "เดลโลนส์",
  "เฮฟเว่นเนีย", "เฮเลเนีย", "เอริส", "ลูดี้", "น็อกซ์",
]);

function containsRetiredHero(value) {
  if (typeof value === "string") return RETIRED_HERO_IDS.has(value);
  if (Array.isArray(value)) return value.some(containsRetiredHero);
  if (!value || typeof value !== "object") return false;
  return Object.entries(value).some(([key, child]) =>
    RETIRED_HERO_IDS.has(key) || containsRetiredHero(child)
  );
}

function renameHeroIds(value) {
  if (typeof value === "string") return AWAKE_HERO_RENAMES[value] || value;
  if (Array.isArray(value)) return value.map(renameHeroIds);
  if (!value || typeof value !== "object") return value;

  const renamed = {};
  for (const [key, child] of Object.entries(value)) {
    const canonicalKey = AWAKE_HERO_RENAMES[key] || key;
    if (Object.hasOwn(renamed, canonicalKey)) {
      throw new Error(`Cannot merge colliding hero key: ${canonicalKey}`);
    }
    renamed[canonicalKey] = renameHeroIds(child);
  }
  return renamed;
}

function renameTeamTitle(name) {
  return Object.entries(AWAKE_HERO_RENAMES).reduce(
    (title, [legacyId, canonicalId]) => title.replaceAll(legacyId, canonicalId),
    name
  );
}

function renameDisplayNames(value) {
  if (Array.isArray(value)) return value.map(renameDisplayNames);
  if (!value || typeof value !== "object") return value;

  return Object.fromEntries(Object.entries(value).map(([key, child]) => [
    key,
    key === "name" && typeof child === "string"
      ? renameTeamTitle(child)
      : renameDisplayNames(child),
  ]));
}

export function migrateTeams(data) {
  // Once no legacy Awake ID remains, this dataset has already been migrated.
  // Do not mistake its canonical IDs for retired non-Awake IDs on later runs.
  const hasLegacyAwakeIds = Object.keys(AWAKE_HERO_RENAMES).some((legacyId) => {
    const containsId = (value) => {
      if (value === legacyId) return true;
      if (Array.isArray(value)) return value.some(containsId);
      if (!value || typeof value !== "object") return false;
      return Object.entries(value).some(([key, child]) => key === legacyId || containsId(child));
    };
    return containsId(data.teams || []);
  });

  if (!hasLegacyAwakeIds) return { data: renameDisplayNames(data), removedTeamIds: [] };

  const removedTeamIds = [];
  const teams = [];

  for (const team of data.teams || []) {
    if (containsRetiredHero(team)) {
      removedTeamIds.push(team.id);
      continue;
    }
    teams.push(renameDisplayNames(renameHeroIds(team)));
  }

  return { data: { ...data, teams }, removedTeamIds };
}

const source = JSON.parse(await readFile(inputPath, "utf8"));
const result = migrateTeams(source);
console.log(JSON.stringify({
  mode: write ? "write" : "check",
  sourceTeamCount: source.teams?.length || 0,
  retainedTeamCount: result.data.teams.length,
  removedTeamIds: result.removedTeamIds,
}, null, 2));

if (write) await writeFile(outputPath ? resolve(outputPath) : inputPath, `${JSON.stringify(result.data, null, 2)}\n`);
