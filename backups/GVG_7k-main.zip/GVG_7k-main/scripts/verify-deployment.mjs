const origin = String(process.argv[2] || process.env.TEAM_VERIFY_ORIGIN || "").replace(/\/$/, "");
const expectedStoreId = process.argv[3] || process.env.TEAM_STORE_EXPECTED_ID;
const minimumRevision = Number(process.env.TEAM_MIN_REVISION || 0);
const minimumTeamCount = Number(process.env.TEAM_MIN_COUNT || 0);

if (!origin || !expectedStoreId) {
  console.error("Usage: npm run verify:deployment -- <origin> <expected-store-id>");
  process.exit(2);
}

async function get(path, type = "json") {
  const response = await fetch(`${origin}${path}`, {
    headers: { "Cache-Control": "no-cache" }
  });
  if (!response.ok) throw new Error(`${path} returned ${response.status}`);
  return type === "text" ? response.text() : response.json();
}

const [meta, teams, html] = await Promise.all([
  get("/api/teams/meta"),
  get("/api/teams"),
  get("/", "text")
]);

const failures = [];
if (meta.storeId !== expectedStoreId) failures.push(`store identity mismatch: ${meta.storeId}`);
if (!Number.isInteger(meta.revision) || meta.revision < 1) failures.push(`invalid revision: ${meta.revision}`);
if (meta.revision < minimumRevision) failures.push(`revision regressed below ${minimumRevision}`);
if (teams.revision !== meta.revision) failures.push("API data revision differs from metadata revision");
if (!Array.isArray(teams.teams)) failures.push("API teams value is not an array");
if (Array.isArray(teams.teams) && teams.teams.length !== meta.teamCount) failures.push("team count differs from metadata");
if (meta.teamCount < minimumTeamCount) failures.push(`team count fell below ${minimumTeamCount}`);
if (!/rollback-safety-1/.test(html)) failures.push("HTML does not reference rollback-safety client assets");

if (failures.length) {
  failures.forEach((failure) => console.error(`FAIL: ${failure}`));
  process.exit(1);
}

console.log(JSON.stringify({
  ok: true,
  origin,
  storeId: meta.storeId,
  revision: meta.revision,
  checksum: meta.checksum,
  teamCount: meta.teamCount,
  counterCount: meta.counterCount
}, null, 2));
