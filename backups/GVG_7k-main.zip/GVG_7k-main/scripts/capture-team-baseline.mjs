const origin = String(process.argv[2] || process.env.TEAM_VERIFY_ORIGIN || "").replace(/\/$/, "");
if (!origin) {
  console.error("Usage: npm run capture:baseline -- <origin>");
  process.exit(2);
}

const response = await fetch(`${origin}/api/teams`, { headers: { "Cache-Control": "no-cache" } });
if (!response.ok) {
  console.error(`/api/teams returned ${response.status}; do not deploy until the authoritative data is available`);
  process.exit(1);
}
const data = await response.json();
if (!Number.isInteger(data.revision) || !Array.isArray(data.teams)) {
  console.error("The current API did not return a valid revisioned team dataset");
  process.exit(1);
}
const counterCount = data.teams.reduce((count, team) => count + (Array.isArray(team.counters) ? team.counters.length : 0), 0);
console.log(JSON.stringify({
  origin,
  revision: data.revision,
  teamCount: data.teams.length,
  counterCount,
  verificationEnvironment: {
    TEAM_MIN_REVISION: String(data.revision),
    TEAM_MIN_COUNT: String(data.teams.length)
  }
}, null, 2));
