import { readFile, writeFile } from "node:fs/promises";
import { basename, dirname, extname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import vm from "node:vm";

const STAT_ORDER = [
  "atk", "def", "hp", "atkSpd", "critRate", "critDmg", "weakPt", "blockRate", "dmgRed",
  "hitRate", "effRes", "bonusDmg", "crush", "resilience", "recovery"
];

const STAT_LABELS = {
  atk: "โจมตี", def: "ป้องกัน", hp: "HP",
  atkSpd: "ความเร็ว", critRate: "คริ", critDmg: "ดาเมจคริ",
  weakPt: "จุดอ่อน", blockRate: "บล็อก", dmgRed: "ลดดาเมจ",
  hitRate: "ผลเข้าเป้า", effRes: "ต้านทานผล", bonusDmg: "เสริมความเสียหาย",
  crush: "บดขยี้", resilience: "ยึดหยุ่น", recovery: "ฟื้นคืน"
};

const args = process.argv.slice(2);

function valueFor(flag) {
  const index = args.indexOf(flag);
  return index >= 0 ? args[index + 1] : null;
}

function usage() {
  return [
    "Usage: node scripts/regenerate-counter-summaries.mjs --input <export.json> [--output <summarized.json>]",
    "",
    "Regenerates each assigned counter hero's note from its saved rings, sets, overlays, and stats.",
    "It preserves team-level notes and never overwrites the input file."
  ].join("\n");
}

export function loadGearCatalog(source) {
  const catalog = vm.runInNewContext(`${source}\n;({ RINGS, EQUIPMENT_SETS })`);
  return {
    rings: new Map(catalog.RINGS.map(({ id, name }) => [id, name])),
    equipmentSets: new Map(catalog.EQUIPMENT_SETS.map(({ id, name }) => [id, name]))
  };
}

export function summarizeHeroGear(gear, catalog, missingIds) {
  const rings = gear?.rings || {};
  const ringOverlays = gear?.ringOverlays || {};
  const sets = gear?.sets || {};
  const stats = gear?.stats || {};
  const displayRing = (id) => {
    if (catalog.rings.has(id)) return catalog.rings.get(id);
    missingIds.rings.add(id);
    return id;
  };
  const displaySet = (id) => {
    if (catalog.equipmentSets.has(id)) return catalog.equipmentSets.get(id);
    missingIds.equipmentSets.add(id);
    return id;
  };

  const ringNames = [1, 2, 3].map((slot) => {
    const mainId = rings[String(slot)];
    if (!mainId) return null;
    const mainName = displayRing(mainId);
    const overlayId = ringOverlays[String(slot)];
    return overlayId ? `${mainName} ซ้อน ${displayRing(overlayId)}` : mainName;
  }).filter(Boolean);
  const setNames = [1, 2, 3]
    .map((slot) => sets[String(slot)])
    .filter(Boolean)
    .map(displaySet);
  const statParts = STAT_ORDER
    .filter((id) => stats[id] !== undefined && stats[id] !== "")
    .map((id) => `${STAT_LABELS[id]} ${stats[id]}`);
  const lines = [];
  if (ringNames.length) lines.push(`แหวน: ${ringNames.join(", ")}`);
  if (setNames.length) lines.push(`เซ็ต: ${setNames.join(", ")}`);
  if (statParts.length) lines.push(statParts.join(" | "));
  return lines.join("\n");
}

export function regenerateCounterSummaries(data, catalog) {
  const result = structuredClone(data);
  const missingIds = { rings: new Set(), equipmentSets: new Set() };
  let counterCount = 0;
  let updatedNoteCount = 0;
  let unchangedNoteCount = 0;

  for (const team of result.teams || []) {
    for (const counter of team.counters || []) {
      counterCount += 1;
      const assignedHeroIds = new Set(Object.values(counter.slots || {}).filter(Boolean));
      for (const heroId of assignedHeroIds) {
        if (!counter.gear?.[heroId]) continue;
        const gear = counter.gear[heroId];
        const note = summarizeHeroGear(gear, catalog, missingIds);
        if (gear.note === note) {
          unchangedNoteCount += 1;
        } else {
          gear.note = note;
          updatedNoteCount += 1;
        }
      }
    }
  }

  return {
    data: result,
    summary: {
      teamCount: result.teams?.length || 0,
      counterCount,
      updatedNoteCount,
      unchangedNoteCount,
      missingRingIds: [...missingIds.rings].sort(),
      missingEquipmentSetIds: [...missingIds.equipmentSets].sort()
    }
  };
}

async function main() {
  const input = valueFor("--input");
  if (!input || args.includes("--help") || args.includes("-h")) {
    console.log(usage());
    process.exit(input ? 0 : 1);
  }

  const inputPath = resolve(input);
  const output = valueFor("--output");
  const parsed = basename(inputPath);
  const defaultOutput = resolve(dirname(inputPath), `${parsed.slice(0, -extname(parsed).length)}.counter-summaries.json`);
  const outputPath = resolve(output || defaultOutput);
  if (inputPath === outputPath) throw new Error("Refusing to overwrite the input file. Choose a different --output path.");

  const [dataSource, gearSource] = await Promise.all([
    readFile(inputPath, "utf8"),
    readFile(new URL("../guild-war-hub.pages.dev/js/gear-data.js", import.meta.url), "utf8")
  ]);
  const result = regenerateCounterSummaries(JSON.parse(dataSource), loadGearCatalog(gearSource));
  await writeFile(outputPath, `${JSON.stringify(result.data, null, 2)}\n`);
  console.log(JSON.stringify({ outputPath, ...result.summary }, null, 2));
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) await main();
