const AdminTools = {
  activities: [],
  teamChanges: [],

  async render() {
    const view = document.getElementById("toolsView");
    view.innerHTML = '<div class="tools-page"><p class="hint">กำลังโหลด Admin Tools…</p></div>';

    let accessCode = null;
    try {
      const response = await fetch("/api/access-code", { cache: "no-store", credentials: "include" });
      if (!response.ok) throw new Error("admin_required");
      accessCode = await response.json();
    } catch (_) {}

    const date = accessCode?.date
      ? new Date(`${accessCode.date}T00:00:00+07:00`).toLocaleDateString("th-TH", { weekday: "short", day: "numeric", month: "short", year: "numeric" })
      : "ไม่สามารถโหลดรหัสได้";
    const code = accessCode?.code || "—";

    view.innerHTML = `
      <div class="tools-page">
        <button class="detail-back-btn" id="toolsBackBtn">← กลับ</button>
        <h2 class="tools-title">🔧 Admin Tools</h2>

        ${Auth.isActualAdmin() ? `<div class="tools-card role-preview-card">
          <div class="tools-card-title">👁️ ตัวอย่างมุมมองตามบทบาท</div>
          <p class="hint">เลือกเพื่อดูหน้าจอแบบสมาชิกกิลด์ หรือ Researcher โดยไม่เปลี่ยนสิทธิ์จริงและไม่กระทบข้อมูลบนระบบ</p>
          <div class="role-preview-controls">
            <label for="rolePreviewSelect">แสดงมุมมองเป็น</label>
            <select id="rolePreviewSelect">
              <option value="admin" ${Auth.isPreviewingRole() ? "" : "selected"}>Admin</option>
              <option value="researcher" ${Auth.previewRole === "researcher" ? "selected" : ""}>Researcher</option>
              <option value="member" ${Auth.previewRole === "member" ? "selected" : ""}>สมาชิกกิลด์</option>
            </select>
          </div>
        </div>` : ""}

        <div class="tools-card">
          <div class="tools-card-title">🗓️ รหัสสมาชิกประจำวัน</div>
          <div class="tools-today">
            <div class="tools-today-date">${date}</div>
            <div class="tools-today-code">${code}</div>
            <div class="tools-today-actions">
              <button class="btn btn-primary" id="copyTodayBtn" ${accessCode ? "" : "disabled"}>📋 คัดลอกรหัส</button>
              <button class="btn btn-danger" id="resetTodayCodeBtn" ${accessCode ? "" : "disabled"}>↻ สร้างรหัสใหม่</button>
            </div>
          </div>
        </div>

        <div class="tools-card">
          <div class="tools-card-title">ℹ️ วิธีการใช้งาน</div>
          <p class="hint">รหัสสมาชิกจะเปลี่ยนอัตโนมัติทุกวันเวลาเที่ยงคืน (เวลาไทย)</p>
          <p class="hint">ปุ่ม <b>สร้างรหัสใหม่</b> จะเปลี่ยนรหัสของวันนี้ทันที รหัสเดิมใช้ไม่ได้ และผู้ที่เข้าด้วยรหัสสมาชิกจะถูกขอให้เข้าสู่ระบบใหม่ภายใน 15 วินาที</p>
        </div>

        <div class="tools-card revision-history-card">
          <div class="tools-card-title">🛡️ ประวัติและกู้คืนข้อมูลทีม</div>
          <p class="hint" id="revisionHistorySummary">กำลังโหลด revision history…</p>
          <div class="activity-log-scroll">
            <table class="tools-code-table activity-log-table">
              <thead><tr><th>Revision</th><th>เวลา</th><th>การทำงาน</th><th>ผู้ใช้</th><th>การเปลี่ยนแปลง</th><th>Checksum</th><th>เครื่องมือ</th></tr></thead>
              <tbody id="revisionHistoryRows"><tr><td colspan="7">กำลังโหลด…</td></tr></tbody>
            </table>
          </div>
          <div class="tools-today-actions">
            <button class="btn" id="refreshRevisionHistoryBtn" type="button">รีเฟรช revision</button>
          </div>
        </div>

        <div class="tools-card activity-card">
          <div class="tools-card-title">📊 Activity log</div>
          <p class="hint" id="activitySummary">กำลังโหลดข้อมูลการเข้าชม…</p>
          <div class="activity-log-scroll">
            <table class="tools-code-table activity-log-table">
              <thead><tr><th>เวลา</th><th>กิจกรรม</th><th>ผู้ใช้</th><th>กิลด์</th><th>IP</th><th>รายละเอียด</th><th>สถานที่</th></tr></thead>
              <tbody id="activityLogRows"><tr><td colspan="7">กำลังโหลด…</td></tr></tbody>
            </table>
          </div>
          <div class="tools-today-actions">
            <button class="btn" id="refreshActivityBtn" type="button">รีเฟรช activity</button>
            <button class="btn btn-primary" id="exportActivityBtn" type="button">ส่งออก CSV</button>
          </div>
        </div>
      </div>
    `;

    document.getElementById("toolsBackBtn").addEventListener("click", () => App.showList());
    document.getElementById("rolePreviewSelect")?.addEventListener("change", (event) =>
      App.setRolePreview(event.target.value)
    );

    document.getElementById("copyTodayBtn").addEventListener("click", () => {
      navigator.clipboard.writeText(code).then(() => toast("คัดลอกรหัสแล้ว"));
    });
    document.getElementById("resetTodayCodeBtn").addEventListener("click", () => {
      Modal.confirm("ต้องการสร้างรหัสสมาชิกใหม่สำหรับวันนี้ใช่ไหม? รหัสเก่าจะใช้ไม่ได้ทันที และสมาชิกที่ใช้รหัสอยู่จะต้องเข้าสู่ระบบใหม่", async () => {
        const response = await fetch("/api/access-code/reset", { method: "POST", credentials: "include" });
        if (!response.ok) {
          toast("ไม่สามารถสร้างรหัสใหม่ได้");
          return;
        }
        toast("สร้างรหัสสมาชิกใหม่แล้ว");
        this.render();
      });
    });

    document.getElementById("refreshActivityBtn").addEventListener("click", () => this.loadActivity());
    document.getElementById("exportActivityBtn").addEventListener("click", () => this.exportActivity());
    document.getElementById("refreshRevisionHistoryBtn").addEventListener("click", () => this.loadRevisionHistory());
    this.loadRevisionHistory();
    this.loadActivity();
  },

  async loadRevisionHistory() {
    const summary = document.getElementById("revisionHistorySummary");
    const rows = document.getElementById("revisionHistoryRows");
    if (!summary || !rows) return;
    summary.textContent = "กำลังโหลด revision history…";
    try {
      const response = await fetch("/api/teams/history?limit=100", { cache: "no-store", credentials: "include" });
      if (!response.ok) throw new Error("history_unavailable");
      const { currentRevision, changes = [] } = await response.json();
      this.teamChanges = changes;
      summary.textContent = `Revision ปัจจุบัน ${currentRevision} · เก็บประวัติ ${changes.length} รายการ`;
      rows.innerHTML = changes.length ? changes.map((item) => {
        const delta = item.change || {};
        const detail = `+${delta.addedIds?.length || 0} ~${delta.changedIds?.length || 0} −${delta.removedIds?.length || 0}`;
        return `<tr>
          <td>${this.escape(item.newRevision)}</td>
          <td>${this.escape(item.at ? new Date(item.at).toLocaleString("th-TH") : "-")}</td>
          <td>${this.escape(item.operation || "-")}<br><small>${this.escape(item.reason || "")}</small></td>
          <td>${this.escape(item.displayName || item.userId || "System")}</td>
          <td>${this.escape(detail)}</td>
          <td><code>${this.escape(String(item.newChecksum || "").slice(0, 12))}</code></td>
          <td><button class="btn" data-download-revision="${item.newRevision}">ดาวน์โหลด</button> <button class="btn btn-danger" data-restore-revision="${item.newRevision}" ${item.newRevision === currentRevision ? "disabled" : ""}>กู้คืน</button></td>
        </tr>`;
      }).join("") : '<tr><td colspan="7">ยังไม่มี revision history</td></tr>';
      rows.querySelectorAll("[data-download-revision]").forEach((button) =>
        button.addEventListener("click", () => this.downloadRevision(Number(button.dataset.downloadRevision)))
      );
      rows.querySelectorAll("[data-restore-revision]").forEach((button) =>
        button.addEventListener("click", () => this.restoreRevision(Number(button.dataset.restoreRevision)))
      );
    } catch (_) {
      summary.textContent = "ไม่สามารถโหลด revision history ได้";
      rows.innerHTML = '<tr><td colspan="7">ระบบประวัติข้อมูลไม่พร้อมใช้งาน</td></tr>';
    }
  },

  async downloadRevision(revision) {
    try {
      const response = await fetch(`/api/teams/history/${revision}`, { cache: "no-store", credentials: "include" });
      if (!response.ok) throw new Error("revision_not_found");
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `teams-revision-${revision}.json`;
      link.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (_) {
      toast("ไม่สามารถดาวน์โหลด revision นี้ได้");
    }
  },

  async restoreRevision(revision) {
    const reason = window.prompt(`ระบุเหตุผลในการกู้คืน revision ${revision} (จำเป็น)`, "")?.trim();
    if (!reason) return;
    if (!window.confirm(`ยืนยันกู้คืน revision ${revision}? ระบบจะสร้าง revision ใหม่และจะไม่ลบประวัติเดิม`)) return;
    try {
      const response = await fetch("/api/teams/restore", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ revision, reason })
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.error || "restore_failed");
      toast(`กู้คืนสำเร็จเป็น revision ${result.revision}`);
      setTimeout(() => location.reload(), 800);
    } catch (error) {
      window.alert("กู้คืนไม่สำเร็จ: " + error.message);
    }
  },

  async loadActivity() {
    const summary = document.getElementById("activitySummary");
    const rows = document.getElementById("activityLogRows");
    if (!summary || !rows) return;
    summary.textContent = "กำลังโหลดข้อมูลการเข้าชม…";

    try {
      const [activityResponse, usersResponse] = await Promise.all([
        fetch("/api/activity?limit=250", { credentials: "include" }),
        fetch("/api/users", { credentials: "include" })
      ]);
      if (!activityResponse.ok || !usersResponse.ok) throw new Error("admin_required");
      const [{ activities = [] }, { users = [] }] = await Promise.all([
        activityResponse.json(), usersResponse.json()
      ]);
      const visits = activities.filter((item) => item.type === "visit").length;
      const updates = activities.filter((item) => item.type === "team_update").length;
      this.activities = activities;
      summary.textContent = `สมาชิกที่ลงทะเบียน ${users.length} บัญชี · การแก้ไข ${updates} รายการ · การเข้าชม ${visits} รายการ · แสดงล่าสุด ${activities.length} รายการ`;
      rows.innerHTML = activities.length
        ? activities.map((item) => {
          const time = item.at ? new Date(item.at).toLocaleString("th-TH") : "-";
          const actor = item.displayName || item.email || "ไม่ระบุ";
          const userId = item.userId ? `<br><small>${this.escape(item.userId)}</small>` : "";
          return `<tr><td>${this.escape(time)}</td><td>${this.escape(this.activityLabel(item.type))}</td><td>${this.escape(actor)}${userId}</td><td>${this.escape(item.guild || "-")}</td><td>${this.escape(item.ip || "-")}</td><td>${this.escape(item.path || item.provider || "-")}</td><td>${this.locationCell(item.location)}</td></tr>`;
        }).join("")
        : '<tr><td colspan="7">ยังไม่มี activity log</td></tr>';
    } catch (_) {
      summary.textContent = "ไม่สามารถโหลด activity log ได้";
      rows.innerHTML = '<tr><td colspan="7">ต้องเข้าสู่ระบบด้วยบัญชี Admin ก่อน</td></tr>';
    }
  },

  async exportActivity() {
    try {
      const response = await fetch("/api/activity/export", { credentials: "include" });
      if (!response.ok) throw new Error("admin_required");
      const file = await response.blob();
      const downloadUrl = URL.createObjectURL(file);
      const link = document.createElement("a");
      link.href = downloadUrl;
      link.download = "gvg-activity-log.csv";
      link.click();
      setTimeout(() => URL.revokeObjectURL(downloadUrl), 1000);
      toast("ส่งออก Activity log แล้ว");
    } catch (_) {
      toast("ไม่สามารถส่งออก Activity log ได้");
    }
  },

  activityLabel(type) {
    return ({ login: "เข้าสู่ระบบ", visit: "เข้าชม", team_update: "บันทึกการแก้ไขทีม", team_change: "เปลี่ยนแปลงข้อมูลทีม" }[type] || type || "ไม่ระบุ");
  },

  locationCell(location) {
    if (!location) return "-";
    const place = [location.province, location.city, location.country].filter(Boolean).join(", ") || "ไม่ทราบตำแหน่ง";
    const latitude = Number(location.latitude);
    const longitude = Number(location.longitude);
    const hasCoordinates = Number.isFinite(latitude) && Number.isFinite(longitude);
    if (!hasCoordinates) return `${this.escape(place)}<br><small>โดยประมาณจาก IP</small>`;
    const mapUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${latitude},${longitude}`)}`;
    return `<a class="activity-map-link" href="${mapUrl}" target="_blank" rel="noopener noreferrer">${this.escape(place)}</a><br><small>โดยประมาณจาก IP · เปิดแผนที่</small>`;
  },

  escape(value) {
    return String(value ?? "").replace(/[&<>'"]/g, (char) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;"
    }[char]));
  }
};
