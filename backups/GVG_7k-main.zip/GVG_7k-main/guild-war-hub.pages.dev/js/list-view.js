// Renders the public team-list view: search, category filters, cards with
// an enemy-formation preview, and a full detail view for each team.
// Source files may contain legacy guild values; the interface uses one guild.
const DISPLAY_GUILD = "PokkyRebirth";

// Guilds a counter team can be tagged with, shown as badges on its card.
const GUILD_TAGS = [
  { id: "pokkyrebirth", label: "PokkyRebirth", cls: "badge-guild-pokkyrebirth" },
  { id: "priest", label: "Priest", cls: "badge-guild-priest" },
  { id: "gummy", label: "Gummy", cls: "badge-guild-gummy" },
  { id: "unleash", label: "Unleash", cls: "badge-guild-unleash" },
  { id: "everlasting", label: "Everlasting", cls: "badge-guild-everlasting" },
];
const LEGACY_GUILD_TAG_IDS = ["pokkyrebirth", "priest"];
const EVERLASTING_ONLY_GUILD_TAGS = ["everlasting"];
const EVERLASTING_COUNTER_VIEWER_GUILDS = new Set(["pokkyrebirth", "priest", "everlasting"]);

// Counters created before tagging existed have no `guilds` field — treat them as tagged with both.
function getCounterGuilds(c) {
  return Array.isArray(c.guilds) ? c.guilds : LEGACY_GUILD_TAG_IDS;
}

function isEverlastingOnlyCounter(counter) {
  const guilds = getCounterGuilds(counter);
  return guilds.length === EVERLASTING_ONLY_GUILD_TAGS.length &&
    guilds.every((guild) => guild === "everlasting");
}

// Admin and Researcher can manage every counter. An Everlasting-only counter
// is otherwise available only to the three guilds that may use it.
function canViewCounter(counter) {
  if (!isEverlastingOnlyCounter(counter)) return true;
  if (Auth.isAdmin() || Auth.isResearcher()) return true;
  return Auth.memberGuilds().some((guild) =>
    EVERLASTING_COUNTER_VIEWER_GUILDS.has(String(guild).toLowerCase())
  );
}

const ListView = {
  state: { query: "", category: "all", heroId: "", tab: "attack" },

  mount() {
    this.renderTabButtons();
    this.renderFilterPills();
    this.renderHeroTeamFilter();
    document.getElementById("searchInput").addEventListener("input", (e) => {
      this.state.query = e.target.value.trim().toLowerCase();
      this.render();
    });
    document.getElementById("counterFinderLaunch").addEventListener("click", () => CounterFinder.open());
    this.render();
  },

  renderTabButtons() {
    const wrap = document.getElementById("mainTabs");
    wrap.innerHTML = TEAM_TABS.map(
      (tb) =>
        `<button class="main-tab-btn ${tb.id === this.state.tab ? "active" : ""}" data-tab="${tb.id}">${tb.label}</button>`
    ).join("");
    wrap.querySelectorAll(".main-tab-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        this.state.tab = btn.dataset.tab;
        this.state.category = "all";
        this.renderTabButtons();
        this.renderFilterPills();
        this.render();
      });
    });
  },

  renderFilterPills() {
    const wrap = document.getElementById("filterPills");
    const catPills = [{ id: "all", label: "ทั้งหมด" }, ...CATEGORIES];
    wrap.innerHTML =
      catPills.map((c) =>
        `<button class="pill ${c.id === this.state.category ? "active" : ""}" data-cat="${c.id}">${c.label}</button>`
      ).join("");

    wrap.querySelectorAll(".pill[data-cat]").forEach((btn) => {
      btn.addEventListener("click", () => {
        this.state.category = btn.dataset.cat;
        this.renderFilterPills();
        this.render();
      });
    });
  },

  renderHeroTeamFilter() {
    const wrap = document.getElementById("heroTeamFilter");
    if (!wrap) return;
    const heroes = [...HEROES].sort((a, b) => a.name.localeCompare(b.name, "th"));
    wrap.innerHTML = `
      <label for="heroTeamFilterSelect">ตัวละครในทีม</label>
      <select id="heroTeamFilterSelect">
        <option value="">ทุกตัวละคร</option>
        ${heroes.map((hero) => `<option value="${hero.id}" ${hero.id === this.state.heroId ? "selected" : ""}>${escHtml(hero.name)}</option>`).join("")}
      </select>
      ${this.state.heroId ? `<button class="hero-filter-clear" id="heroTeamFilterClear" type="button">ล้างตัวกรอง</button>` : ""}
    `;
    document.getElementById("heroTeamFilterSelect").addEventListener("change", (event) => {
      this.state.heroId = event.target.value;
      this.renderHeroTeamFilter();
      this.render();
    });
    document.getElementById("heroTeamFilterClear")?.addEventListener("click", () => {
      this.state.heroId = "";
      this.renderHeroTeamFilter();
      this.render();
    });
  },

  renderEnemyPreview(enemy) {
    enemy = enemy || { pattern: "basic", slots: {} };
    const pattern = getPattern(enemy.pattern);
    return `<div class="enemy-preview">${renderFormationGrid(pattern, enemy.slots, {
      editable: false,
      dotOrder: enemy.dotOrder,
    })}</div>`;
  },

  // ── Detail view ──────────────────────────────────────────────────────────

  showDetail(teamId) {
    const team = Store.getTeam(teamId);
    if (!team) return;
    document.getElementById("listView").style.display = "none";
    const detailEl = document.getElementById("detailView");
    detailEl.style.display = "block";
    this.renderDetail(team);
    history.pushState(null, "", "#team/" + teamId);
    window.scrollTo(0, 0);
  },

  backToList() {
    document.getElementById("detailView").style.display = "none";
    document.getElementById("listView").style.display = "block";
    history.pushState(null, "", window.location.pathname + window.location.search);
  },

  renderDetail(team) {
    const detailEl = document.getElementById("detailView");
    const enemy = team.enemy || { pattern: "basic", slots: {} };
    const cat = (typeof CATEGORIES !== "undefined" ? CATEGORIES : []).find(
      (c) => c.id === team.category
    );
    const catLabel = cat ? cat.label : (team.category || "ทั่วไป");

    const counters = (team.counters || [])
      .map((counter, index) => ({ counter, index }))
      .filter(({ counter }) => !counter.hidden && canViewCounter(counter))
      .sort((a, b) => {
        const priority = (counter) => counter.firstAttackOpensHouse ? 2 : counter.pinned ? 1 : 0;
        return priority(b.counter) - priority(a.counter);
      });
    const counterHtml = counters.length
      ? `<div class="detail-counters-grid">${counters
          .map(({ counter, index }) => this.renderDetailCounterCard(counter, index, team.id))
          .join("")}</div>`
      : `<p class="detail-no-counters">ยังไม่มีทีมตอบโต้ที่แนะนำ</p>`;

    detailEl.innerHTML = `
      <div class="detail-top-bar">
        <button class="detail-back-btn" id="detailBackBtn">← กลับ</button>
        ${Auth.canEditTeams() ? `<button class="detail-edit-team-btn" data-add-counter-team="${team.id}" type="button">➕ ${(team.tab || "attack") === "defense" ? "เพิ่มทีมป้องกัน" : "เพิ่มทีมตอบโต้"}</button>` : ""}
        <button class="detail-share-btn" id="detailShareBtn">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
          คัดลอกลิงก์
        </button>
      </div>

      <div class="detail-enemy-box">
        <div class="detail-enemy-header">
          ${(team.tab || "attack") === "defense" ? "" : '<span class="detail-enemy-title">ทีมเป้าหมาย</span>'}
          <span class="badge-need">${escHtml(catLabel)}</span>
        </div>
        <div class="detail-enemy-name">${escHtml(team.name)}</div>
        <div class="detail-enemy-body">
          ${this.renderEnemyPreview(enemy)}
        </div>
      </div>

      <div class="detail-counters-heading">ทีมที่ใช้ต่อสู้ได้</div>
      ${counterHtml}
    `;

    document.getElementById("detailBackBtn").addEventListener("click", () => this.backToList());
    document.getElementById("detailShareBtn").addEventListener("click", () => {
      const url = location.origin + location.pathname + "#team/" + team.id;
      navigator.clipboard.writeText(url).then(() => toast("คัดลอกลิงก์แล้ว"));
    });

    detailEl.querySelectorAll("[data-edit-team]").forEach((btn) =>
      btn.addEventListener("click", () => {
        const counterIndex = btn.dataset.editCounter;
        App.openTeamEditor(
          btn.dataset.editTeam,
          counterIndex === undefined ? null : Number(counterIndex),
          { returnToDetailTeamId: team.id }
        );
      })
    );

    detailEl.querySelectorAll("[data-add-counter-team]").forEach((btn) =>
      btn.addEventListener("click", () => App.openCounterEditor(btn.dataset.addCounterTeam))
    );

    detailEl.querySelectorAll("[data-toggle-counter-pin]").forEach((btn) =>
      btn.addEventListener("click", () => {
        if (!Auth.canEditTeams()) return;
        Store.toggleCounterPinned(team.id, Number(btn.dataset.toggleCounterPin));
        const updatedTeam = Store.getTeam(team.id);
        if (updatedTeam) this.renderDetail(updatedTeam);
      })
    );

    detailEl.querySelectorAll("[data-detail-popup]").forEach((btn) => {
      const idx = parseInt(btn.dataset.detailPopup, 10);
      const tid = btn.dataset.popupTeam || team.id;
      btn.addEventListener("click", () => this.showDetailPopup(team.counters[idx], idx, { teamId: tid }));
    });

  },

  showDetailPopup(c, idx, opts) {
    if (!canViewCounter(c)) return;
    opts = opts || {};
    const pattern = getPattern(c.pattern);
    const slots = c.slots || {};
    const pets = c.pets || {};
    const gear = c.gear || {};
    const hasAnyPet = Object.values(pets).some(Boolean);

    const allPositions = [...(pattern.back || []), ...(pattern.front || [])];
    const heroIds = allPositions.filter((n) => slots[String(n)]).map((n) => slots[String(n)]);

    const HERO_STATS_arr     = typeof HERO_STATS      !== "undefined" ? HERO_STATS      : [];
    const HERO_STATS_EXT2_arr= typeof HERO_STATS_EXT2 !== "undefined" ? HERO_STATS_EXT2 : [];
    const HERO_STATS_EXT_arr = typeof HERO_STATS_EXT  !== "undefined" ? HERO_STATS_EXT  : [];

    const makeStatRows = (arr, stats) =>
      arr
        .map((s) => {
          const val = stats[s.id];
          const hasVal = val !== undefined && val !== "";
          return `<div class="hero-stat-row">
            <div class="hero-stat-icon">${s.icon}</div>
            <span class="hero-stat-label">${s.label}</span>
            <span class="dp-stat-value${hasVal ? "" : " dp-stat-empty"}">${hasVal ? escHtml(String(val)) : "—"}</span>
          </div>`;
        })
        .join("");

    const makeGearSlots = (gearObj, type) =>
      [1, 2, 3]
        .map((n) => {
          if (type === "ring") {
            const mainId = (gearObj.rings || {})[String(n)];
            const ovId = (gearObj.ringOverlays || {})[String(n)];
            const mainItem = mainId ? getRing(mainId) : null;
            const ovItem = ovId ? getRing(ovId) : null;
            if (!mainItem) return `<div class="gear-slot empty dp-gear-ro"></div>`;
            if (ovItem) return `<div class="ring-slot-pair">` +
              `<div class="gear-slot filled dp-gear-ro" title="${escHtml(mainItem.name)}"><img src="${mainItem.img}" alt="${escHtml(mainItem.name)}" draggable="false" loading="lazy"></div>` +
              `<div class="gear-slot ring-overlay-slot filled dp-gear-ro" title="${escHtml(ovItem.name)}"><img src="${ovItem.img}" alt="${escHtml(ovItem.name)}" draggable="false" loading="lazy"></div>` +
              `</div>`;
            return `<div class="gear-slot filled dp-gear-ro" title="${escHtml(mainItem.name)}"><img src="${mainItem.img}" alt="${escHtml(mainItem.name)}" draggable="false" loading="lazy"></div>`;
          }
          const id = (gearObj.sets || {})[String(n)];
          const item = id ? getEquipmentSet(id) : null;
          return item
            ? `<div class="gear-slot filled dp-gear-ro" title="${escHtml(item.name)}"><img src="${item.img}" alt="${escHtml(item.name)}" draggable="false" loading="lazy"></div>`
            : `<div class="gear-slot empty dp-gear-ro"></div>`;
        })
        .join("");

    const heroBlocks = heroIds
      .map((heroId) => {
        const hero = getHero(heroId);
        const g = gear[heroId] || {};
        const stats = g.stats || {};
        const note = g.note?.trim() || "";

        return `<div class="hero-gear-block">
          <div class="hero-gear-row">
            <div class="hero-gear-left">
              <div class="hero-gear-portrait">
                <img src="${hero?.img || ""}" alt="${escHtml(hero?.name || "")}" draggable="false" loading="lazy">
                <span>${escHtml(hero?.name || heroId)}</span>
              </div>
              <div class="hero-gear-slots">
                <div class="gear-type-row">
                  <span class="gear-type-label">แหวน</span>
                  <div class="gear-slots-grid">${makeGearSlots(g, "ring")}</div>
                </div>
                <div class="gear-type-row">
                  <span class="gear-type-label">เซ็ต</span>
                  <div class="gear-slots-grid">${makeGearSlots(g, "set")}</div>
                </div>
              </div>
            </div>
            <div class="hero-gear-note">
              <label>รายละเอียด</label>
              <div class="dp-note-text">${fmtNote(note)}</div>
            </div>
          </div>
          <div class="hero-stats-area">
            <div class="hero-stats-table">${makeStatRows(HERO_STATS_arr, stats)}</div>
            <div class="hero-stats-table">${makeStatRows(HERO_STATS_EXT2_arr, stats)}</div>
            <div class="hero-stats-table">${makeStatRows(HERO_STATS_EXT_arr, stats)}</div>
          </div>
        </div>`;
      })
      .join("");

    const popupTitle = c.name?.trim() ? escHtml(c.name.trim()) : `ทีมตอบโต้ที่ ${idx + 1}`;
    const teamId = opts.teamId || null;
    const popupEditBtn = teamId && Auth.canEditTeams()
      ? `<button class="detail-edit-team-btn" data-edit-team="${teamId}" data-edit-counter="${idx}" type="button">✏️ แก้ไขทีม</button>`
      : "";
    const popupTeamNote = c.teamNote?.trim()
      ? `<div class="dp-team-note">
          <div class="detail-note-tag">สรุปรายละเอียดทีม</div>
          <div class="detail-team-note-text">${escHtml(c.teamNote.trim())}</div>
        </div>`
      : "";

    const overlay = document.getElementById("counterDetailModal");
    const dpBox = overlay.querySelector(".dp-box");
    dpBox.innerHTML = `
      <div class="dp-header">
        <span class="dp-title">${popupTitle}</span>
        <div class="dp-header-actions">${popupEditBtn}<button class="dp-close-btn" id="dpCloseBtn" type="button">×</button></div>
      </div>
      <div class="dp-body">
        <div class="dp-formation-row counter-formation-area">
          ${renderFormationGrid(pattern, slots, { editable: false, dotOrder: c.dotOrder })}
          ${hasAnyPet ? this.renderDetailPetSlots(pets) : ""}
        </div>
        ${popupTeamNote}
        <div class="hero-gear-section">${heroBlocks}</div>
      </div>
    `;
    overlay.classList.add("open");

    document.getElementById("dpCloseBtn").addEventListener("click", () =>
      overlay.classList.remove("open")
    );
    dpBox.querySelectorAll("[data-edit-team]").forEach((btn) =>
      btn.addEventListener("click", () => {
        overlay.classList.remove("open");
        App.openTeamEditor(btn.dataset.editTeam, Number(btn.dataset.editCounter), {
          returnToDetailTeamId: btn.dataset.editTeam
        });
      })
    );
  },

  // Renders pet slots for detail view: only filled slots, empty sub-slots
  // are omitted and the remaining ones are centered via flex-wrap.
  renderDetailPetSlots(pets) {
    pets = pets || {};
    const mainId = pets["1"];
    const mainPet = mainId ? getPet(mainId) : null;
    const subPets = [2, 3, 4, 5]
      .map((n) => pets[String(n)])
      .filter(Boolean)
      .map((id) => getPet(id))
      .filter(Boolean);

    if (!mainPet && !subPets.length) return "";

    const mainHtml = mainPet
      ? `<div class="pet-slot main filled readonly"><img src="${mainPet.img}" alt="${escHtml(mainPet.name)}" draggable="false" loading="lazy"></div>`
      : "";

    const subHtml = subPets.length
      ? `<div class="detail-pet-subs">${subPets
          .map(
            (pet) =>
              `<div class="pet-slot sub filled readonly"><img src="${pet.img}" alt="${escHtml(pet.name)}" draggable="false" loading="lazy"></div>`
          )
          .join("")}</div>`
      : "";

    return `<div class="pet-slots-panel">
      <div class="pet-slots-title">สัตว์เลี้ยง</div>
      <div class="pet-slots-wrap">${mainHtml}${subHtml}</div>
    </div>`;
  },

  renderDetailCounterCard(c, idx, teamId) {
    const pattern = getPattern(c.pattern);
    const pets = c.pets || {};
    const hasAnyPet = Object.values(pets).some(Boolean);
    const slots = c.slots || {};
    const gear = c.gear || {};

    const allPositions = [...(pattern.back || []), ...(pattern.front || [])];
    const heroIds = allPositions
      .filter((n) => slots[String(n)])
      .map((n) => slots[String(n)]);

    // ── Note (auto-summary) per hero, always with hero name as header ──
    const heroParts = heroIds
      .map((heroId) => {
        const hero = getHero(heroId);
        const note = gear[heroId]?.note?.trim() || "";
        return note ? { name: hero?.name || heroId, note } : null;
      })
      .filter(Boolean);

    let noteHtml;
    if (!heroParts.length) {
      noteHtml = `<span class="detail-note-empty">ไม่มีข้อมูลรายละเอียด</span>`;
    } else {
      noteHtml = heroParts
        .map(
          (p) => `<div class="detail-note-hero-block">
            <span class="detail-note-hero-name">${escHtml(p.name)}</span>
            <span class="detail-note-text">${fmtNote(p.note)}</span>
          </div>`
        )
        .join("");
    }

    const teamNoteHtml = c.teamNote?.trim()
      ? `<div class="detail-team-note-block">
          <div class="detail-note-tag">สรุปรายละเอียดทีม</div>
          <div class="detail-team-note-text">${escHtml(c.teamNote.trim())}</div>
        </div>`
      : "";

    const moreBtnHtml = heroIds.length
      ? `<button class="detail-more-btn" data-detail-popup="${idx}" data-popup-team="${teamId || ""}" type="button">ดูรายละเอียดเพิ่มเติม</button>`
      : "";

    const cardName = c.name?.trim() || `ทีมตอบโต้ที่ ${idx + 1}`;
    const guildBadgesHtml = getCounterGuilds(c)
      .map((gid) => GUILD_TAGS.find((g) => g.id === gid))
      .filter(Boolean)
      .map((g) => `<span class="badge-guild ${g.cls}">${g.label}</span>`)
      .join("");
    const pinButtonHtml = Auth.canEditTeams()
      ? `<button class="btn btn-icon btn-pin ${c.pinned ? "active" : ""}" data-toggle-counter-pin="${idx}" type="button" title="${c.pinned ? "ยกเลิกการปักหมุด" : "ปักหมุดไว้บนสุด"}">📌</button>`
      : "";
    const firstAttackChipHtml = c.firstAttackOpensHouse
      ? '<span class="counter-first-attack-chip">ไม้แรกใช้เปิดบ้าน</span>'
      : "";
    return `<div class="detail-counter-card">
      <div class="detail-counter-label-row">
        <div class="detail-counter-label">${escHtml(cardName)}</div>
        ${(pinButtonHtml || firstAttackChipHtml || guildBadgesHtml) ? `<div class="detail-counter-guilds">${pinButtonHtml}${firstAttackChipHtml}${guildBadgesHtml}</div>` : ""}
      </div>
      <div class="counter-formation-area detail-formation-area">
        ${renderFormationGrid(pattern, slots, { editable: false, dotOrder: c.dotOrder })}
        ${hasAnyPet ? this.renderDetailPetSlots(pets) : ""}
      </div>
      <div class="detail-counter-footer">
        ${teamNoteHtml}
        <div class="detail-note-tag">สรุปรายละเอียดแบบย่อ</div>
        <div class="detail-counter-note">${noteHtml}</div>
        <div class="detail-footer-actions">
          ${Auth.canEditTeams() ? `<button class="detail-edit-team-btn" data-edit-team="${teamId}" data-edit-counter="${idx}" type="button">✏️ แก้ไขทีม</button>` : ""}
          ${moreBtnHtml}
        </div>
      </div>
    </div>`;
  },

  // ── List view ─────────────────────────────────────────────────────────────

  matchesQuery(team, q) {
    if (!q) return true;
    if (team.name.toLowerCase().includes(q)) return true;
    const formations = [team.enemy, ...(team.counters || []).filter((counter) => canViewCounter(counter))];
    const ids = formations.flatMap((formation) => Object.values(formation?.slots || {}));
    return ids.some((id) => {
      const hero = id ? getHero(id) : null;
      return hero && heroMatchesQuery(hero, q);
    });
  },

  renderTeamControls(team) {
    if (!Auth.canEditTeams()) return "";
    const eyeIcon = team.hidden
      ? `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>`
      : `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`;
    return `<div class="team-card-controls" aria-label="จัดการทีม">
      <button class="btn btn-icon btn-pin ${team.pinned ? "active" : ""}" data-card-toggle-pin="${team.id}" type="button" title="${team.pinned ? "ยกเลิกการปักหมุด" : "ปักหมุดไว้บนสุด"}">📌</button>
      <button class="btn btn-icon btn-eye ${team.hidden ? "btn-eye-off" : ""}" data-card-toggle-hidden="${team.id}" type="button" title="${team.hidden ? "แสดงในหน้าหลัก" : "ซ่อนจากหน้าหลัก"}">${eyeIcon}</button>
      <button class="btn btn-icon" data-card-edit="${team.id}" type="button" title="แก้ไขทีม"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg></button>
      <button class="btn btn-icon btn-icon-danger" data-card-delete="${team.id}" type="button" title="ลบทีม"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg></button>
    </div>`;
  },

  getFilteredTeams() {
    const { query, category, heroId, tab } = this.state;
    return Store.getTeams().filter((t) => {
      if (t.hidden) return false;
      const tabOk   = (t.tab || "attack") === tab;
      const catOk   = category === "all" || t.category === category;
      const formations = [t.enemy, ...(t.counters || []).filter((counter) => canViewCounter(counter))];
      const heroOk = !heroId || formations.some((formation) =>
        Object.values(formation?.slots || {}).includes(heroId)
      );
      return tabOk && catOk && heroOk && this.matchesQuery(t, query);
    }).sort((a, b) => Number(Boolean(b.pinned)) - Number(Boolean(a.pinned)));
  },

  render() {
    const grid  = document.getElementById("teamGrid");
    const empty = document.getElementById("emptyState");

    const teams = this.getFilteredTeams();
    document.getElementById("filterCount").textContent = `ทั้งหมด ${teams.length} รายการ`;
    if (!teams.length) {
      grid.innerHTML = "";
      empty.style.display = "block";
      return;
    }
    empty.style.display = "none";
    grid.innerHTML = teams
      .map((team) => {
        const preview   = team.enemy;
        const accessibleCounters = (team.counters || []).filter((counter) => canViewCounter(counter));
        const visibleCounters = accessibleCounters.filter((c) => !c.hidden).length;
        const hiddenCounters = accessibleCounters.length - visibleCounters;
        const countLabel = visibleCounters === 0 && accessibleCounters.length === 0 ? "" :
          hiddenCounters > 0
            ? `${visibleCounters} ทีมแก้ (ซ่อน ${hiddenCounters})`
            : `${visibleCounters} ทีมแก้`;
        return `
          <div class="team-card" data-id="${team.id}">
            <div class="team-card-top">
              <div class="card-top-left">
              ${team.pinned ? `<span class="badge-pinned">📌 ปักหมุด</span>` : ""}
            </div>
            <div class="team-card-top-right">
              ${countLabel ? `<span class="counter-count">${countLabel}</span>` : ""}
              ${this.renderTeamControls(team)}
            </div>
          </div>
          <div class="enemy-name">${escHtml(team.name)}</div>
          <div class="team-card-body cat-bg cat-bg-${team.category || "other"}">
            ${this.renderEnemyPreview(preview)}
          </div>
          <div class="card-footer">
            <button class="view-more-btn" data-view="${team.id}">ดูเพิ่ม ›</button>
          </div>
        </div>`;
      })
      .join("");

    grid.querySelectorAll("[data-view]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const team = Store.getTeam(btn.dataset.view);
        if (!team) return;
        this.showDetail(btn.dataset.view);
      });
    });
    grid.querySelectorAll("[data-card-toggle-pin]").forEach((btn) =>
      btn.addEventListener("click", () => {
        Store.toggleTeamPinned(btn.dataset.cardTogglePin);
        this.render();
      })
    );
    grid.querySelectorAll("[data-card-toggle-hidden]").forEach((btn) =>
      btn.addEventListener("click", () => {
        Store.toggleTeamHidden(btn.dataset.cardToggleHidden);
        this.render();
      })
    );
    grid.querySelectorAll("[data-card-edit]").forEach((btn) =>
      btn.addEventListener("click", () => App.openTeamEditor(btn.dataset.cardEdit))
    );
    grid.querySelectorAll("[data-card-delete]").forEach((btn) =>
      btn.addEventListener("click", () => {
        const team = Store.getTeam(btn.dataset.cardDelete);
        Modal.confirm(`ลบทีม "${team?.name || ""}" ใช่หรือไม่?`, () => {
          Store.deleteTeam(btn.dataset.cardDelete);
          this.render();
          toast("ลบทีมแล้ว");
        });
      })
    );
  }
};

const CounterFinder = {
  selectedHeroes: new Set(),
  heroQuery: "",

  open() {
    this.selectedHeroes.clear();
    this.heroQuery = "";
    const modal = document.getElementById("counterFinderModal");
    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
    this.render();
  },

  close() {
    const modal = document.getElementById("counterFinderModal");
    modal.classList.remove("open");
    modal.setAttribute("aria-hidden", "true");
  },

  getHeroOptions() {
    const heroes = new Map(
      (typeof HEROES === "undefined" ? [] : HEROES).map((hero) => [hero.id, hero])
    );

    // Include legacy heroes referenced by saved counter teams even when they
    // are no longer in the catalog.
    Store.getTeams().forEach((team) => (team.counters || []).filter((counter) => canViewCounter(counter)).forEach((counter) => {
      Object.values(counter.slots || {}).filter(Boolean).forEach((id) => {
        if (!heroes.has(id)) heroes.set(id, { id, name: id, type: "Other", awaken: false, tier: 99, img: "" });
      });
    }));

    return [...heroes.values()];
  },

  sortHeroesByPaletteOrder(heroes) {
    return [...heroes].sort((a, b) =>
      Number(b.awaken) - Number(a.awaken) ||
      a.tier - b.tier ||
      a.name.localeCompare(b.name, "th")
    );
  },

  heroPickerHtml(heroes) {
    const typeGroups = [
      { type: "Attack", className: "attack" },
      { type: "Magic", className: "magic" },
      { type: "Defense", className: "defense" },
      { type: "Support", className: "support" },
      { type: "Universal", className: "universal" },
      { type: "Other", className: "other", label: "อื่นๆ" },
    ];

    return typeGroups.map((group) => {
      const groupedHeroes = this.sortHeroesByPaletteOrder(
        heroes.filter((hero) => (hero.type || "Other") === group.type)
      );
      if (!groupedHeroes.length) return "";

      return `<div class="palette-type-header palette-type-${group.className}">${group.label || group.type}</div>` +
        groupedHeroes.map((hero) => `
          <button class="counter-finder-hero ${this.selectedHeroes.has(hero.id) ? "selected" : ""}" data-finder-hero="${escHtml(hero.id)}" type="button" aria-pressed="${this.selectedHeroes.has(hero.id)}">
            ${hero.img ? `<img src="${hero.img}" alt="" loading="lazy">` : "<span class=\"counter-finder-no-image\">?</span>"}
            <span>${escHtml(hero.name)}</span>
          </button>`).join("");
    }).join("");
  },

  getCounterHeroes(counter) {
    return Object.values(counter.slots || {}).filter(Boolean);
  },

  getResults() {
    return Store.getTeams()
      .filter((team) => !team.hidden && (team.tab || "attack") === "attack")
      .map((team) => ({
        team,
        counters: (team.counters || [])
          .map((counter, index) => ({ counter, index }))
          .filter(({ counter }) => {
            const heroes = this.getCounterHeroes(counter);
            return !counter.hidden && canViewCounter(counter) &&
              heroes.length > 0 &&
              heroes.every((heroId) => !this.selectedHeroes.has(heroId));
          }),
      }))
      .filter(({ counters }) => counters.length > 0);
  },

  heroLabel(heroId) {
    const hero = getHero(heroId);
    const name = hero?.name || heroId;
    return `<span class="counter-finder-hero-label">${hero?.img ? `<img src="${hero.img}" alt="" loading="lazy">` : ""}<span>${escHtml(name)}</span></span>`;
  },

  renderCounter(counter, index) {
    const pattern = getPattern(counter.pattern);
    const label = counter.name?.trim() || `ทีมแก้ที่ ${index + 1}`;
    return `
      <article class="counter-finder-counter">
        <div class="counter-finder-counter-heading">
          <span>${escHtml(label)}</span>
        </div>
        <div class="counter-finder-formation">
          ${renderFormationGrid(pattern, counter.slots || {}, { editable: false, dotOrder: counter.dotOrder })}
        </div>
        <div class="counter-finder-hero-labels">
          ${this.getCounterHeroes(counter).map((id) => this.heroLabel(id)).join("")}
        </div>
      </article>`;
  },

  render() {
    const modal = document.getElementById("counterFinderModal");
    // Searching used to replace the whole dialog on every keystroke. Keep the
    // caret and focus on the replacement input so a search can be typed
    // continuously (including on touch keyboards).
    const activeSearch = document.activeElement?.id === "counterFinderHeroSearch"
      ? document.activeElement
      : null;
    const selectionStart = activeSearch?.selectionStart ?? 0;
    const selectionEnd = activeSearch?.selectionEnd ?? selectionStart;
    const normalizedQuery = this.heroQuery.trim().toLocaleLowerCase();
    const heroes = this.getHeroOptions().filter((hero) =>
      !normalizedQuery || hero.name.toLocaleLowerCase().includes(normalizedQuery)
    );
    const results = this.getResults();
    const counterCount = results.reduce((total, result) => total + result.counters.length, 0);
    const selectedCount = this.selectedHeroes.size;

    modal.innerHTML = `
      <div class="modal-box counter-finder-box" role="dialog" aria-modal="true" aria-label="ค้นหาทีมแก้จากตัวที่เหลือ">
        <div class="counter-finder-header">
          <div>
            <h2>ค้นหาทีมแก้จากตัวที่เหลือ</h2>
            <p>เลือกตัวละครที่ใช้งานไปแล้ว ระบบจะตัดทีมแก้ที่ต้องใช้ตัวละครเหล่านั้นออก</p>
          </div>
          <button class="dp-close-btn" data-finder-close type="button" aria-label="ปิด">×</button>
        </div>

        <div class="counter-finder-controls">
          <label class="counter-finder-search">
            <span>🔍</span>
            <input id="counterFinderHeroSearch" type="search" placeholder="ค้นหาตัวละคร" value="${escHtml(this.heroQuery)}">
          </label>
          <button class="btn" id="counterFinderClear" type="button" ${selectedCount ? "" : "disabled"}>ล้างที่เลือก</button>
        </div>
        <div class="counter-finder-selection">ใช้ไปแล้ว <b>${selectedCount}</b> ตัว · แสดงตัวละคร ${heroes.length} ตัว</div>
        <div class="counter-finder-heroes">
          ${this.heroPickerHtml(heroes) || '<p class="hint">ไม่พบตัวละครที่ตรงกับคำค้นหา</p>'}
        </div>

        <div class="counter-finder-results-header">
          <div>
            <h3>ทีมที่ยังบุกได้</h3>
            <p>พบ ${results.length} ทีมเป้าหมาย · ${counterCount} ทีมแก้ที่ใช้ได้</p>
          </div>
        </div>
        <div class="counter-finder-results">
          ${results.map(({ team, counters }) => `
            <section class="counter-finder-result">
              <div class="counter-finder-target">
                <div>
                  <span class="badge-need">ทีมเป้าหมาย</span>
                  <strong>${escHtml(team.name || "ไม่มีชื่อทีม")}</strong>
                  <small>${counters.length} ทีมแก้ที่ใช้ได้</small>
                </div>
                <button class="btn btn-small" data-finder-open-team="${team.id}" type="button">ดูทีม</button>
              </div>
              <div class="counter-finder-counter-grid">
                ${counters.map(({ counter, index }) => this.renderCounter(counter, index)).join("")}
              </div>
            </section>`).join("") || '<div class="counter-finder-empty">ไม่พบทีมแก้ที่ใช้ตัวละครที่เหลืออยู่ ลองเอาตัวละครออกจากรายการที่เลือก</div>'}
        </div>
      </div>`;

    const searchInput = modal.querySelector("#counterFinderHeroSearch");

    modal.querySelector("[data-finder-close]").addEventListener("click", () => this.close());
    modal.onclick = (event) => {
      if (event.target === modal) this.close();
    };
    searchInput.addEventListener("input", (event) => {
      this.heroQuery = event.target.value;
      this.render();
    });
    modal.querySelector("#counterFinderClear").addEventListener("click", () => {
      this.selectedHeroes.clear();
      this.render();
    });
    modal.querySelectorAll("[data-finder-hero]").forEach((button) => {
      button.addEventListener("click", () => {
        const id = button.dataset.finderHero;
        if (this.selectedHeroes.has(id)) this.selectedHeroes.delete(id);
        else this.selectedHeroes.add(id);
        this.render();
      });
    });
    modal.querySelectorAll("[data-finder-open-team]").forEach((button) => {
      button.addEventListener("click", () => {
        this.close();
        ListView.showDetail(button.dataset.finderOpenTeam);
      });
    });

    if (activeSearch) {
      searchInput.focus({ preventScroll: true });
      searchInput.setSelectionRange(selectionStart, selectionEnd);
    }
  },
};

function escHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function fmtNote(note) {
  if (!note) return "";
  return note.split("\n").map(line => {
    const m = line.match(/^(แหวน:|เซ็ต:)([\s\S]*)/);
    if (m) return `<span class="note-keyword">${escHtml(m[1])}</span>${escHtml(m[2])}`;
    return escHtml(line);
  }).join("\n");
}
