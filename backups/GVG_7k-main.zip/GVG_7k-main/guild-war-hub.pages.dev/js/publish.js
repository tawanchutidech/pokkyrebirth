// Publishes the current data to the same-origin Worker. The Worker verifies
// the Discord admin session before updating its persistent team store.
const Publisher = {
  _busy: false,

  async publish() {
    if (this._busy) return false;
    this._busy = true;
    Store.normalizeNames();
    const btn = document.getElementById("publishBtn");
    const origHtml = btn.innerHTML;
    btn.disabled = true;
    btn.classList.add("btn-publishing");

    try {
      const operations = Store.buildOperations();
      if (!operations.length) {
        Store.clearDraft();
        toast("ไม่มีข้อมูลที่เปลี่ยนแปลง");
        return true;
      }
      const response = await fetch("/api/teams/mutate", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          baseRevision: Store._remoteRevision,
          operations
        })
      });
      if (!response.ok) {
        const error = await response.json().catch(() => ({}));
        throw new Error(
          error.error === "editor_required"
            ? "ต้องเข้าสู่ระบบ Discord ด้วยบัญชี Researcher หรือ Admin"
            : error.error === "stale_version"
              ? "มีผู้แก้ไขข้อมูลก่อนหน้า กรุณารีเฟรชหน้า แล้วนำการแก้ไขของคุณมาปรับกับข้อมูลล่าสุด"
              : error.error === "store_identity_mismatch"
                ? "ระบบตรวจพบคลังข้อมูลผิดชุดและปฏิเสธการบันทึก"
                : error.error === "store_uninitialized"
                  ? "คลังข้อมูลยังไม่ได้เริ่มต้น ระบบจึงปฏิเสธการบันทึก"
                  : error.error === "destructive_change_requires_import"
                    ? "การเปลี่ยนแปลงลบหรือแก้ไขข้อมูลจำนวนมากเกินเกณฑ์ กรุณาใช้ Import แบบตรวจสอบโดย Admin"
                    : error.error === "historical_snapshot_requires_restore"
                      ? `ข้อมูลตรงกับ revision เก่า ${error.matchingRevision} กรุณาใช้เมนูกู้คืนใน Admin Tools`
              : "บันทึกข้อมูลบนแพลตฟอร์มไม่สำเร็จ"
        );
      }

      const saved = await response.json();
      Store.acceptPublished(saved);
      btn.classList.remove("btn-publishing");
      btn.classList.add("btn-published");
      toast("บันทึกข้อมูลบนแพลตฟอร์มแล้ว");
      setTimeout(() => btn.classList.remove("btn-published"), 2500);
      return true;
    } catch (error) {
      toast(error.message || "บันทึกข้อมูลบนแพลตฟอร์มไม่สำเร็จ");
      return false;
    } finally {
      btn.innerHTML = origHtml;
      btn.classList.remove("btn-publishing");
      btn.disabled = false;
      this._busy = false;
    }
  },

  async previewImport(data) {
    const response = await fetch("/api/teams/import/preview", {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ data })
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(result.message || result.error || "import_preview_failed");
    return result;
  },

  async applyImport(token, reason, confirmDestructive) {
    const response = await fetch("/api/teams/import/apply", {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token, reason, confirmDestructive })
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(result.message || result.error || "import_apply_failed");
    Store.acceptPublished(result);
    return result;
  }
};
