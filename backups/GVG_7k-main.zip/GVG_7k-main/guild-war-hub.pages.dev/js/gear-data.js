// IDs intentionally remain the legacy filenames so saved team data and icon
// paths stay compatible while the app shows the clearer display names.
const RING_DEFINITIONS = [
  { id: "แหวนแห่งการคืนชีพระดับสูง", name: "แหวนชุบ 6 ดาว" },
  { id: "แหวนแห่งการคืนชีพ", name: "แหวนชุบ 5 ดาว" },
  { id: "แหวนแห่งการคืนชีพเก่า", name: "แหวนชุบ 4 ดาว" },
  { id: "แหวนอมตะระดับสูง", name: "แหวนอมตะ 6 ดาว" },
  { id: "แหวนอมตะ", name: "แหวนอมตะ 5 ดาว" },
  { id: "แหวนอมตะเก่า", name: "แหวนอมตะ 4 ดาว" },
  { id: "แหวนแห่งอำนาจระดับสูง", name: "แหวนอำนาจ 6 ดาว" },
  { id: "แหวนแห่งอำนาจ", name: "แหวนอำนาจ 5 ดาว" },
  { id: "แหวนแห่งอำนาจเก่า", name: "แหวนอำนาจ 4 ดาว" },
  { id: "แหวนแห่งพลังกายใจระดับสูง", name: "แหวนโล่โจมตี" },
  { id: "แหวนกำแพงเหล็กระดับสูง", name: "แหวนโล่ป้องกัน" },
  { id: "แหวนแห่งสุขภาพระดับสูง", name: "แหวนโล่เลือด" },
  { id: "แหวนช่วงชิงปราสาทระดับสูง", name: "แหวน 1-3 เป้า" },
  { id: "แหวนแห่งการปราบปรามระดับสูง", name: "แหวนบอส" },
  { id: "แหวนแห่งการทำลายล้างระดับสูง", name: "แหวน 4-5 เป้า" },
  { id: "แหวนเลือดนักสู้ระดับสูง", name: "แหวนเด้งเลือด" },
  { id: "แหวนเดธ", name: "แหวนเดธ" },
  { id: "แหวนขจัดบัพ", name: "แหวนขจัดบัพ" },
  { id: "แหวนตาบอด", name: "แหวนตาบอด" },
  { id: "แหวนติดพิษ", name: "แหวนติดพิษ" },
  { id: "แหวนน้ำแข็ง", name: "แหวนน้ำแข็ง" },
  { id: "แหวนสตั๊น", name: "แหวนสตั๊น" },
  { id: "แหวนหลับไหล", name: "แหวนหลับไหล" },
  { id: "แหวนอัมพาต", name: "แหวนอัมพาต" },
  { id: "แหวนเร่งเทิร์น", name: "แหวนเร่งเทิร์น" },
  { id: "แหวนเลือดไหล", name: "แหวนเลือดไหล" },
  { id: "แหวนใบ้", name: "แหวนใบ้" },
  { id: "แหวนไฟช๊อต", name: "แหวนไฟช๊อต" },
  { id: "แหวนไฟเผา", name: "แหวนไฟเผา" },
  { id: "แหวนคริ", name: "แหวนคริ" },
  { id: "แหวนจุดอ่อน", name: "แหวนจุดอ่อน" },
  { id: "แหวนดาเมจ", name: "แหวนดาเมจ" },
  { id: "แหวนต้าน", name: "แหวนต้าน" },
  { id: "แหวนบล๊อค", name: "แหวนบล๊อค" },
  { id: "แหวนป้องกัน", name: "แหวนป้องกัน" },
  { id: "แหวนเข้าเป้า", name: "แหวนเข้าเป้า" },
];

const EQUIPMENT_SET_DEFINITIONS = [
  { id: "นักฆ่า", name: "คริ" },
  { id: "นายประตู", name: "บล็อค" },
  { id: "ผู้บัญชาการ", name: "โจมตี" },
  { id: "ผู้ปรับสมดุล", name: "ต้าน" },
  { id: "ผู้พิทักษ์", name: "ป้องกัน" },
  { id: "ผู้ล้างแค้น", name: "บอส" },
  { id: "ผู้ไล่ล่า", name: "จุดอ่อน" },
  { id: "หมอผี", name: "หมอผี" },
  { id: "อัศวินศักดิ์สิทธิ", name: "เลือด" },
  { id: "ยำ", name: "ยำ" }
];

const RINGS = RING_DEFINITIONS.map(({ id, name }) => ({
  id,
  name,
  img: `public/ring/${id}.webp`
}));

const EQUIPMENT_SETS = EQUIPMENT_SET_DEFINITIONS.map(({ id, name }) => ({
  id,
  name,
  img: `public/equipment-set/${id}.webp`
}));

const RING_ALIASES = {
  "แหวนอมตะระดับสูง":          ["ซอมบี้"],
  "แหวนอมตะ":                   ["ซอมบี้"],
  "แหวนอมตะเก่า":               ["ซอมบี้"],
  "แหวนแห่งการคืนชีพระดับสูง": ["ตายเกิด", "ชุบ"],
  "แหวนแห่งการคืนชีพ":         ["ตายเกิด", "ชุบ"],
  "แหวนแห่งการคืนชีพเก่า":     ["ตายเกิด", "ชุบ"],
};

function ringMatchesQuery(ring, query) {
  const q = query.trim().toLowerCase();
  if (!q) return true;
  if (ring.name.toLowerCase().includes(q)) return true;
  if (ring.id.toLowerCase().includes(q)) return true;
  return (RING_ALIASES[ring.id] || []).some((alias) => alias.toLowerCase().includes(q));
}

function getRing(id) {
  return RINGS.find((r) => r.id === id) || null;
}

function getEquipmentSet(id) {
  return EQUIPMENT_SETS.find((s) => s.id === id) || null;
}
