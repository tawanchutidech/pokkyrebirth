// Bootstraps the app: theme toggle, update banner, admin gate, and switching
// between the public list view and the admin editor view.
const App = {
  _booted: false,
  _presenceTimer: null,
  _sessionTimer: null,
  _accessCodeValidationTimer: null,
  _expiringSession: false,

  async init() {
    this.initTheme();
    this.bindWelcomeModal();
    this.bindPresenceLifecycle();
    await Auth.initDiscord();
    await Auth.validateLocalGuildSession();
    await Store.load();
    if (Store.loadError()) {
      this.showDataUnavailable(Store.loadError());
      return;
    }

    // แสดง error ถ้า Discord ปฏิเสธสิทธิ์
    const urlParams = new URLSearchParams(location.search);
    const authResult = urlParams.get("auth");
    const loginSucceeded = urlParams.get("login") === "success";

    if (urlParams.get("logged_out") === "1") {
      sessionStorage.clear();
      history.replaceState(null, "", location.pathname);
    }

    if (!Auth.isGuildMember()) {
      this.showGate(authResult);
    } else {
      this.bootApp();
      this.showWatermark();
      if (loginSucceeded) this.showWelcome();
    }
    if (loginSucceeded) history.replaceState(null, "", location.pathname + location.hash);
  },

  showDataUnavailable(code) {
    this.stopPresence();
    this.stopAccessCodeValidation();
    this.setSessionStatus("ระบบข้อมูลไม่พร้อมใช้งาน", "locked");
    document.getElementById("gateView").style.display = "flex";
    document.getElementById("listView").style.display = "none";
    document.getElementById("detailView").style.display = "none";
    document.getElementById("toolsView").style.display = "none";
    document.getElementById("adminView").style.display = "none";
    const error = document.getElementById("gateAuthError");
    const messages = {
      store_uninitialized: "ระบบหยุดแสดงข้อมูลเพื่อความปลอดภัย เนื่องจากคลังข้อมูลหลักยังไม่ได้เริ่มต้น กรุณาติดต่อผู้ดูแลระบบ",
      store_identity_mismatch: "ระบบตรวจพบว่าการเชื่อมต่อชี้ไปยังคลังข้อมูลผิดชุด จึงหยุดการอ่านและเขียนข้อมูล กรุณาติดต่อผู้ดูแลระบบ",
      store_metadata_inconsistent: "ข้อมูล revision และ metadata ไม่ตรงกัน ระบบจึงหยุดทำงานเพื่อป้องกันข้อมูลเสียหาย",
      api_unavailable: "ไม่สามารถเชื่อมต่อคลังข้อมูลหลักได้ ระบบจะไม่แสดงข้อมูลสำรองเก่าแทน กรุณาลองใหม่ภายหลัง"
    };
    error.textContent = messages[code] || messages.api_unavailable;
    error.style.display = "block";
    const image = document.getElementById("gateNoAccessImage");
    if (image) image.style.display = "none";
    document.getElementById("storeInitializeControls")?.remove();
    if (code === "store_uninitialized" && Auth.isActualAdmin()) {
      const controls = document.createElement("div");
      controls.id = "storeInitializeControls";
      controls.className = "store-initialize-controls";
      controls.innerHTML = `
        <p class="hint">Admin: เลือกไฟล์ export ที่ตรวจสอบแล้วเพื่อเริ่มต้นคลังข้อมูลอย่างชัดเจน</p>
        <button class="btn btn-danger" id="initializeStoreBtn" type="button">เริ่มต้นคลังข้อมูลจากไฟล์</button>
        <input id="initializeStoreFile" type="file" accept="application/json" style="display:none;">
      `;
      error.insertAdjacentElement("afterend", controls);
      const fileInput = controls.querySelector("#initializeStoreFile");
      controls.querySelector("#initializeStoreBtn").addEventListener("click", () => fileInput.click());
      fileInput.addEventListener("change", async () => {
        const file = fileInput.files?.[0];
        if (!file) return;
        try {
          const data = await Store.parseImportJsonFile(file);
          const reason = window.prompt("ระบุเหตุผลในการเริ่มต้นคลังข้อมูล (จำเป็น)", "Production recovery initialization")?.trim();
          if (!reason) return;
          if (!window.confirm(`ยืนยันเริ่มต้นคลังข้อมูลด้วย ${data.teams.length} ทีม? ใช้เฉพาะเมื่อยืนยันแล้วว่าคลัง production ว่างจริง`)) return;
          const response = await fetch("/api/teams/initialize", {
            method: "POST",
            credentials: "include",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ data, confirm: "INITIALIZE", reason })
          });
          const result = await response.json().catch(() => ({}));
          if (!response.ok) throw new Error(result.error || "initialize_failed");
          window.alert("เริ่มต้นคลังข้อมูลและสร้าง snapshot แรกแล้ว");
          location.reload();
        } catch (initError) {
          window.alert("เริ่มต้นคลังข้อมูลไม่สำเร็จ: " + initError.message);
        } finally {
          fileInput.value = "";
        }
      });
    }
  },

  setSessionStatus(label, state = "online") {
    const status = document.getElementById("sessionStatus");
    const text = document.getElementById("sessionStatusText");
    if (!status || !text) return;
    text.textContent = label;
    status.title = label;
    status.classList.remove("is-loading", "is-online", "is-locked", "is-admin", "is-researcher");
    status.classList.add(`is-${state}`);
  },

  showGate(authResult) {
    this.stopPresence();
    this.stopAccessCodeValidation();
    this.refreshOnlineCount();
    this.setSessionStatus("ต้องยืนยันสิทธิ์", "locked");
    document.getElementById("gateView").style.display = "flex";
    document.getElementById("listView").style.display = "none";
    document.getElementById("detailView").style.display = "none";
    document.getElementById("toolsView").style.display = "none";
    document.getElementById("adminView").style.display = "none";

    const errEl = document.getElementById("gateAuthError");
    const noAccessImage = document.getElementById("gateNoAccessImage");
    const isNoAccessDiscordUser = Boolean(Auth.discordUser && !Auth.discordUser.isMember);
    if (noAccessImage) noAccessImage.style.display = isNoAccessDiscordUser ? "block" : "none";
    if (authResult === "denied") {
      errEl.textContent = "ไม่มีสิทธิ์เข้าถึง — ต้องเป็นสมาชิกกิลด์ใน Discord";
      errEl.style.display = "block";
    } else if (authResult === "config_missing") {
      errEl.textContent = "ผู้ดูแลยังตั้งค่า Discord OAuth ไม่ครบ (ต้องมี DISCORD_CLIENT_SECRET และ SESSION_SECRET)";
      errEl.style.display = "block";
    } else if (authResult === "state_invalid") {
      errEl.textContent = "การยืนยัน Discord หมดอายุหรือถูกบล็อกคุกกี้ — โปรดลองใหม่ในหน้าต่างปกติ";
      errEl.style.display = "block";
    } else if (authResult === "token_failed") {
      errEl.textContent = "Discord ไม่รับการยืนยันตัวตน — ตรวจสอบ Client Secret และ Callback URL";
      errEl.style.display = "block";
    } else if (authResult === "user_failed") {
      errEl.textContent = "Discord ไม่สามารถอ่านบัญชีผู้ใช้ได้ — โปรดลองอนุญาตสิทธิ์ใหม่";
      errEl.style.display = "block";
    } else if (authResult === "failed") {
      errEl.textContent = "เกิดข้อผิดพลาด กรุณาลองใหม่อีกครั้ง";
      errEl.style.display = "block";
    } else if (authResult === "session_expired") {
      errEl.textContent = "หมดเวลาใช้งาน 15 นาทีแล้ว กรุณาเข้าสู่ระบบอีกครั้ง";
      errEl.style.display = "block";
    } else if (authResult === "access_code_reset") {
      errEl.textContent = "รหัสสมาชิกถูกเปลี่ยนแล้ว กรุณาเข้าสู่ระบบด้วยรหัสใหม่";
      errEl.style.display = "block";
    }

    document.getElementById("gateLoginBtn").onclick = () => {
      Auth.promptGuildLogin(() => { this.bootApp(); this.showWatermark(); this.showWelcome(); });
    };
  },

  bindWelcomeModal() {
    document.getElementById("welcomeCloseBtn")?.addEventListener("click", () => {
      const modal = document.getElementById("welcomeModal");
      modal.classList.remove("open");
      modal.setAttribute("aria-hidden", "true");
    });
  },

  bindPresenceLifecycle() {
    window.addEventListener("pagehide", () => this.sendOfflinePresence(true));
    window.addEventListener("pageshow", (event) => {
      if (event.persisted && Auth.isGuildMember()) this.sendPresence();
    });
  },

  showWelcome() {
    const modal = document.getElementById("welcomeModal");
    const message = document.getElementById("welcomeModalMessage");
    if (!modal || !message) return;
    const name = Auth.discordUser?.displayName || "สมาชิกกิลด์";
    const guild = Auth.memberGuilds().join(" / ") || "PokkyRebirth & Priest";
    message.textContent = `ยินดีต้อนรับ ${name} จากกิลด์ ${guild}`;
    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
  },

  showWatermark() {
    const user = Auth.discordUser;
    if (!user) return;
    const name = user.displayName;
    // Corner watermark
    const wm = document.getElementById("discordWatermark");
    wm.textContent = name;
    wm.style.display = "block";
    // CSS variable for card watermarks
    document.documentElement.style.setProperty("--discord-wm", `"${name}"`);
  },

  bootApp() {
    this.refreshRoleStatus();
    document.getElementById("logoutBtn").style.display = "";
    if (this._booted) {
      document.getElementById("gateView").style.display = "none";
      this.showList();
      this.startPolling();
      this.startPresence();
      this.armSessionExpiry();
      this.startAccessCodeValidation();
      this.handleDeepLink();
      return;
    }
    this._booted = true;
    document.getElementById("gateView").style.display = "none";
    document.getElementById("listView").style.display = "block";
    ListView.mount();
    AdminEditor.mount();
    this.startPolling();
    this.startPresence();
    this.armSessionExpiry();
    this.startAccessCodeValidation();
    document.getElementById("editToggle").addEventListener("click", () => this.onEditToggle());
    document.getElementById("toolsToggle").addEventListener("click", () => this.showTools());
    document.getElementById("rolePreviewExitBtn").addEventListener("click", () => this.exitRolePreview());
    document.getElementById("closeLineModal").addEventListener("click", () =>
      document.getElementById("lineModal").classList.remove("open")
    );
    document.getElementById("copyLineBtn").addEventListener("click", () => {
      navigator.clipboard.writeText(document.getElementById("lineText").textContent)
        .then(() => toast("คัดลอกข้อความแล้ว"));
    });
    this.applyAdminUi();
    this.handleDeepLink();
    if (Store.hasStaleDraft()) {
      toast("พบฉบับร่างเก่าบนอุปกรณ์นี้ จึงแสดงข้อมูลล่าสุดจากแพลตฟอร์มแทน เพื่อป้องกันการเขียนทับข้อมูล");
    }
    window.addEventListener("popstate", () => this.handleDeepLink());
  },

  refreshRoleStatus() {
    const role = Auth.isAdmin()
      ? { label: "Admin", state: "admin" }
      : Auth.isResearcher()
        ? { label: "Researcher", state: "researcher" }
        : { label: Auth.memberGuilds().join(" / ") || "สมาชิกกิลด์", state: "online" };
    const discordName = String(Auth.discordUser?.displayName || "").trim();
    this.setSessionStatus(discordName ? `${role.label} · ${discordName}` : role.label, role.state);
  },

  updateOnlineCount(count) {
    const value = document.getElementById("onlineCountValue");
    if (value && Number.isFinite(Number(count))) value.textContent = String(count);
  },

  async refreshOnlineCount() {
    try {
      const response = await fetch("/api/presence", { credentials: "include" });
      if (!response.ok) return;
      const data = await response.json();
      this.updateOnlineCount(data.onlineCount);
    } catch (_) {}
  },

  async sendPresence() {
    // Access-code members may also have a Discord session that has no approved
    // guild role. Such a session cannot use the presence endpoint and must not
    // invalidate the separate, valid access-code session.
    if (!Auth.discordUser || (!Auth.discordUser.isMember && !Auth.isActualAdmin())) {
      await this.refreshOnlineCount();
      return;
    }
    try {
      const response = await fetch("/api/presence", { method: "POST", credentials: "include" });
      if (response.status === 401) {
        this.expireSession();
        return;
      }
      if (!response.ok) return;
      const data = await response.json();
      this.updateOnlineCount(data.onlineCount);
    } catch (_) {}
  },

  async sendOfflinePresence(useBeacon = false) {
    if (!Auth.discordUser) return;
    const endpoint = "/api/presence/offline";
    if (useBeacon && navigator.sendBeacon) {
      navigator.sendBeacon(endpoint, new Blob([], { type: "text/plain" }));
      return;
    }
    try {
      const response = await fetch(endpoint, { method: "POST", credentials: "include", keepalive: true });
      if (!response.ok) return;
      const data = await response.json();
      this.updateOnlineCount(data.onlineCount);
    } catch (_) {}
  },

  startPresence() {
    this.stopPresence();
    this.sendPresence();
    this._presenceTimer = setInterval(() => this.sendPresence(), 60 * 1000);
  },

  stopPresence() {
    if (this._presenceTimer) clearInterval(this._presenceTimer);
    this._presenceTimer = null;
  },

  startAccessCodeValidation() {
    this.stopAccessCodeValidation();
    // Discord members are validated by their server session. Only code-only
    // members need to check whether an Admin has reset the daily access code.
    if (!Auth.hasActiveLocalGuildSession() || Auth.discordUser?.isMember) return;
    const validate = async () => {
      if (await Auth.validateLocalGuildSession()) return;
      this.logout("access_code_reset");
    };
    this._accessCodeValidationTimer = setInterval(validate, 15 * 1000);
  },

  stopAccessCodeValidation() {
    if (this._accessCodeValidationTimer) clearInterval(this._accessCodeValidationTimer);
    this._accessCodeValidationTimer = null;
  },

  armSessionExpiry() {
    if (this._sessionTimer) clearTimeout(this._sessionTimer);
    const expiresAt = Auth.sessionExpiry();
    if (!expiresAt) return;
    const remaining = expiresAt - Date.now();
    if (remaining <= 0) {
      this.expireSession();
      return;
    }
    this._sessionTimer = setTimeout(() => this.expireSession(), remaining + 50);
  },

  expireSession() {
    if (this._expiringSession) return;
    this._expiringSession = true;
    this.logout("session_expired").finally(() => { this._expiringSession = false; });
  },

  handleDeepLink() {
    const match = window.location.hash.match(/^#team\/(.+)$/);
    if (match) {
      ListView.showDetail(match[1]);
    } else if (document.getElementById("detailView").style.display !== "none") {
      document.getElementById("detailView").style.display = "none";
      document.getElementById("listView").style.display = "block";
    }
  },

  initTheme() {
    // Keep one consistent presentation for the tactical dashboard.
    localStorage.removeItem("7kcombo_theme");
    document.documentElement.classList.add("dark");
  },

  onEditToggle() {
    const inAdmin = document.getElementById("adminView").style.display !== "none";
    if (inAdmin) {
      // Currently in admin view → exit (logout clears admin session)
      this.exitAdminWithConfirm();
      return;
    }
    if (Auth.canEditTeams()) {
      // An editor session is still active (e.g. came back from the list).
      this.showAdmin();
      return;
    }
    toast("โหมดแก้ไขสำหรับ Researcher หรือ Admin ที่ได้รับอนุญาตเท่านั้น");
  },

  // Leaving admin mode (via the editToggle icon or the "กลับหน้าหลัก"
  // button) returns to the list. If a team add/edit is open and unsaved, confirm first so a stray
  // click can't silently throw away in-progress work.
  exitAdminWithConfirm() {
    const leave = () => {
      Auth.logout();
      this.showList();
    };
    if (AdminEditor.team) {
      Modal.confirm("คุณมีการแก้ไขที่ยังไม่บันทึก ต้องการออกจากหน้าแก้ไขใช่หรือไม่?", leave);
      return;
    }
    leave();
  },

  showAdmin() {
    if (!Auth.canEditTeams()) {
      toast("ไม่มีสิทธิ์เข้าสู่โหมดแก้ไขทีม");
      return;
    }
    document.getElementById("listView").style.display = "none";
    document.getElementById("detailView").style.display = "none";
    document.getElementById("toolsView").style.display = "none";
    document.getElementById("adminView").style.display = "block";
    AdminEditor.tab = ListView.state.tab;
    AdminEditor.renderTeamList();
    this.applyAdminUi();
  },

  openTeamEditor(teamId, counterIndex = null, { returnToDetailTeamId = null } = {}) {
    if (!Auth.canEditTeams()) {
      toast("การแก้ไขทีมสำหรับ Researcher และ Admin เท่านั้น");
      return;
    }
    const team = Store.getTeam(teamId);
    if (!team) return;
    this.showAdmin();
    AdminEditor.tab = team.tab || "attack";
    AdminEditor.renderTeamList();
    AdminEditor.openEditorModal(team, false, counterIndex, {
      returnToListOnCancel: !returnToDetailTeamId,
      returnToDetailTeamId
    });
  },

  openCounterEditor(teamId) {
    if (!Auth.canEditTeams()) {
      toast("การเพิ่มทีมตอบโต้สำหรับ Researcher และ Admin เท่านั้น");
      return;
    }
    const team = Store.getTeam(teamId);
    if (!team) return;
    this.showAdmin();
    AdminEditor.tab = team.tab || "attack";
    AdminEditor.renderTeamList();
    AdminEditor.openCounterEditor(team, { returnToDetailTeamId: team.id });
  },

  showList() {
    ListView.state.tab = AdminEditor.tab;
    AdminEditor.closeEditor();
    document.getElementById("adminView").style.display = "none";
    document.getElementById("detailView").style.display = "none";
    document.getElementById("toolsView").style.display = "none";
    document.getElementById("listView").style.display = "block";
    ListView.renderTabButtons();
    ListView.renderFilterPills();
    ListView.render();
    this.applyAdminUi();
  },

  showTools() {
    if (!Auth.canAccessAdminTools()) {
      toast("เครื่องมือนี้สำหรับ Admin เท่านั้น");
      return;
    }
    document.getElementById("listView").style.display = "none";
    document.getElementById("adminView").style.display = "none";
    document.getElementById("detailView").style.display = "none";
    document.getElementById("toolsView").style.display = "block";
    AdminTools.render();
    this.applyAdminUi();
  },

  applyAdminUi() {
    const inAdmin = document.getElementById("adminView").style.display !== "none";
    const editToggle = document.getElementById("editToggle");
    editToggle.classList.toggle("active", inAdmin);
    editToggle.style.display = Auth.canEditTeams() ? "" : "none";
    document.getElementById("toolsToggle").style.display = Auth.canAccessAdminTools() ? "" : "none";
    const title = document.getElementById("adminTitle");
    if (title) title.textContent = Auth.isAdmin()
      ? "โหมดแก้ไข (Admin)"
      : "โหมดแก้ไข (Researcher)";
    ["importBtn", "exportBtn"].forEach((id) => {
      const button = document.getElementById(id);
      if (button) button.style.display = Auth.isAdmin() ? "" : "none";
    });
    this.refreshRolePreviewBar();
  },

  setRolePreview(role) {
    if (!Auth.setPreviewRole(role)) {
      toast("เฉพาะ Admin เท่านั้นที่เปลี่ยนมุมมองตัวอย่างได้");
      return;
    }
    this.refreshRoleStatus();
    if (Auth.isPreviewingRole()) this.showList();
    else this.showTools();
  },

  exitRolePreview() {
    if (!Auth.isActualAdmin()) return;
    Auth.setPreviewRole("admin");
    this.refreshRoleStatus();
    this.showTools();
  },

  refreshRolePreviewBar() {
    const bar = document.getElementById("rolePreviewBar");
    const text = document.getElementById("rolePreviewText");
    if (!bar || !text) return;
    const active = Auth.isActualAdmin() && Auth.isPreviewingRole();
    bar.style.display = active ? "flex" : "none";
    if (active) text.textContent = `กำลังดูมุมมอง: ${Auth.previewRoleLabel()} (ตัวอย่างเท่านั้น)`;
  },

  startPolling() {
    Store.pollForUpdates(() => {
      // Editors already have the current draft open, so don't interrupt them.
      if (Auth.canEditTeams()) return;
      this.showUpdateNotif();
    });
  },

  showUpdateNotif() {
    Store.stopPolling();
    const banner = document.getElementById("updateNotifBanner");
    if (!banner || banner.style.display !== "none") return;
    banner.style.display = "flex";
  },

  async logout(reason = null) {
    await this.sendOfflinePresence();
    try {
      await fetch("/auth/logout", { method: "POST", credentials: "include" });
    } catch (_) {
      // Local/static previews have no Worker logout endpoint.
    }
    Auth.logoutAll();
    Store.stopPolling();
    this.stopPresence();
    this.stopAccessCodeValidation();
    if (this._sessionTimer) clearTimeout(this._sessionTimer);
    this._sessionTimer = null;
    document.getElementById("logoutBtn").style.display = "none";
    document.getElementById("discordWatermark").style.display = "none";
    this.showGate(reason);
  },
};

document.addEventListener("DOMContentLoaded", () => {
  App.init();
  document.getElementById("logoutBtn").addEventListener("click", () => { App.logout(); });
});
