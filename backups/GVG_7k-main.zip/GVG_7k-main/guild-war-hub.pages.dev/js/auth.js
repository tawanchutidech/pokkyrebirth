const GUILD_SESSION_KEY = "7kcombo_daily_ok_v2";
const GUILD_SESSION_STARTED_KEY = "7kcombo_daily_started_at_v1";
const GUILD_SESSION_VERSION_KEY = "7kcombo_daily_code_version_v1";
const GUILD_SESSION_MAX_AGE = 6 * 60 * 60 * 1000;

const Auth = {
  discordUser: null,
  // A real administrator may temporarily preview a lower-privilege interface.
  // This only changes client-side visibility; it never changes the signed session.
  previewRole: null,

  async initDiscord() {
    // Invalidate sessions that could have been created by the removed static admin codes.
    sessionStorage.removeItem("7kcombo_admin_ok");
    sessionStorage.removeItem("7kcombo_admin_guild");
    sessionStorage.removeItem("7kcombo_guild_ok");
    this.sessionExpiresAt = null;
    try {
      const res = await fetch("/auth/me");
      const data = await res.json();
      if (data.loggedIn) {
        this.discordUser = data;
        this.sessionExpiresAt = Number(data.expiresAt) || null;
        // A confirmed Discord member always has guild access. Do not remove a
        // valid access-code session for an unapproved Discord account.
        if (data.isMember) sessionStorage.setItem(GUILD_SESSION_KEY, "1");
      }
    } catch (_) {}
  },

  async validateLocalGuildSession() {
    if (sessionStorage.getItem(GUILD_SESSION_KEY) !== "1") return true;
    try {
      const response = await fetch("/api/access-code/version", { cache: "no-store" });
      if (!response.ok) return true;
      const { version } = await response.json();
      if (version && sessionStorage.getItem(GUILD_SESSION_VERSION_KEY) === version) return true;
      this.clearLocalGuildSession();
      return false;
    } catch (_) {
      // Do not log a member out merely because the network is temporarily unavailable.
      return true;
    }
  },

  clearLocalGuildSession() {
    sessionStorage.removeItem(GUILD_SESSION_KEY);
    sessionStorage.removeItem(GUILD_SESSION_STARTED_KEY);
    sessionStorage.removeItem(GUILD_SESSION_VERSION_KEY);
  },

  isAdmin() {
    return this.previewRole ? this.previewRole === "admin" : this.isActualAdmin();
  },

  isActualAdmin() {
    return Boolean(this.discordUser?.isAdmin);
  },

  isResearcher() {
    return this.previewRole ? this.previewRole === "researcher" : Boolean(this.discordUser?.isResearcher);
  },

  setPreviewRole(role) {
    if (!this.isActualAdmin()) return false;
    this.previewRole = ["researcher", "member"].includes(role) ? role : null;
    return true;
  },

  isPreviewingRole() {
    return Boolean(this.previewRole);
  },

  previewRoleLabel() {
    return ({
      researcher: "Researcher",
      member: "สมาชิกกิลด์"
    }[this.previewRole] || "Admin");
  },

  memberGuilds() {
    const guilds = this.discordUser?.memberGuilds;
    return Array.isArray(guilds) ? guilds.filter(Boolean) : [];
  },

  canEditTeams() {
    // Editing is intentionally limited to verified Researcher and Admin roles.
    return this.isAdmin() || this.isResearcher();
  },

  canAccessAdminTools() {
    return this.isActualAdmin();
  },

  // True for both guild-members and admins (admins always have guild access).
  isGuildMember() {
    if (this.discordUser?.isMember) return true;
    return this.isAdmin() || this.hasActiveLocalGuildSession();
  },

  hasActiveLocalGuildSession() {
    if (sessionStorage.getItem(GUILD_SESSION_KEY) !== "1") return false;
    const startedAt = Number(sessionStorage.getItem(GUILD_SESSION_STARTED_KEY));
    if (Number.isFinite(startedAt) && Date.now() < startedAt + GUILD_SESSION_MAX_AGE) return true;
    this.clearLocalGuildSession();
    return false;
  },

  sessionExpiry() {
    if (Number.isFinite(this.sessionExpiresAt)) return this.sessionExpiresAt;
    const startedAt = Number(sessionStorage.getItem(GUILD_SESSION_STARTED_KEY));
    return Number.isFinite(startedAt) ? startedAt + GUILD_SESSION_MAX_AGE : null;
  },

  // Opens the shared login modal configured for the given context.
  // opts: { title, subtitle, label, codes, sessionKey, onSuccess }
  _openLoginModal(opts) {
    const overlay   = document.getElementById("adminLoginModal");
    const titleEl   = document.getElementById("adminLoginTitle");
    const subEl     = document.getElementById("adminLoginSubtitle");
    const labelEl   = document.getElementById("adminLoginLabel");
    const input     = document.getElementById("adminCodeInput");
    const error     = document.getElementById("adminLoginError");
    const eye       = document.getElementById("adminCodeEye");
    const iconShow  = document.getElementById("eyeIconShow");
    const iconHide  = document.getElementById("eyeIconHide");
    const okBtn     = document.getElementById("adminLoginOk");
    const cancelBtn = document.getElementById("adminLoginCancel");
    const closeBtn  = document.getElementById("adminLoginClose");

    // Store original texts so close() restores them for admin login next time.
    const origTitle  = titleEl.textContent;
    const origSub    = subEl.textContent;
    const origLabel  = labelEl.textContent;

    titleEl.textContent = opts.title;
    subEl.textContent   = opts.subtitle;
    labelEl.textContent = opts.label;

    input.value = "";
    input.type  = "password";
    error.textContent = "";
    iconShow.style.display = "";
    iconHide.style.display = "none";
    overlay.classList.add("open");
    setTimeout(() => input.focus(), 60);

    const close = () => {
      overlay.classList.remove("open");
      input.onkeydown   = null;
      okBtn.onclick     = null;
      cancelBtn.onclick = null;
      closeBtn.onclick  = null;
      eye.onclick       = null;
      titleEl.textContent = origTitle;
      subEl.textContent   = origSub;
      labelEl.textContent = origLabel;
    };

    const trySubmit = async () => {
      const code = input.value.trim();
      let result = null;
      try {
        result = opts.validateCode
          ? await opts.validateCode(code)
          : { valid: opts.codes?.some((item) => item.toLowerCase() === code.toLowerCase()) };
      } catch (_) {
        error.textContent = "ไม่สามารถตรวจสอบรหัสได้ กรุณาลองใหม่อีกครั้ง";
        return;
      }
      if (result?.valid) {
        sessionStorage.setItem(opts.sessionKey, "1");
        close();
        opts.onSuccess(result);
      } else {
        error.textContent = "รหัสไม่ถูกต้อง กรุณาลองใหม่อีกครั้ง";
        input.value = "";
        input.focus();
      }
    };

    okBtn.onclick     = trySubmit;
    cancelBtn.onclick = close;
    closeBtn.onclick  = close;
    input.onkeydown   = (e) => { if (e.key === "Enter") trySubmit(); };
    eye.onclick = () => {
      const hidden = input.type === "password";
      input.type = hidden ? "text" : "password";
      iconShow.style.display = hidden ? "none" : "";
      iconHide.style.display = hidden ? ""     : "none";
    };
  },

  promptGuildLogin(onSuccess) {
    this._openLoginModal({
      title:     "สมาชิกกิลด์",
      subtitle:  "กรอกรหัสสมาชิกเพื่อเข้าใช้งานเว็บไซต์",
      label:     "รหัสสมาชิก",
      sessionKey: GUILD_SESSION_KEY,
      validateCode: async (code) => {
        const response = await fetch("/api/access-code/verify", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ code })
        });
        if (!response.ok) throw new Error("verification_failed");
        return response.json();
      },
      onSuccess: ({ version }) => {
        sessionStorage.setItem(GUILD_SESSION_STARTED_KEY, String(Date.now()));
        if (version) sessionStorage.setItem(GUILD_SESSION_VERSION_KEY, version);
        onSuccess();
      },
    });
  },

  canEditTeam() {
    return this.canEditTeams();
  },

  logout() {
    // Editing access comes only from the active Discord session.
  },

  logoutAll() {
    this.clearLocalGuildSession();
    this.discordUser = null;
    this.sessionExpiresAt = null;
    this.previewRole = null;
  }
};
