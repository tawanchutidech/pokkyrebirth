const VOTE_STORE_KEY = "7kcombo_votes_v1";
const VOTE_COUNT_STORE_KEY = "7kcombo_vote_counts_v1";

const Vote = {
  _getAll() {
    try { return JSON.parse(localStorage.getItem(VOTE_STORE_KEY) || "{}"); }
    catch { return {}; }
  },

  _getAllCounts() {
    try { return JSON.parse(localStorage.getItem(VOTE_COUNT_STORE_KEY) || "{}"); }
    catch { return {}; }
  },

  getLocal(teamId, counterIdx) {
    return this._getAll()[`${teamId}:${counterIdx}`] || null;
  },

  getCounts(teamId, counterIdx, likes = 0, dislikes = 0) {
    return this._getAllCounts()[`${teamId}:${counterIdx}`] || { likes, dislikes };
  },

  _setLocal(teamId, counterIdx, voteType) {
    const all = this._getAll();
    const key = `${teamId}:${counterIdx}`;
    if (voteType) all[key] = voteType;
    else delete all[key];
    localStorage.setItem(VOTE_STORE_KEY, JSON.stringify(all));
  },

  _setCounts(teamId, counterIdx, counts) {
    const all = this._getAllCounts();
    all[`${teamId}:${counterIdx}`] = counts;
    localStorage.setItem(VOTE_COUNT_STORE_KEY, JSON.stringify(all));
  },

  async cast(teamId, counterIdx, voteType) {
    try {
      const response = await fetch("/api/votes", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ teamId, counterIdx, voteType })
      });
      if (!response.ok) {
        if (response.status === 404) return this._castLocal(teamId, counterIdx, voteType);
        const error = await response.json().catch(() => ({}));
        throw new Error(error.error === "member_required" ? "กรุณาเข้าสู่ระบบก่อนโหวต" : "บันทึกคะแนนบนแพลตฟอร์มไม่สำเร็จ");
      }
      const result = await response.json();
      this._setLocal(teamId, counterIdx, result.newVote);
      this._setCounts(teamId, counterIdx, result);
      this._syncCurrentData(teamId, counterIdx, result);
      return result;
    } catch (error) {
      // Keep local previews usable only when the Worker endpoint is absent.
      if (!/Failed to fetch|NetworkError|not found/i.test(error.message)) throw error;
      return this._castLocal(teamId, counterIdx, voteType);
    }
  },

  _castLocal(teamId, counterIdx, voteType) {
    const prev = this.getLocal(teamId, counterIdx);
    const newVote = prev === voteType ? null : voteType;
    const team = Store.getTeam(teamId);
    const counter = team?.counters?.[counterIdx];
    if (!counter) throw new Error("ไม่พบทีมตอบโต้");
    const current = this.getCounts(teamId, counterIdx, counter.likes || 0, counter.dislikes || 0);
    let likes = current.likes || 0;
    let dislikes = current.dislikes || 0;
    if (prev === "like") likes = Math.max(0, likes - 1);
    if (prev === "dislike") dislikes = Math.max(0, dislikes - 1);
    if (newVote === "like") likes += 1;
    if (newVote === "dislike") dislikes += 1;
    const result = { newVote, likes, dislikes };
    this._setLocal(teamId, counterIdx, newVote);
    this._setCounts(teamId, counterIdx, result);
    this._syncCurrentData(teamId, counterIdx, result);
    return result;
  },

  _syncCurrentData(teamId, counterIdx, result) {
    const counter = Store.getTeam(teamId)?.counters?.[counterIdx];
    if (!counter) return;
    counter.likes = result.likes;
    counter.dislikes = result.dislikes;
  },
};
