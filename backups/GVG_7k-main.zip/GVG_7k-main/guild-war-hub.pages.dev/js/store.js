// Data layer: loads data/teams.json, keeps an in-memory working copy that
// gets auto-saved as a draft to localStorage, and offers Export/Import to
// move that draft back into the committed teams.json file (this is a static
// site with no backend, so the JSON file is the real source of truth).
const TEAMS_JSON_PATH = "data/teams.json";
const TEAMS_API_PATH = "/api/teams";
const DRAFT_KEY = "7kcombo_draft_v1";

const TEAM_TABS = [
  { id: "attack", label: "ทีมบุก" },
];

const CATEGORIES = [
  { id: "tank", label: "ถึก", color: "#94a3b8" },
  { id: "magic", label: "เวทย์", color: "#60a5fa" },
  { id: "physical", label: "กายภาพ", color: "#f87171" },
  { id: "other", label: "อื่นๆ", color: "#a78bfa" }
];

function getCategory(id) {
  return CATEGORIES.find((c) => c.id === id) || CATEGORIES[3];
}

const DEFAULT_DATA = { teams: [] };

// Awake heroes are now the canonical versions. Keep this migration at the
// data boundary so saved browser drafts and older JSON imports do not produce
// missing portraits or split gear records after the catalogue rename.
const LEGACY_AWAKE_HERO_IDS = {
  "ซอรัน Awake": "ซอรัน",
  "ซิลเวสตา Awake": "ซิลเวสตา",
  "สกัลด์ Awake": "สกัลด์",
  "ออร์ก้า Awake": "ออร์ก้า",
  "เคลมิส Awake": "เคลมิส",
  "เดลโลนส์ Awake": "เดลโลนส์",
  "เฮฟเว่นเนีย Awake": "เฮฟเว่นเนีย",
  "เฮเลเนีย Awake": "เฮเลเนีย",
  "เอริส Awake": "เอริส",
  "ลูดี้ Awake": "ลูดี้",
  "โดยอง Awake": "โดยอง",
  "น็อกซ์ Awake": "น็อกซ์",
  "ยุนกอน Awake": "ยุนกอน",
};

const RETIRED_NON_AWAKE_HERO_IDS = new Set([
  "ซิลเวสตา", "สกัลด์", "ออร์ก้า", "เคลมิส", "เดลโลนส์",
  "เฮฟเว่นเนีย", "เฮเลเนีย", "เอริส", "ลูดี้", "น็อกซ์",
]);

function containsRetiredNonAwakeHero(value) {
  if (typeof value === "string") return RETIRED_NON_AWAKE_HERO_IDS.has(value);
  if (Array.isArray(value)) return value.some(containsRetiredNonAwakeHero);
  if (!value || typeof value !== "object") return false;
  return Object.entries(value).some(([key, child]) =>
    RETIRED_NON_AWAKE_HERO_IDS.has(key) || containsRetiredNonAwakeHero(child)
  );
}

function containsLegacyAwakeHero(value) {
  if (typeof value === "string") return Object.hasOwn(LEGACY_AWAKE_HERO_IDS, value);
  if (Array.isArray(value)) return value.some(containsLegacyAwakeHero);
  if (!value || typeof value !== "object") return false;
  return Object.entries(value).some(([key, child]) =>
    Object.hasOwn(LEGACY_AWAKE_HERO_IDS, key) || containsLegacyAwakeHero(child)
  );
}

function renameLegacyHeroIds(value) {
  if (typeof value === "string") return LEGACY_AWAKE_HERO_IDS[value] || value;
  if (Array.isArray(value)) return value.map(renameLegacyHeroIds);
  if (!value || typeof value !== "object") return value;

  const renamed = {};
  for (const [key, child] of Object.entries(value)) {
    const canonicalKey = LEGACY_AWAKE_HERO_IDS[key] || key;
    if (Object.hasOwn(renamed, canonicalKey)) {
      throw new Error(`Conflicting legacy hero data for ${canonicalKey}`);
    }
    renamed[canonicalKey] = renameLegacyHeroIds(child);
  }
  return renamed;
}

function renameLegacyHeroTitle(name) {
  return Object.entries(LEGACY_AWAKE_HERO_IDS).reduce(
    (title, [legacyId, canonicalId]) => title.replaceAll(legacyId, canonicalId),
    name || ""
  );
}

function renameLegacyDisplayNames(value) {
  if (Array.isArray(value)) return value.map(renameLegacyDisplayNames);
  if (!value || typeof value !== "object") return value;

  return Object.fromEntries(Object.entries(value).map(([key, child]) => [
    key,
    key === "name" && typeof child === "string"
      ? renameLegacyHeroTitle(child)
      : renameLegacyDisplayNames(child),
  ]));
}

function migrateAwakeHeroes(data) {
  const sourceTeams = Array.isArray(data?.teams) ? data.teams : [];
  if (!containsLegacyAwakeHero(sourceTeams)) {
    const renamed = renameLegacyDisplayNames(data || {});
    return { data: renamed, changed: JSON.stringify(renamed) !== JSON.stringify(data || {}) };
  }

  // This runs while loading the authoritative shared store. Never remove a
  // record here: a client that silently omits a team will later submit a
  // partial `set_order` operation, which the server must reject. Any
  // destructive cleanup of retired hero records belongs in the explicit
  // migration/import workflow, not a normal editor session.
  const teams = sourceTeams.map((team) => renameLegacyDisplayNames(renameLegacyHeroIds(team)));
  let changed = false;

  sourceTeams.forEach((team, index) => {
    const migrated = teams[index];
    if (JSON.stringify(migrated) !== JSON.stringify(team)) changed = true;
  });

  return { data: { ...(data || {}), teams }, changed };
}

function withoutDefenseTeams(data) {
  const teams = Array.isArray(data?.teams) ? data.teams : [];
  const { meta: _meta, change: _change, ...clean } = data || {};
  return {
    ...clean,
    teams: teams.filter((team) => (team.tab || "attack") !== "defense")
  };
}

function formationHeroName(formation) {
  const slots = formation?.slots || {};
  const pattern = getPattern(formation?.pattern || "basic");
  return [...pattern.back, ...pattern.front]
    .map((slot) => slots[String(slot)])
    .filter(Boolean)
    .map((id) => getHero(id)?.name || id)
    .join(" / ");
}

function restoreLegacyGearDisplayText(text) {
  if (typeof text !== "string") return text;
  const definitions = [
    ...(typeof RINGS === "undefined" ? [] : RINGS),
    ...(typeof EQUIPMENT_SETS === "undefined" ? [] : EQUIPMENT_SETS)
  ]
    .filter(({ id, name }) => typeof id === "string" && typeof name === "string" && id !== name)
    .sort((left, right) => right.name.length - left.name.length);
  return definitions.reduce((restored, { id, name }) => restored.replaceAll(name, id), text);
}

function restoreLegacyGearDisplayTextInTeam(team) {
  const restored = JSON.parse(JSON.stringify(team));
  const restoreText = (object, key) => {
    if (object) object[key] = restoreLegacyGearDisplayText(object[key]);
  };

  restoreText(restored, "name");
  (restored.counters || []).forEach((counter) => {
    restoreText(counter, "name");
    restoreText(counter, "teamNote");
    Object.values(counter.gear || {}).forEach((gear) => restoreText(gear, "note"));
  });
  return restored;
}

function recoverLegacyGearDisplayDraft(draftData, remoteData) {
  const remoteById = new Map((remoteData?.teams || []).map((team) => [String(team.id), team]));
  let recoveredTeamCount = 0;
  const teams = (draftData?.teams || []).map((draftTeam) => {
    const remoteTeam = remoteById.get(String(draftTeam.id));
    if (!remoteTeam) return draftTeam;
    const restoredTeam = restoreLegacyGearDisplayTextInTeam(draftTeam);
    if (JSON.stringify(restoredTeam) !== JSON.stringify(remoteTeam)) return draftTeam;
    recoveredTeamCount += 1;
    return JSON.parse(JSON.stringify(remoteTeam));
  });
  return { data: { ...draftData, teams }, recoveredTeamCount };
}

function normalizeTeamNames(data) {
  const migrated = migrateAwakeHeroes(data);
  const normalized = withoutDefenseTeams(migrated.data);
  let changed = migrated.changed || normalized.teams.length !== (Array.isArray(data?.teams) ? data.teams.length : 0);

  normalized.teams.forEach((team) => {
    // A team cannot be both hidden and pinned. Favor hiding for legacy data so
    // a private team cannot become visible through a pin.
    if (team.hidden && team.pinned) {
      team.pinned = false;
      changed = true;
    }

    // Enemy-team names use the current rule: only a complete three-hero team
    // receives an automatic name.
    if (countFilledSlots(team.enemy?.slots || {}) === MAX_FORMATION_HEROES) {
      const name = formationHeroName(team.enemy);
      if (team.name !== name) {
        team.name = name;
        changed = true;
      }
    }

    // Counter teams use the current automatic rule for any selected heroes.
    (team.counters || []).forEach((counter) => {
      // A counter team cannot be both hidden and pinned. Favor hiding for
      // legacy data so an admin does not accidentally promote a hidden card.
      if (counter.hidden && (counter.pinned || counter.firstAttackOpensHouse)) {
        counter.pinned = false;
        counter.firstAttackOpensHouse = false;
        changed = true;
      }
      // The first-attack marker always keeps the recommended counter pinned.
      if (counter.firstAttackOpensHouse && !counter.pinned) {
        counter.pinned = true;
        changed = true;
      }
      const name = formationHeroName(counter);
      if ((counter.name || "") !== name) {
        counter.name = name;
        changed = true;
      }
    });
  });

  return { data: normalized, changed };
}

const Store = {
  data: null,
  _remoteSnapshot: null,
  _remoteData: null,
  _remoteRevision: 0,
  _staleDraftDetected: false,
  _loadError: null,
  _pollTimer: null,
  _baseTeamIds: null, // IDs ตอนโหลดหน้า ใช้แยกว่า "ลบตั้งใจ" vs "คนอื่นเพิ่มใหม่"

  async fetchTeamsText() {
    // The deployed Worker is the only production source of truth. Bundled JSON
    // is allowed only for local/static previews and is never presented as live
    // data after a production storage or binding failure.
    try {
      const api = await fetch(TEAMS_API_PATH, { cache: "no-store", credentials: "include" });
      // A legacy Pages deployment can return index.html for /api/teams.
      // Only treat an actual JSON response as the shared team store.
      if (api.ok && api.headers.get("Content-Type")?.includes("application/json")) {
        return await api.text();
      }
      if (api.headers.get("Content-Type")?.includes("application/json")) {
        const problem = await api.json().catch(() => ({}));
        const error = new Error(problem.error || `api_failed_${api.status}`);
        error.code = problem.error || "api_unavailable";
        throw error;
      }
    } catch (error) {
      if (error?.code && !(this.isLocalPreview() && error.code === "store_uninitialized")) throw error;
      if (!this.isLocalPreview()) {
        const unavailable = new Error("api_unavailable");
        unavailable.code = "api_unavailable";
        throw unavailable;
      }
    }

    if (!this.isLocalPreview()) {
      const unavailable = new Error("api_unavailable");
      unavailable.code = "api_unavailable";
      throw unavailable;
    }
    const file = await fetch(TEAMS_JSON_PATH, { cache: "no-store" });
    if (!file.ok) throw new Error("fetch failed " + file.status);
    return file.text();
  },

  isLocalPreview() {
    if (typeof location === "undefined") return true;
    return location.protocol === "file:" || ["localhost", "127.0.0.1", "::1"].includes(location.hostname);
  },

  async load() {
    const draft = this.readDraft();
    try {
      const text = await this.fetchTeamsText();
      this._remoteSnapshot = text;
      this.data = normalizeTeamNames(JSON.parse(text)).data;
      this._remoteRevision = Number(this.data.revision) || 0;
      this._remoteData = JSON.parse(JSON.stringify(this.data));

      // Resume a draft only when it was made from the current server version.
      // Older drafts are retained as a recoverable backup, never shown over
      // newer shared data.
      if (draft?.data && draft.baseRevision === this._remoteRevision) {
        const recovered = recoverLegacyGearDisplayDraft(draft.data, this._remoteData);
        this.data = normalizeTeamNames(recovered.data).data;
        if (recovered.recoveredTeamCount) {
          if (this.buildOperations().length) this.saveDraft();
          else this.clearDraft();
        }
      } else if (draft) {
        this._staleDraftDetected = true;
      }
      this._baseTeamIds = new Set((this.data.teams || []).map((t) => t.id));
    } catch (e) {
      console.warn(
        "Could not load the authoritative team store. Starting in a safe unavailable state.",
        e
      );
      this.data = JSON.parse(JSON.stringify(DEFAULT_DATA));
      this._loadError = e?.code || e?.message || "api_unavailable";
    }
    return this.data;
  },

  pollForUpdates(onChanged, intervalMs = 60000) {
    if (this._pollTimer) return;
    this._pollTimer = setInterval(async () => {
      try {
        const text = await this.fetchTeamsText();
        if (this._remoteSnapshot && text !== this._remoteSnapshot) {
          this._remoteSnapshot = text;
          onChanged();
        }
      } catch (e) { /* network error, try again next cycle */ }
    }, intervalMs);
  },

  stopPolling() {
    clearInterval(this._pollTimer);
    this._pollTimer = null;
  },

  saveDraft() {
    localStorage.setItem(DRAFT_KEY, JSON.stringify({
      format: 2,
      baseRevision: this._remoteRevision,
      data: this.data
    }));
  },

  readDraft() {
    const raw = localStorage.getItem(DRAFT_KEY);
    if (!raw) return null;
    try {
      const parsed = JSON.parse(raw);
      if (parsed?.format === 2 && parsed.data && Number.isInteger(parsed.baseRevision)) return parsed;
      // Old drafts have no source version and are unsafe to restore.
      return { format: 1, data: parsed, baseRevision: null };
    } catch (error) {
      console.warn("Draft parse failed; ignoring local draft", error);
      return null;
    }
  },

  hasStaleDraft() {
    return this._staleDraftDetected;
  },

  loadError() {
    return this._loadError;
  },

  hasDraft() {
    return !!localStorage.getItem(DRAFT_KEY);
  },

  clearDraft() {
    localStorage.removeItem(DRAFT_KEY);
  },

  buildOperations() {
    if (!this._remoteData || !Array.isArray(this._remoteData.teams)) return [];
    const before = this._remoteData.teams;
    const after = this.data.teams || [];
    const beforeById = new Map(before.map((team) => [String(team.id), team]));
    const afterById = new Map(after.map((team) => [String(team.id), team]));
    const operations = [];

    before.forEach((team) => {
      if (!afterById.has(String(team.id))) operations.push({ type: "delete_team", teamId: team.id });
    });
    after.forEach((team) => {
      const previous = beforeById.get(String(team.id));
      if (!previous || JSON.stringify(previous) !== JSON.stringify(team)) {
        operations.push({ type: "upsert_team", team: JSON.parse(JSON.stringify(team)) });
      }
    });
    const beforeOrder = before.map((team) => String(team.id));
    const afterOrder = after.map((team) => String(team.id));
    if (beforeOrder.join("|") !== afterOrder.join("|")) {
      operations.push({ type: "set_order", teamIds: afterOrder });
    }
    return operations;
  },

  acceptPublished(saved) {
    const normalized = normalizeTeamNames(saved).data;
    this.data = normalized;
    this._remoteData = JSON.parse(JSON.stringify(normalized));
    this._remoteSnapshot = JSON.stringify(normalized);
    this._remoteRevision = Number(normalized.revision) || 0;
    this._baseTeamIds = new Set((normalized.teams || []).map((team) => team.id));
    this._loadError = null;
    this.clearDraft();
  },

  normalizeNames() {
    if (!this.data) return false;
    const normalized = normalizeTeamNames(this.data);
    this.data = normalized.data;
    if (normalized.changed) this.saveDraft();
    return normalized.changed;
  },

  getTeams() {
    return this.data.teams;
  },

  getTeam(id) {
    return this.data.teams.find((t) => t.id === id) || null;
  },

  upsertTeam(team) {
    const idx = this.data.teams.findIndex((t) => t.id === team.id);
    if (idx >= 0) this.data.teams[idx] = team;
    else this.data.teams.push(team);
    this.saveDraft();
  },

  deleteTeam(id) {
    this.data.teams = this.data.teams.filter((t) => t.id !== id);
    this.saveDraft();
  },

  reorderTeam(dragId, targetId, insertBefore) {
    const teams = this.data.teams;
    const dragIdx = teams.findIndex((t) => t.id === dragId);
    if (dragIdx < 0) return;
    const [dragged] = teams.splice(dragIdx, 1);
    const newTargetIdx = teams.findIndex((t) => t.id === targetId);
    teams.splice(insertBefore ? newTargetIdx : newTargetIdx + 1, 0, dragged);
    this._normalizePinnedOrder(dragged.tab || "attack");
    this.saveDraft();
  },

  _tabTeams(tab) {
    return this.data.teams.filter((team) => (team.tab || "attack") === tab);
  },

  _replaceTabOrder(tab, ordered) {
    let index = 0;
    this.data.teams = this.data.teams.map((team) =>
      (team.tab || "attack") === tab ? ordered[index++] : team
    );
  },

  _normalizePinnedOrder(tab) {
    const ordered = this._tabTeams(tab);
    this._replaceTabOrder(tab, [
      ...ordered.filter((team) => team.pinned),
      ...ordered.filter((team) => !team.pinned),
    ]);
  },

  toggleTeamHidden(id) {
    const team = this.data.teams.find((t) => t.id === id);
    if (!team) return;
    team.hidden = !team.hidden;
    if (team.hidden) team.pinned = false;
    this.saveDraft();
  },

  moveTeam(id, direction) {
    const teams = this.data.teams;
    const team = teams.find((t) => t.id === id);
    if (!team) return;
    const tab = team.tab || "attack";
    const tabTeams = teams.filter((t) => (t.tab || "attack") === tab);
    const tabIdx = tabTeams.findIndex((t) => t.id === id);
    const newTabIdx = tabIdx + (direction === "up" ? -1 : 1);
    if (newTabIdx < 0 || newTabIdx >= tabTeams.length) return;
    const neighbor = tabTeams[newTabIdx];
    const idxA = teams.findIndex((t) => t.id === id);
    const idxB = teams.findIndex((t) => t.id === neighbor.id);
    [teams[idxA], teams[idxB]] = [teams[idxB], teams[idxA]];
    this._normalizePinnedOrder(tab);
    this.saveDraft();
  },

  toggleTeamPinned(id) {
    const team = this.getTeam(id);
    if (!team) return;
    const tab = team.tab || "attack";
    team.pinned = !team.pinned;
    if (team.pinned) team.hidden = false;
    const ordered = this._tabTeams(tab).filter((item) => item.id !== id);
    const pinned = ordered.filter((item) => item.pinned);
    const regular = ordered.filter((item) => !item.pinned);
    this._replaceTabOrder(tab, team.pinned
      ? [team, ...pinned, ...regular]
      : [...pinned, team, ...regular]);
    this.saveDraft();
  },

  toggleCounterPinned(teamId, counterIndex) {
    const counter = this.getTeam(teamId)?.counters?.[counterIndex];
    if (!counter) return;
    counter.pinned = !counter.pinned;
    if (!counter.pinned) counter.firstAttackOpensHouse = false;
    if (counter.pinned) counter.hidden = false;
    this.saveDraft();
  },

  toggleCounterFirstAttackOpensHouse(teamId, counterIndex) {
    const counter = this.getTeam(teamId)?.counters?.[counterIndex];
    if (!counter) return;
    counter.firstAttackOpensHouse = !counter.firstAttackOpensHouse;
    counter.pinned = counter.firstAttackOpensHouse;
    if (counter.pinned) counter.hidden = false;
    this.saveDraft();
  },

  moveTeamToTop(id) {
    const team = this.getTeam(id);
    if (!team) return;
    const tab = team.tab || "attack";
    const ordered = this._tabTeams(tab).filter((item) => item.id !== id);
    const pinned = ordered.filter((item) => item.pinned);
    const regular = ordered.filter((item) => !item.pinned);
    this._replaceTabOrder(tab, team.pinned
      ? [team, ...pinned, ...regular]
      : [...pinned, team, ...regular]);
    this.saveDraft();
  },

  moveTeamToBottom(id) {
    const team = this.getTeam(id);
    if (!team) return;
    const tab = team.tab || "attack";
    // Pinning takes priority over order. Sending a pinned team to the bottom
    // therefore clears its pin, then puts it after all regular teams.
    team.pinned = false;
    const ordered = this._tabTeams(tab).filter((item) => item.id !== id);
    const pinned = ordered.filter((item) => item.pinned);
    const regular = ordered.filter((item) => !item.pinned);
    this._replaceTabOrder(tab, [...pinned, ...regular, team]);
    this.saveDraft();
  },

  exportJson() {
    const blob = new Blob([JSON.stringify(this.data, null, 2)], {
      type: "application/json"
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "teams.json";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  },

  async parseImportJsonFile(file) {
    const text = await file.text();
    const parsed = JSON.parse(text);
    if (!parsed || !Array.isArray(parsed.teams)) {
      throw new Error("ไฟล์ไม่ถูกต้อง: ต้องมี teams เป็น array");
    }
    // Preserve the accepted source schema while normalizing newly imported
    // records to the single guild shown throughout this interface.
    parsed.teams = parsed.teams.map((team) => ({ ...team, guild: "PokkyRebirth" }));
    return normalizeTeamNames(parsed).data;
  }
};

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}
